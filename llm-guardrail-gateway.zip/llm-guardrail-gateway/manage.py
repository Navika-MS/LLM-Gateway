"""Project task runner (replaces the old .bat scripts). Pure standard library; works on Windows, macOS and Linux.

    python manage.py setup              create backend/.venv, install Python + npm packages, create backend/.env
    python manage.py test [pytest args] run the offline test suite
    python manage.py eval [dataset]     dev + regression by default; or one of: dev regression holdout legacy_unseen policy policy_unseen
                                        add  --stage2 deberta  (or simulator+deberta) and/or  --risk-policy off
    python manage.py setup-model [--enable]  OPTIONAL: install torch/onnxruntime and download the Stage 2 model (~1.5 GB incl. ONNX);
                                        --enable also sets GATEWAY_STAGE2_BACKEND in backend/.env (that one line only)
    python manage.py bench [args]       compare Stage 2 backends: accuracy, latency, memory, start-up (benchmarks/)
    python manage.py backend            API on http://127.0.0.1:8000 (localhost only)
    python manage.py frontend           dashboard on http://localhost:5173
    python manage.py start [--no-browser]  backend + dashboard together, opens the browser; Ctrl+C stops both

Free local simulation: no API key and no paid calls are needed by any command here.
"""
import os
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"
VENV = BACKEND / ".venv"
VENV_PY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def say(msg):
    print("[manage] " + msg, flush=True)


def project_python():
    """The venv interpreter if setup has been run, otherwise the interpreter running this script."""
    if VENV_PY.exists():
        return str(VENV_PY)
    say("backend/.venv not found; using " + sys.executable + " (run 'python manage.py setup' for an isolated environment)")
    return sys.executable


def npm():
    exe = shutil.which("npm.cmd" if os.name == "nt" else "npm") or shutil.which("npm")
    if not exe:
        sys.exit("[manage] npm not found. Install Node.js 18+ from https://nodejs.org and re-open the terminal.")
    return exe


def run(cmd, cwd, env=None):
    return subprocess.call([str(c) for c in cmd], cwd=str(cwd), env=env)


def cmd_setup(_args):
    if sys.version_info < (3, 9):
        sys.exit("[manage] Python 3.9+ is required.")
    if not VENV_PY.exists():
        say("creating virtual environment in backend/.venv ...")
        if run([sys.executable, "-m", "venv", VENV], ROOT) != 0:
            sys.exit("[manage] venv creation failed.")
    say("installing backend packages ...")
    if run([VENV_PY, "-m", "pip", "install", "--disable-pip-version-check", "-r", "requirements.txt"], BACKEND) != 0:
        sys.exit("[manage] pip install failed.")
    env_file, example = BACKEND / ".env", BACKEND / ".env.example"
    if not env_file.exists() and example.exists():
        shutil.copyfile(example, env_file)
        say("created backend/.env from .env.example (defaults are free and local; no key needed)")
    say("installing frontend packages ...")
    if run([npm(), "install", "--no-audit", "--no-fund"], FRONTEND) != 0:
        sys.exit("[manage] npm install failed.")
    say("done. Next: python manage.py start   (or: python manage.py test)")
    return 0


def cmd_test(args):
    env = dict(os.environ, GATEWAY_SKIP_DOTENV="1")  # tests are hermetic: never read backend/.env
    return run([project_python(), "-m", "pytest"] + args, BACKEND, env)


def cmd_eval(args):
    py = project_python()
    if args:
        return run([py, "evaluator.py", "--dataset"] + args, BACKEND)
    return max(run([py, "evaluator.py", "--dataset", d], BACKEND) for d in ("dev", "regression"))


def cmd_setup_model(args):
    """Optional: install the ML libraries and download the pinned Stage 2 model (one explicit, user-initiated download)."""
    if not VENV_PY.exists():
        sys.exit("[manage] run 'python manage.py setup' first.")
    say("installing model libraries (torch, transformers, onnxruntime; large) ...")
    if run([VENV_PY, "-m", "pip", "install", "--disable-pip-version-check", "-r", "requirements-model.txt"], BACKEND) != 0:
        sys.exit("[manage] pip install failed.")
    say("downloading the pinned model (about 740 MB) and its ONNX export (another 740 MB; the recommended runtime) ...")
    if run([VENV_PY, "stage2_backends.py", "--onnx"], BACKEND) != 0:
        sys.exit("[manage] model download failed.")
    choice = RECOMMENDED_BACKEND
    if "--enable" in args:
        _set_env_value(BACKEND / ".env", "GATEWAY_STAGE2_BACKEND", choice)
        say(f"set GATEWAY_STAGE2_BACKEND={choice} in backend/.env (no other line was changed). Restart the backend.")
    else:
        say(f"done. To use it, add this line to backend/.env and restart:   GATEWAY_STAGE2_BACKEND={choice}")
        say("or run 'python manage.py setup-model --enable' and I will add it for you. See docs/MODEL_BENCHMARK.md for why.")
    return 0


# The backend the benchmark in docs/MODEL_BENCHMARK.md recommends. The built-in default stays "simulator" so the project
# runs with no download; this is what `setup-model --enable` switches on.
RECOMMENDED_BACKEND = "simulator+deberta_onnx"


def _set_env_value(path, key, value):
    """Set KEY=value in an env file, creating it from .env.example if missing. Touches only that one line; prints nothing from it."""
    if not path.exists():
        example = path.with_name(".env.example")
        path.write_text(example.read_text(encoding="utf-8") if example.exists() else "", encoding="utf-8")
    lines = path.read_text(encoding="utf-8").splitlines()
    for i, line in enumerate(lines):
        if line.split("=", 1)[0].strip() == key:
            lines[i] = f"{key}={value}"
            break
    else:
        lines.append(f"{key}={value}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def cmd_bench(args):
    """Compare Stage 2 backends on the same data: accuracy, latency, memory, start-up. Writes new files only."""
    return run([project_python(), "benchmarks/compare_stage2.py"] + args, BACKEND)


def backend_cmd():
    return [project_python(), "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", "8000"]


def backend_env():
    """`manage.py` always serves on localhost (see backend_cmd), so tell the app that, whatever HOST an old .env says.

    The app decides things like "may I save your prompts?" from its configured HOST; a leftover HOST=0.0.0.0 in .env would
    otherwise switch that off even though this launcher never exposes the server to the network. (An explicit environment
    variable beats .env, so this does not edit the file.)
    """
    return dict(os.environ, HOST="127.0.0.1")


def cmd_backend(_args):
    return run(backend_cmd(), BACKEND, backend_env())


def cmd_frontend(_args):
    if not (FRONTEND / "node_modules").exists():
        sys.exit("[manage] frontend packages missing. Run: python manage.py setup")
    return run([npm(), "run", "dev"], FRONTEND)


def cmd_start(args):
    if not (FRONTEND / "node_modules").exists():
        sys.exit("[manage] frontend packages missing. Run: python manage.py setup")
    procs = [
        subprocess.Popen([str(c) for c in backend_cmd()], cwd=str(BACKEND), env=backend_env()),
        subprocess.Popen([npm(), "run", "dev"], cwd=str(FRONTEND)),
    ]
    say("backend  http://127.0.0.1:8000   dashboard  http://localhost:5173   (Ctrl+C stops both)")
    if "--no-browser" not in args:
        threading.Timer(6.0, lambda: webbrowser.open("http://localhost:5173")).start()
    try:
        while all(p.poll() is None for p in procs):
            time.sleep(0.5)
        say("a process exited; shutting down")
    except KeyboardInterrupt:
        say("stopping ...")
    finally:
        for p in procs:
            if p.poll() is None:
                p.terminate()
        for p in procs:
            try:
                p.wait(timeout=8)
            except subprocess.TimeoutExpired:
                p.kill()
    return 0


COMMANDS = {"setup": cmd_setup, "setup-model": cmd_setup_model, "test": cmd_test, "eval": cmd_eval, "bench": cmd_bench,
            "backend": cmd_backend, "frontend": cmd_frontend, "start": cmd_start}


def main(argv):
    if not argv or argv[0] not in COMMANDS:
        print(__doc__)
        return 0 if not argv or argv[0] in ("-h", "--help", "help") else 2
    return COMMANDS[argv[0]](argv[1:]) or 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
