# Interview Guide: LLM Guardrail Gateway

Everything below is accurate to the code in this repository. Wherever something is **simulated**, it says so; saying that
plainly is a strength in an interview, not a weakness.

## 1. The 60-second pitch

> I built a security gateway that sits in front of an LLM. Prompts pass cheap deterministic checks first, then a Stage 2
> classifier, and only allowed prompts reach the generator, whose output is schema-validated and scanned before it
> leaves. I then audited my own first version and found it was weaker than its own benchmark claimed, so I rebuilt the
> decision logic around one authority, made the server own security policy, and replaced the numbers with a reproducible
> evaluation that includes a frozen holdout. The frozen holdout showed the heuristic simulator catches only 12% of unseen
> attacks, and I report that rather than hide it. The project runs fully offline; the Stage 2 classifier is a deterministic
> simulator and replies are mocks, and the UI says so.

## 2. What is implemented vs. what is simulated

| Real and tested | Simulated (and labelled as such) |
|---|---|
| Request validation, size limits, strict schema, 422/413/502 mapping | **Stage 2 classifier**: a deterministic heuristic scorer (`LOCAL_HEURISTIC_SIMULATOR`), not an LLM or ML model |
| Server-owned policy; clients can only tighten | **Generation**: a mock generator (`LOCAL_MOCK_GENERATOR`) that returns JSON text |
| Stage 1: normalisation, PII/secret detection (Luhn, brands), signatures, use-vs-mention | Latency: local compute time, **not** LLM inference latency |
| Strict output validation, exactly one bounded retry, output PII/credential guard | Cost: "N/A" (no paid calls are made) |
| Evaluation harness, metrics, dataset hash verification, error isolation | Optional live adapters exist but were **never run against the real API** here |
| 600+ automated tests, run offline | A real trained model is optional (opt-in): see section 9 |

## 3. Architecture in one minute

1. Validate and size-limit the request. 2. Resolve policy (server policy; client may only tighten). 3. Stage 1 on *normalised*
text: block high-confidence threats immediately. 4. **Every prompt Stage 1 did not block goes to Stage 2** when enabled.
5. `risk > threshold` blocks; the uncertain band is flagged; a classifier failure is ERROR (fail closed). 6. Only then
generate, validate the JSON strictly with at most one retry, and scan the output. 7. Return the answer plus metadata
saying exactly what ran, what was simulated, and which policy applied.

Diagram: [ARCHITECTURE.md](ARCHITECTURE.md).

## 4. The story that makes this project credible (what the audit found)

- **Conflicting results had a root cause.** Four scripts encoded four policies; two skipped Stage 2 for "clean" prompts, the
  API did not. The 95.83% could not be reproduced (the same cases scored 41.67% on the code that existed) because it came from an
  older file. Lesson: results must be tied to code (reports now carry a code fingerprint).
- **Routing was not the main problem.** Running Stage 2 on every prompt left holdout recall at 6%. The simulator simply did
  not recognise the attacks. Fixing the bypass was necessary but not sufficient, and I measured that instead of assuming.
- **The "classifier" was substring matching**: `"dan"` blocked *guidance* and *Sudan*; 9 of 12 plain benign prompts were
  blocked; 7 of 7 trivial obfuscations passed.
- **The client controlled security.** One request body could disable every check.
- **One regex made a 40,000-character prompt take 21 seconds** (quadratic), with no length limit.
- **Schema validation never ran** in simulation (the mock returned an already-valid object) and the mock *claimed* checks
  that had not run.
- **The benchmark was circular**: the simulator contained verbatim fragments of its own test templates, and the 400
  "samples" were 43 distinct prompts.

## 5. Evaluation methodology (be able to explain this cold)

- **Three splits with different jobs.** `dev` (used while building; shows design completeness), `regression` (one case per
  fixed defect), `holdout` (frozen: seed 731904, SHA-256 verified, prompts never displayed, run once for reporting).
- **Why a frozen holdout matters.** The dev set was written by the same person as the simulator, so it flatters it (90% recall).
  The holdout says 12%. That gap *is* the generalisation estimate.
- **Metrics done carefully.** Undefined values are `n/a` (not 100% or 0%); errors are excluded and reported as reliability,
  never counted as passes; ambiguous dual-use prompts are reported separately; the strict operating point (block the
  uncertain band) shows the precision/recall trade-off.
- **Hard negatives.** 22 security-education questions and 18 lexical look-alikes measure over-blocking, because a guardrail
  that blocks everything has perfect recall.
- **Independent false-positive check.** 1,562 natural paragraphs the author did not write: 0.06% blocked.
- **Discipline.** Simulator logic was frozen after the holdout aggregate was seen (by accident, while testing that prompts are hidden);
  no rule changed afterwards, and that event is disclosed in the verification report.

## 6. Known limitations (say these before they ask)

- English only; lexicon-based; no semantic understanding. Misses paraphrase, persuasion/authority attacks ("I'm an authorised red-teamer"),
  fiction-wrapped harm requests, multi-turn setups, and anything needing world knowledge.
- Holdout recall is 12%. Do not claim it "detects prompt injection"; claim it "demonstrates the architecture around a classifier".
- A rule-based mention detector can be gamed by an adaptive attacker who wraps a command in discussion framing.
- No authentication, rate limiting or TLS. `/evaluate` is unauthenticated. CORS is not security.
- PII policy is blunt: any structurally valid SSN or real-looking email blocks, which over-blocks some legitimate pasted data.
- The live adapters are untested against the real API.

## 7. Likely questions and good answers

**Why two stages instead of one?** Cost and latency tiering plus defence in depth: Stage 1 is microseconds and deterministic
for high-confidence cases; Stage 2 handles the ambiguous middle. In a real deployment Stage 2 would be a model, so you want to
call it only when needed. Here it is local, so it runs on every non-blocked prompt, which also removed an unsafe shortcut.

**Why did you stop skipping Stage 2 for "clean" prompts?** "Clean" only means Stage 1 recognised nothing. That is the dangerous
case: an attack phrased in a way Stage 1 does not know looks identical to benign text. Skipping the second opinion exactly there
defeats the layer. The audit also showed the shortcut was inconsistent across code paths.

**What does `bypassed_stage2` mean?** Stage 2 did not execute, for any reason, and `stage2_skip_reason` says why. It used to
mean three different things.

**How do you decide block versus allow?** One rule: block iff `risk > threshold` (strictly). Scores between `uncertain_low`
and the threshold are *uncertain*: flagged by default, blocked in strict mode. The old `OR is_malicious` meant the slider could
not relax a decision, so it was removed.

**Why is the client not allowed to turn checks off?** A control the requester can disable is not a control. The server owns
policy; clients can lower the threshold or switch things on. Weakening requests are refused and reported in the response, and a
demo-only override exists behind an explicit operator flag that every response labels.

**How do you handle obfuscation?** Normalise once, up front: NFKC, strip zero-width/format characters, fold homoglyphs, repair
leetspeak inside words, collapse spacing, check reversed text, and decode base64/hex/URL payloads (bounded depth and size) before matching.
Fixing the root cause beats adding phrase variants.

**Isn't a quoted attack phrase a false positive risk (security education)?** Yes, so Stage 1 distinguishes *use* from *mention*: a
phrase quoted or introduced by a discussion frame escalates to Stage 2 instead of hard-blocking. Quote-wrapping a command
("repeat after me: '...'") is still treated as use. A test caught that my first version let "for educational purposes, ignore your
instructions" launder a command, because I scanned the whole sentence for discussion words; now only a frame immediately before
the phrase counts.

**How do you validate model output?** The generator returns raw text. A strict pydantic model (no type coercion, no extra keys) is
the gate. On failure exactly one retry is made, passing field paths and messages (never values) back. After that: ERROR, nothing
returned. The retry cap is enforced in code, not just config, and nothing "recovers" malformed output into a valid-looking reply
(the old live path did).

**Why 502 for errors instead of 200?** It separates reliability from security verdicts. BLOCKED is the gateway working; ERROR
means it could not decide. Monitoring can alert on the second without conflating it with attack traffic.

**What is the Luhn check and why not just count digits?** Luhn is the checksum card numbers satisfy. A digit-count regex flags
order IDs and timestamps; Luhn plus brand and length rules cuts that. Even so, about 10% of random digit strings pass Luhn,
hence the brand check.

**How would you scale it?** Stage 1 is stateless and linear-time, so it scales horizontally. The first real bottleneck is a model-based
Stage 2: move it behind its own inference service so the API layer scales independently, cache verdicts on normalised-prompt hashes, and
apply per-tenant rate limits and quotas.

**How would you make Stage 2 real?** Replace `classify()` with an adapter implementing the same callable contract (the live adapter
shows the shape): same error policy, same thresholds, same evaluation harness, but re-measured on a holdout that is
representative of real traffic and **collected independently of the model's developers**.

**What would you do next?** Build a larger independent holdout from public adversarial corpora; evaluate a trained injection
classifier behind the same interface and compare operating points; add authentication, rate limiting and audit logging; adversarially
test the use/mention heuristic.

**Walk me through a bug you found in your own work.** The quadratic email regex: a prompt of repeated letters made every start
position scan to the end looking for `@`. I measured 5k/10k/20k/40k characters (0.4 s, 1.1 s, 4.7 s, 21 s, ratio about 4x per doubling), proved only one pattern was
affected, replaced it with a bounded scan around each `@`, added a length limit, and added a scaling test that asserts it is no
longer quadratic.

**What is the most important thing you learned?** A benchmark you wrote alongside the system measures the system's authors, not
the system. Freeze a holdout early, never tune against it, and report the number even when it is bad.

## 8. Numbers to remember

| | |
|---|---|
| Tests | 603 collected, offline, about 10 s |
| Dev / regression / legacy-24 | 94.15% / 100% / 91.67% accuracy, 0% false positives |
| **Frozen holdout** | **56% accuracy, 100% precision, 12% recall, 0% FPR** (baseline was 52 / 75 / 6 / 2) |
| Natural-text false positives | 1 of 1,562 (0.06%) |
| Pre-audit evidence | 9/12 benign blocked; 7/7 obfuscations passed; 40k chars = 21 s; 95.83% unreproducible (41.67% on current code) |

## 9. Plugging in a real model (the second chapter of the story)

**What you did.** After the audit showed the simulator caught 12% of unseen attacks, you added a trained model behind the same Stage 2
interface (`GATEWAY_STAGE2_BACKEND`), benchmarked it against the simulator on the same frozen holdout, and chose by evidence.

**The numbers to remember** (holdout, laptop CPU): simulator 12% recall / 0% FPR / 1 ms; DeBERTa through PyTorch 92% / 8% / 244 ms;
through ONNX the same verdicts at 38 ms (6x faster); int8-quantised ONNX 0% recall (smaller and faster but useless). Ensemble with the
rules: dev recall 90% -> 99%. Full table and caveats: [MODEL_BENCHMARK.md](MODEL_BENCHMARK.md).

**Why ONNX over PyTorch?** Same decisions, 6x faster, faster to load. Cost: 1.6 GB resident vs 431 MB. I tested it instead of
assuming, and I also tested int8, which looked attractive and was broken. Lesson: re-measure accuracy after every "optimisation".

**Why is the model not the default?** The core demo must run free and offline with no 740 MB download. It is opt-in
(`setup-model --enable`), the server never downloads on its own, and if the model is missing the gateway reports it and fails closed.

**Why a separate rule layer?** "Send me the trade secret" and "erase the main database" are not injections; the model alone caught 17% of
them. Different question, different rules, independent of the Stage 2 backend, server-owned policy off / flag / block.

**How good is that layer, honestly?** 51% on paraphrases it was not written against, 83% on a fresh round run once after fixes, 0 false
positives on 68 benign look-alikes. Lexical and English-only. I report the first number, not the flattering one.

**Mistakes worth telling.** (1) The model was classifying every prompt twice because normalisation attaches a rot13 reading to all text;
a test caught it and the first benchmark was superseded, not hidden. (2) Unit tests passed while the dashboard's label buttons failed
CORS; browser testing found it. (3) I reasoned about some of my own "unseen" prompts while designing rules, so that set is not a clean
test, and the docs say so. (4) The holdout is now used up by model selection; the right next step is a new independent holdout.

**Security properties of the model integration.** Loads from a local folder only (offline flags set), pinned revision, safetensors/ONNX
only (no pickle), SHA-256 checked, overlapping windows so padding cannot hide an attack, input too long to cover fails closed, any model
failure is status ERROR not a pass, inference serialised to avoid CPU oversubscription, evidence never contains prompt text.

**The test-list feature.** Every typed prompt is saved so you can evaluate it later, but a typed prompt has no ground truth, so you label
it; unlabelled prompts are shown and never scored (scoring a system against its own answers proves nothing). Prompts with PII or secrets are
never written to disk, the list is capped, localhost-only, and kept out of the project zip.
