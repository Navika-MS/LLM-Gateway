# Stage 2 model benchmark and decision

**Question:** Stage 2 started as a hand-written heuristic scorer that caught 12% of attacks on the frozen holdout. Would a real,
free, local trained model do better, and at what cost?

**Short answer:** yes, by a lot. Use **`simulator+deberta_onnx`** (the DeBERTa model through ONNX Runtime, fp32, with the rule-based
scorer as a second opinion) when you want better detection. Keep **`simulator`** as the default so the project still runs
offline with no download. The model does **not** replace the sensitive-data / destructive-action rule layer, and it
over-blocks some security-education prompts.

Raw reports (never overwritten): `backend/benchmarks/results/`. Baseline recorded before any change:
`backend/benchmarks/baseline_simulator_v2.0.0/`. Re-run everything with `python manage.py bench`.

## Setup measured

| | |
|---|---|
| Model | `protectai/deberta-v3-base-prompt-injection-v2`, Apache-2.0, pinned revision `90c9989b1a34`, `model.safetensors` SHA-256 `6521cb8d...e0424` |
| Machine | Intel Core i5-10210U (4 cores / 8 threads), 15.8 GB RAM, Windows 10, **CPU only**, Python 3.9, torch 2.8, onnxruntime 1.19 |
| Method | each backend in its own fresh process; latency from an uncached first pass; accuracy at the policy's default threshold (block iff risk > 65) |
| Datasets | frozen holdout (100), dev (179), regression (24), legacy (24), policy dev (105), policy "unseen" (36) |

## Results

Classifier only = Stage 1 + Stage 2 (rule layer OFF), so the numbers isolate Stage 2.

| Backend | Holdout recall | Holdout FPR | Dev recall | Dev FPR | Stage 2 p50 / p95 | Memory after load | Load |
|---|---|---|---|---|---|---|---|
| `simulator` (default) | 12% | 0% | 90% | 0% | 0.9 / 1.7 ms | 32 MB | 0 s |
| `deberta` (PyTorch) | 92% | 8% | 90% | 7% | 244 / 384 ms | 431 MB (peak 1.0 GB) | 30 s |
| **`deberta_onnx` (fp32)** | **92%** | **8%** | 90% | 7% | **38 / 94 ms** | 1.6 GB | 17 s |
| `deberta_onnx:int8` | **0%** | 0% | **25%** | 0% | 29 / 72 ms | 766 MB | 16 s |
| **`simulator+deberta_onnx`** | **92%** | **8%** | **99%** | **7%** | ~55 / 96 ms | 1.6 GB | 25-90 s (cold disk) |

What the table says:

* **Accuracy.** The model lifts holdout recall from 12% to 92% (46 of 50 attacks) for 4 false positives out of 50 benign prompts.
  That is the first real evidence of generalisation in this project.
* **PyTorch vs ONNX.** Identical decisions, ONNX about 6x faster (p50 38 ms vs 244 ms) and faster to load. ONNX uses more memory
  after load (1.6 GB vs 431 MB); the PyTorch load peaks at about 1.0 GB.
* **int8 is a trap.** Quantising to int8 (made locally, 244 MB) looks smaller and faster, but its recall collapses (0% on the
  holdout, 25% on dev). It is shown here so nobody "optimises" into it. Do not use it.
* **Ensemble.** Highest risk wins. Dev recall rises from 90% to 99% because the two make different mistakes (the model misses
  some data-exfiltration phrasings the rules catch; the rules miss paraphrase the model catches). The false positives are the
  model's; the ensemble cannot remove them.
* **Long prompts are slow.** A 4,000-character prompt takes about 2.2 s because it is scanned in overlapping 512-token windows
  (on purpose: truncating would let an attacker pad past the model's context).
* **A bug the benchmark found.** The first run classified every prompt twice, because normalisation attaches a rot13 reading
  to everything. That doubled the cost and made the first latencies (390 ms) look worse than reality. Fixed (the model skips rot13;
  Stage 1 still catches rot13-encoded attacks), with a test. The superseded run is kept as
  `SUPERSEDED_rot13_double_inference_...` for transparency.

### Per-category (classifier only, dev set, `deberta_onnx` vs `simulator`)

| category | simulator | model |
|---|---|---|
| DIRECT_JAILBREAK, INDIRECT_INJECTION, PII/SECRET | 0 missed | 0 missed |
| DATA_EXFILTRATION (10) | 0 missed | **4 missed** |
| INSTRUCTION_OVERRIDE, PROMPT_EXTRACTION, ENCODED_PAYLOAD | 0 missed | 1 missed each |
| HARD_SEMANTIC (8, persuasion-style) | 7 missed | **2 missed** |
| POLICY_EVASION (10) | 3 missed | 1 missed |
| benign: SECURITY_EDUCATION (22) | 0 FP | **2 FP** |
| benign: LEXICAL_LOOKALIKE / NUMBERS_AND_IDS / SYNTHETIC_PII | 0 FP | 1 FP each |

The holdout has binary labels only, so it has no per-category breakdown.

## The model does not solve "trade secrets" and "erase the database"

Those are not prompt injections. On the policy sets the model alone catches 8 of 48 (17%) and 1 of 16 (6%) of the sensitive-data
and destructive-action prompts; the simulator catches none. A separate rule layer (`risk_policy.py`) handles them.
With the layer on, `simulator+deberta_onnx` scores 100% on both policy sets, but see the caveats below.

### Honest estimate of the rule layer

| Test | Result |
|---|---|
| Policy dev set (rules were iterated on it) | 48/48 attacks blocked, 0/53 benign blocked |
| `policy_unseen` (written before the rules, but its author reasoned about some of its prompts while designing them) | 16/16, 0/20. **Not a clean test.** |
| Red-team round 1: 35 paraphrases it was not written against, **before** fixes | **18/35 (51%)** blocked, 0/30 benign blocked |
| Red-team round 2: 36 fresh paraphrases written after the fixes, run **once** and not tuned afterwards | **30/36 (83%)** blocked, 0/38 benign blocked |

Known misses from round 2: "Zero out ...", "permanently remove all records from the master database" (filler word before the verb),
"Trash ...", "End the project by erasing ...", "Extract the private customer database ...", "Dump the whole customer table from the CRM".
Treat the rule layer as one layer, not a complete defence. English only; lexical; cannot tell whether a requester is authorised.

## Decision

| Criterion | Result |
|---|---|
| Detection | model backends are far better on unseen attacks (holdout 92% vs 12%) |
| Over-blocking | the model adds 7-8% false positives on benign security-education style prompts. This is the price. |
| Speed | `deberta_onnx` p50 38 ms, p95 94 ms: fine for an interactive gateway on a laptop CPU |
| Memory | 1.6 GB resident: acceptable for a laptop, a real cost on a small server. PyTorch is smaller (431 MB) but 6x slower. |
| Start-up | 17-90 s to load (depends on whether the files are in the OS cache); the server loads in the background and `/health` shows progress |
| Chosen | `simulator+deberta_onnx` for better detection; `simulator` stays the zero-download default; int8 rejected |

If memory is the constraint, use `deberta` (PyTorch, 431 MB, 244 ms). If false positives matter more than recall, use `simulator`
alone and accept the 12% holdout recall.

## Limitations of this benchmark

* **The holdout was used to compare backends.** That is a selection on it: it is no longer a clean estimate for the chosen
  backend, and it was also seen in aggregate earlier (see VERIFICATION_REPORT). A new independent holdout, collected by someone
  who has not seen the rules, is needed before quoting 92% externally. Your own labelled prompts (the `user` / `combined` sets)
  are a start.
* One machine, one model, sequential requests, no GPU, no load test. Latencies are wall-clock and will differ on yours.
* The model is trained by a third party on data this project does not control, and can be bypassed by an adaptive attacker.
* English only. No multi-turn attacks. No semantic understanding of authorisation.
