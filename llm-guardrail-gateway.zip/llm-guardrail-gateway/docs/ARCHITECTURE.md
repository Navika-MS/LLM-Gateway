# Architecture

One principle drives the design: **there is exactly one place that decides whether a prompt is blocked.**
`pipeline.security_decision(prompt, policy)` is called by the API, the evaluator and the tests. Before the audit there
were four separate copies of that logic, and they disagreed about whether Stage 2 even ran for "clean" prompts.

## Request pipeline

```mermaid
flowchart TD
    A[POST /api/v1/chat] --> B{Valid request?<br/>size, types, no unknown fields}
    B -- no --> B1[422 / 413<br/>input never echoed]
    B -- yes --> C[Resolve policy<br/>server policy + client TIGHTENING only]
    C --> D[Normalise text<br/>NFKC, strip invisibles, fold homoglyphs,<br/>de-leet, decode base64/hex/url]
    D --> E{STAGE 1<br/>PII / secret / signature?}
    E -- high-confidence hit --> X1[BLOCKED<br/>Stage 2 NOT run<br/>stage2_skip_reason=STAGE_1_BLOCKED]
    E -- clean or suspicious --> R{RISK-POLICY LAYER<br/>sensitive-data request or<br/>destructive command?}
    R -- BLOCK level --> XR[BLOCKED<br/>Stage 2 NOT run<br/>skip_reason=RISK_POLICY_BLOCKED]
    R -- FLAG level or none --> F{Stage 2 enabled?}
    F -- no, prompt CLEAN --> G1[allowed on Stage 1 alone<br/>skip_reason=DISABLED_BY_POLICY]
    F -- no, prompt SUSPICIOUS --> X2[BLOCKED<br/>fail closed:<br/>escalation unavailable]
    F -- yes --> H[STAGE 2 backend, configurable:<br/>simulator or DeBERTa torch/ONNX<br/>or an ensemble. risk 1-100]
    H -- classifier error --> X3[ERROR 502<br/>fail closed by default]
    H -- risk > threshold --> X4[BLOCKED]
    H -- uncertain band --> I[allow + FLAG<br/>or block in strict mode]
    H -- below band --> J
    I --> J[Mock generator returns RAW JSON text]
    G1 --> J
    J --> K{Strict schema validation}
    K -- invalid, first try --> L[ONE retry with the validation error]
    L --> K
    K -- invalid after retry --> X5[ERROR 502<br/>nothing returned]
    K -- valid --> M{Output guard:<br/>PII / credentials in the reply?}
    M -- leak --> X6[BLOCKED<br/>value never echoed]
    M -- clean --> N[200 SUCCESS<br/>full decision metadata]
```

## Evaluation pipeline

```mermaid
flowchart LR
    D1[dev set<br/>design completeness] --> E[evaluator.evaluate]
    D2[regression set<br/>one case per fixed defect] --> E
    D3[frozen holdout<br/>SHA-256 verified, prompts hidden] --> E
    E -->|per case, isolated try/except| S[pipeline.security_decision<br/>SAME function as the API]
    S --> R{outcome}
    R --> TP & FP & TN & FN
    R --> ERR[ERROR: excluded from metrics,<br/>reported as reliability]
    TP & FP & TN & FN --> M[metrics: undefined = n/a<br/>+ strict operating point<br/>+ per-category + missed list]
    ERR --> M
    M --> O[timestamped report: dataset sha, seed,<br/>policy/simulator version, code fingerprint]
```

## Semantics, defined once

| Term | Meaning |
|---|---|
| **Block rule** | Stage 2 blocks iff `risk_score > risk_threshold` (strictly greater; a score equal to the threshold passes). No second `is_malicious` flag. |
| **Uncertain band** | `uncertain_low <= risk <= threshold`. Default: allowed and **flagged** (`flagged_uncertain`); `uncertain_action=block` makes it strict. Never reported as certainty. |
| **`bypassed_stage2`** | `true` iff Stage 2 **did not execute**, for any reason. `stage2_skip_reason` is `STAGE_1_BLOCKED`, `RISK_POLICY_BLOCKED` or `DISABLED_BY_POLICY`. |
| **Stage 1 routes** | `BLOCK` (high confidence, immediate), `SUSPICIOUS` (soft signal), `CLEAN`. `CLEAN` does **not** skip Stage 2. |
| **ERROR vs BLOCKED** | BLOCKED is a security verdict. ERROR means the gateway could not decide or produce a valid result (classifier failure, invalid output after one retry). It is HTTP 502, is never a pass, and is excluded from classification metrics. |
| **Timing** | `execution_time_ms` is one `perf_counter` span. `breakdown_ms` (stage1_local, stage2_classifier, generation, output_validation, overhead) sums to it. It is local simulator compute time, **not LLM latency**. |
| **Policy ownership** | The server owns policy. A client can lower the threshold or switch a control **on**; anything weakening is refused and reported in `response.policy.rejected`. |

## Modules and responsibilities

| Module | Responsibility | Notable properties |
|---|---|---|
| `normalization.py` | One normalised view of untrusted text | NFKC, invisible/format characters stripped, homoglyphs folded **only counted as obfuscation in mixed-script tokens**, leetspeak repaired inside words only, bounded decoding (depth 2, 8 segments, 4 KB) |
| `detectors.py` | PII and secrets | Linear time (40k chars: ~ms, was 21 s), boundary-aware, brand + length + Luhn, RFC 2606 domains and published test PANs treated as synthetic, never returns the matched value |
| `guardrails.py` | Stage 1 and the output guard | Small curated signature set, matched on normalised/tight/reversed/decoded views; **use vs mention** gate; no phrase-list growth |
| `risk_policy.py` | Sensitive-data requests and destructive commands | Separate from Stage 2 and independent of which backend runs it; command-vs-question analysis, scope words (main/production/all), exempt test/staging/partial targets; BLOCK / FLAG levels; server policy off / flag / block; evidence is lexicon words only, never prompt text |
| `stage2_backends.py` | Pluggable Stage 2 | `simulator`, `deberta` (PyTorch), `deberta_onnx`, or `a+b` ensemble (highest risk wins); loads only from a LOCAL folder, never the network; overlapping 512-token windows (no truncation evasion); fails closed; the only download code is `python manage.py setup-model` (pinned revision, safetensors/ONNX only, SHA-256 checked) |
| `prompt_log.py` | Your saved test prompts | Every chat prompt is saved (localhost only, capped, de-duplicated, never PII/secrets); you label the correct outcome; feeds the `user` and `combined` evaluation sets |
| `stage2_simulator.py` | Stage 2 (default backend) | Relations not keywords; directedness; negation/prevention; mention discount; persona framing as a *modifier*; defensive wording cannot discount a direct command; noisy-OR |
| `pipeline.py` | The decision authority | `resolve_policy`, `security_decision` (never raises), `run_gateway` |
| `generation.py` | Generation and validation | Generators return **raw text**; strict pydantic model; retry hard-capped at 1 in code |
| `evaluator.py` | Measurement | Calls `security_decision`; error isolation; hash-verified frozen set; never overwrites |
| `main.py` | HTTP | Body-size middleware, explicit CORS, generic errors, sync endpoints |
| `providers_live.py` | Optional paid adapters | Fail loudly; never imported in simulation mode |

## Why Stage 2 is a feature scorer and not a keyword list

The pre-audit simulator did `term in prompt.lower()`: `"dan"` matched *guidance* and *Sudan*, `"override"` matched every Python
question, and a zero-width space beat every rule. The replacement scores *relations*:

```
override verb  ──within 6 tokens──  policy noun        (+ directed at the assistant, not negated, not preventive)
extraction verb ─────────────────── hidden-config noun  (+ possessive / "you were given")
exfiltration verb ────────────────── secret noun        (+ capability or external-recipient cue)
adoption cue ("act as", "pretend") ─ unrestricted term  (+ addressed to the assistant)
embedded instructions to "the assistant" inside content the assistant is asked to process
decoded payloads, re-scored with the same features
```

Each hit has a weight; evidence combines with noisy-OR: `risk = 1 - Π(1 - wᵢ)`. Persona framing multiplies other
evidence but is harmless alone. Defensive/educational wording discounts only weak signals. A test proves that prepending
"for educational purposes..." does not launder a direct command (it did in an intermediate version, and the test caught it).

## Why the risk-policy layer is separate from Stage 2

A prompt-injection classifier answers one question: is this text trying to subvert the assistant? "Send me the trade secret of
the organization" and "erase the main db" are not injections, and the benchmark confirmed that no injection classifier is
the right tool for them (the DeBERTa model caught only 9 of 48 such prompts, the simulator none). They need a different
question (is somebody commanding this system to hand over or destroy something that matters?), different rules, and a policy
the operator can set per category. Keeping it separate means it behaves identically whichever Stage 2 backend is configured.

## Trade-offs

| Decision | Why | Cost |
|---|---|---|
| Fail closed on classifier error (ERROR, not pass) | A security gateway that silently allows on failure is worse than one that is unavailable | Availability depends on Stage 2 |
| Uncertain band flagged, not blocked, by default | Avoids over-blocking dual-use security questions | Some risky prompts pass with a flag; strict mode is one setting away |
| Block on any structurally valid SSN / real-looking email | Cannot tell real from fake without context | Over-blocks some legitimate pasted data; documented test data is exempt |
| Server owns policy | A client that can disable checks is not a control | The UI cannot weaken settings unless the operator opts in |
| Stage 1 kept small | Regex lists cannot enumerate attacks and overfit benchmarks | Recall depends on Stage 2 |
| Mock generator | Free, deterministic, testable failure modes | No real answers; clearly labelled |
| Model is opt-in, not the default | The core demo must run free, offline, with no 740 MB download | Out of the box you get the weaker simulator unless you run `setup-model` |
| Model reads the prompt in overlapping windows, fails closed if more than the configured windows are needed | Truncating at 512 tokens lets an attacker pad past the model's context | Very long prompts return ERROR instead of a verdict |
