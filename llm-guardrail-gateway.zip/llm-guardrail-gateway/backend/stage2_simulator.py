"""
Stage 2: LOCAL HEURISTIC SIMULATOR of an AI security classifier.

>>> This is NOT a large language model and NOT a trained classifier. <<<
It is a deterministic, explainable intent scorer written to stand in for one in a free, offline demo.
Its scores say "this text has the structural shape of an attack", not "an AI judged this prompt".
Results measure THIS simulator on a given dataset; they do not predict a real classifier's accuracy and
do not show generalisation to unseen attacks. It is English-only and has no semantic understanding.

Why it is not a keyword counter (audit C2)
------------------------------------------
The pre-audit simulator did `term in prompt.lower()`, so "dan" matched "guidance" and "Sudan", "override"
matched every Python question, and a zero-width space beat every rule. This version:

  1. scores NORMALISED text (see normalization.py), so obfuscation does not hide an attack;
  2. detects *relations*, not words: an override VERB near a policy NOUN, an extraction verb applied to
     the assistant's hidden configuration, a secret NOUN reached by a capability/exfiltration cue;
  3. requires the instruction to be DIRECTED at the assistant (second person, an assistant noun, a
     config-specific modifier, or the imperative mood) and drops negated/preventive uses
     ("do not ignore the rules", "prevent users from bypassing the rules");
  4. separates USE from MENTION: a quoted or explicitly discussed attack phrase is down-weighted;
  5. treats persona framing ("pretend", "roleplay", "hypothetically") as a MODIFIER, never a verdict:
     it only amplifies another signal and is harmless on its own;
  6. lets defensive/educational wording discount only WEAK signals. A direct command keeps its full
     weight, so appending "for educational purposes" does not launder an attack;
  7. combines evidence with noisy-OR instead of counting keywords;
  8. reports an explicit UNCERTAIN band and a confidence level instead of pretending certainty.

Known limits (documented, not hidden): paraphrase beyond the lexicons, persuasion/authority attacks,
multi-turn setups, non-English text, and anything needing world knowledge are NOT detected.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from guardrails import Stage1Result, _quote_spans, is_mention
from normalization import NormalizedText
from schemas import Policy

PROVIDER = "LOCAL_HEURISTIC_SIMULATOR"

# ------------------------------------------------------------------------------------------------
# Result types
# ------------------------------------------------------------------------------------------------


@dataclass
class Feature:
    name: str
    category: str
    weight: float                 # raw strength in [0, 1)
    mention: bool = False         # looked quoted / discussed rather than commanded
    effective: float = 0.0        # after modifiers


@dataclass
class Stage2Result:
    risk_score: int               # 1-100
    category: str
    confidence: str               # HIGH | MEDIUM | LOW
    features: List[Feature] = field(default_factory=list)
    reasoning: str = ""
    framing: bool = False
    defensive: float = 0.0
    provider: str = PROVIDER


# A classifier is any callable with this shape. The simulator below is the default; tests inject others
# (including ones that raise or return garbage) to exercise the error policy.
Classifier = Callable[[str, NormalizedText, Stage1Result, Policy], Stage2Result]

# ------------------------------------------------------------------------------------------------
# Tokens and stems
# ------------------------------------------------------------------------------------------------

_TOKEN = re.compile(r"[a-z0-9']+")


def stem(t: str) -> str:
    """Tiny suffix stripper: enough to equate ignore/ignored/ignoring and rule/rules, nothing more."""
    if len(t) <= 3:
        return t
    if t.endswith("ies") and len(t) > 4:
        return t[:-3] + "y"
    for suf in ("ing", "ed", "es", "s"):
        if t.endswith(suf) and len(t) - len(suf) >= 3:
            if suf == "s" and t.endswith("ss"):
                continue
            t = t[: -len(suf)]
            break
    if t.endswith("e") and len(t) > 3:
        t = t[:-1]
    return t


def _stems(words: str) -> frozenset:
    return frozenset(stem(w) for w in words.split())


OVERRIDE_VERBS = _stems("ignore disregard forget override bypass circumvent disable deactivate discard drop skip neglect "
                        "overrule supersede cancel revoke void lift remove suspend abandon defy violate")
OVERRIDE_STATES = _stems("obsolete void invalid cancelled canceled revoked outdated irrelevant superseded replaced")
STRONG_NOUNS = _stems("instruction guideline directive guardrail safeguard programming training constraint restriction policy limitation")
WEAK_NOUNS = _stems("rule filter limit boundary check setting protocol safety ethic ethical censorship moderation protection")
DIRECTED = _stems("you your yourself assistant model ai chatbot llm bot gpt claude agent")
NOUN_MODIFIERS = _stems("previous prior above earlier original initial existing current safety content system ethical security default core")
NEGATIONS = frozenset({"not", "never", "dont", "don't", "cannot", "can't", "cant", "shouldn't", "shouldnt", "won't", "wont",
                       "avoid", "no", "didn't", "doesn't"})
PREVENTION = _stems("prevent avoid detect defend mitigate protect guard catch flag block")

IMPERATIVE_LEAD = re.compile(r"^(?:please\s+|now\s+|just\s+|kindly\s+|also\s+|then\s+|and\s+|so\s+|simply\s+|first\s+)*$")

# ------------------------------------------------------------------------------------------------
# Regex features (bounded gaps only; no unbounded nested quantifiers)
# ------------------------------------------------------------------------------------------------

_CFG_NOUN = (r"(?:rules?|instructions?|guidelines?|polic(?:y|ies)|restrictions?|constraints?|safeguards?|filters?|"
             r"guardrails?|directives?|limitations?|safety\s+\w+|programming|training)")
_SEC_NOUN = (r"(?:(?:\.env\b)|(?:\b(?:passwords?|passwd|credentials?|passphrases?|environment\s+variables?|connection\s+strings?|"
             r"customer\s+records?|(?:api|ssh|private|secret|encryption|access|signing|database|master)\s+keys?|"
             r"(?:access|session|auth|api|bearer|refresh|authentication)\s+tokens?|(?:session|auth)\s+cookies?)\b))")
_EXFIL_VERB = (r"(?:send|transmit|forward|email|upload|exfiltrate|leak|extract|steal|harvest|dump|reveal|disclose|retrieve|fetch|"
               r"grab|collect|print|output|list|show|find|read|paste|give|share|include|copy|expose|post|display)")
_STRONG_EXFIL_VERB = r"(?:send|transmit|forward|email|upload|exfiltrate|leak|steal|harvest|dump|post)"
_CAPABILITY = (r"(?:\byou\s+(?:have|can|could|are\s+(?:configured|given|able)|were\s+(?:given|configured)|hold|know)\b|"
               r"\bavailable\s+to\s+you\b|\byour\s+(?:environment|memory|context|tools?|configuration|config|system|disk|server|files?|access)\b|"
               r"\bstored\b|\bin\s+the\s+environment\b|\bconfigured\s+with\b|\bother\s+users?\b|"
               r"\b(?:production|prod|internal|company|corporate|admin(?:istrator)?|root|master|customer|database)\b)")
_EXTERNAL = (r"(?:\bto\s+me\b|\bto\s+my\s+\w+|\bto\s+(?:an?\s+)?(?:external|remote|third[- ]party)\b|"
             r"\bto\s+(?:this|that|the)\s+(?:url|address|server|webhook|endpoint|link)\b|https?://|\bto\s+(?:the\s+)?attacker\b|"
             r"\bmy\s+(?:webhook|server|endpoint)\b)")
_EXTRACT_OBJ = (r"(?:(?:your|the|this)\s+)?(?:(?:system|initial|original|hidden|secret|confidential|internal|private|developer|"
                r"underlying|full|entire|exact)\s+){1,3}(?:prompts?|messages?|instructions?|configurations?|configs?|context|rules?|"
                r"guidelines?|directives?|setup|text)")
_EXTRACT_VERB = (r"(?:reveal|print|repeat|output|echo|recite|disclose|leak|expose|dump|display|paste|quote|reproduce|show|"
                 r"tell\s+me|give\s+me|summari[sz]e|state|share|provide|copy|list)")
_STRONG_EXTRACT_VERB = r"(?:reveal|print|repeat|output|echo|recite|disclose|leak|expose|dump|display|paste|quote|reproduce)"

# (name, category, regex, weight)
_REGEX_FEATURES: List[Tuple[str, str, "re.Pattern[str]", float]] = []


def _rx(name: str, category: str, pattern: str, weight: float) -> None:
    _REGEX_FEATURES.append((name, category, re.compile(pattern), weight))


# --- instruction override: multiword structures -----------------------------------------------
_rx("override_forget_told", "INSTRUCTION_OVERRIDE",
    r"\b(?:forget|ignore|disregard|discard|drop)\s+(?:everything|anything|all(?:\s+of)?\s+(?:that|what))\s+(?:that\s+)?(?:you(?:'ve|\s+have)?\s+)?"
    r"(?:were\s+|was\s+|been\s+|have\s+been\s+)?(?:told|given|taught|instructed|said|trained|learned)", 0.78)
_rx("override_stop_following", "INSTRUCTION_OVERRIDE",
    r"\b(?:stop|quit|cease)\s+(?:following|obeying|using|applying|respecting)\s+(?:your|the|any|all|those|these)\b", 0.72)
_rx("override_set_aside", "INSTRUCTION_OVERRIDE",
    r"\b(?:set\s+aside|pay\s+no\s+attention\s+to|turn\s+off|switch\s+off|do\s+not\s+follow|don't\s+follow|do\s+not\s+obey|"
    r"don't\s+obey|no\s+longer\s+(?:apply|applies|binding|valid))\b(?:\s+\S+){0,3}?\s+" + _CFG_NOUN, 0.72)
_rx("override_priority", "INSTRUCTION_OVERRIDE",
    r"\b(?:higher[- ]priority|takes?\s+precedence|supersedes?|overrides?\s+(?:all|any|every))\b.{0,60}?\b" + _CFG_NOUN, 0.72)
_rx("override_declared_void", "INSTRUCTION_OVERRIDE",
    r"\b(?:previous|earlier|prior|original|old|your)\s+(?:\w+\s+)?" + _CFG_NOUN +
    r"\s+(?:are|is|were)\s+(?:now\s+)?(?:obsolete|void|invalid|cancel\w*|revoked|null|outdated|irrelevant|replaced|superseded|a\s+test)\b", 0.72)
_rx("override_above_ignored", "INSTRUCTION_OVERRIDE",
    r"\b(?:instructions?|rules?|guidelines?)\s+above\b.{0,40}?\b(?:ignored|disregarded|void|obsolete|a\s+test)\b", 0.7)
_rx("override_new_directive", "INSTRUCTION_OVERRIDE",
    r"\b(?:new|updated|revised)\s+(?:instructions?|directives?|rules?|system\s+prompt|configuration)\s*:.{0,80}?"
    r"\b(?:you\s+(?:must|will|should|shall|are\s+to)|from\s+now\s+on|always\s+(?:comply|obey|answer)|your\s+(?:earlier|previous|old))", 0.68)
_rx("override_from_now_on", "INSTRUCTION_OVERRIDE",
    r"\bfrom\s+(?:now|this\s+point)\s+on\b.{0,60}?\b(?:ignore|without|no\s+(?:rules|restrictions|limits)|only\s+(?:what|follow)|obey|comply|operate\s+without)", 0.66)
_rx("override_pretend_policy_gone", "INSTRUCTION_OVERRIDE",
    r"\b(?:pretend|imagine|suppose|assume)\s+(?:that\s+)?(?:the\s+|your\s+)?(?:content\s+|safety\s+)?"
    r"(?:polic(?:y|ies)|rules?|restrictions?|guidelines?|filters?|guardrails?|checks?)\s+(?:do(?:es)?\s+not|don't|doesn't|never)\s+(?:exist|apply|matter)", 0.7)
_rx("override_counterfactual", "INSTRUCTION_OVERRIDE",
    r"\b(?:if|suppose|assuming|imagine)\s+(?:that\s+)?your\s+(?:\w+\s+){0,2}?" + _CFG_NOUN +
    r"\s+(?:did(?:n't|\s+not)|do(?:es)?(?:n't|\s+not)|were(?:n't|\s+not)|was(?:n't|\s+not)|no\s+longer)\s+(?:apply|exist|matter|in\s+place)", 0.6)
# --- privilege / unrestricted persona ---------------------------------------------------------
_rx("persona_named_jailbreak", "DIRECT_JAILBREAK",
    r"\byou\s+(?:are|will\s+be|have\s+become|have\s+been)\s+(?:now\s+)?(?:an?\s+|in\s+|the\s+)?(?:\w+\s+){0,3}?"
    r"(?:dan|stan|godmode|god\s+mode|developer\s+mode|jailbreak\s+mode)\b", 0.75)
_rx("persona_mode_switch", "DIRECT_JAILBREAK",
    r"\b(?:enable|activate|enter|switch\s+to|turn\s+on|go\s+into)\s+(?:your\s+|the\s+)?(?:\w+\s+){0,2}?"
    r"(?:developer|jailbreak|god|unrestricted|uncensored|maintenance|admin|sudo|root|debug)\s+(?:mode|persona|access)\b"
    r".{0,100}?\b(?:ignore|bypass|without|no\s+(?:rules|restrictions|limits)|any\s+request|every\s+request|disable|polic\w+|safety|filter\w*|censor\w*)", 0.76)
_rx("safety_mode_off", "DIRECT_JAILBREAK",
    r"\b(?:safety|content|ethic\w*)\s+(?:mode|filter\w*|polic\w+|checks?|guardrails?)\s+(?:is\s+|are\s+)?(?:off|disabled|removed|deactivated|turned\s+off)\b|"
    r"\broot\s+access\s+granted\b", 0.72)
_rx("freed_from_limits", "DIRECT_JAILBREAK",
    r"\bwithout\s+(?:any\s+)?(?:of\s+)?(?:the\s+|your\s+)?(?:limitations?|restrictions?|filters?|rules?|guidelines?|ethical\s+constraints?|censorship)\b"
    r"\s+(?:your\s+)?(?:creators?|developers?|makers?)\s+(?:placed|put|set|imposed)", 0.72)
_rx("never_refuse", "DIRECT_JAILBREAK",
    r"\byou\b.{0,60}?\b(?:never\s+refuse|do\s+anything\s+now|can\s+do\s+anything|answer\s+(?:every|any|all)\s+(?:request|question)s?)\b", 0.66)
_rx("authority_claim", "DIRECT_JAILBREAK",
    r"\b(?:i\s*(?:am|'m)|as)\s+(?:your|the)\s+(?:admin\w*|developer|creator|owner|operator|maker)\b", 0.35)
_rx("authority_order", "INDIRECT_INJECTION",
    r"\b(?:as|i\s*(?:am|'m))\s+your\s+(?:developer|creator|admin\w*|owner)\b.{0,40}?\b(?:order|command|instruct|demand|tell)\w*\s+you\b", 0.62)
# --- prompt extraction -------------------------------------------------------------------------
_rx("prompt_extraction_strong", "PROMPT_EXTRACTION",
    r"\b" + _STRONG_EXTRACT_VERB + r"\b(?:\s+\S+){0,6}?\s+(?:(?:your|the|this)\s+)?(?:(?:system|initial|original|hidden|secret|"
    r"confidential|internal|private|developer|underlying|exact)\s+){1,3}(?:prompts?|messages?|instructions?|configurations?|configs?|context|rules?|guidelines?|directives?|setup)", 0.76)
_rx("prompt_extraction_possessive", "PROMPT_EXTRACTION",
    r"\b" + _EXTRACT_VERB + r"\b(?:\s+\S+){0,6}?\s+your\s+(?:(?:system|initial|original|hidden|secret|confidential|internal|developer|underlying)\s+){0,2}"
    r"(?:prompts?|instructions?|configurations?|configs?|context|rules?|guidelines?|setup)", 0.74)
_rx("prompt_extraction_generic", "PROMPT_EXTRACTION",
    r"\b" + _STRONG_EXTRACT_VERB + r"\b(?:\s+\S+){0,6}?\s+(?:the\s+)?system\s+(?:prompts?|messages?)", 0.5)
_rx("prompt_extraction_given", "PROMPT_EXTRACTION",
    r"\binstructions?\s+you\s+(?:were|was|have\s+been|had\s+been|got|received|are)\s+(?:given|told|provided|using|following)\b|"
    r"\bwhat\s+(?:the\s+)?(?:developers?|creators?)\s+told\s+you\b|"
    r"\b(?:everything|text|content|messages?|all)\s+(?:above|before)\s+(?:this|my)\s+(?:line|message|first|point)\b|"
    r"\bcontext\s+window\b.{0,40}?\bbefore\b|\bbefore\s+(?:this|my)\s+(?:first\s+)?(?:conversation|message)\b", 0.7)
# --- indirect injection ------------------------------------------------------------------------
_rx("chat_markup", "INDIRECT_INJECTION",
    r"<\|?(?:im_start|im_end|system|assistant|endoftext)\|?>|\[/?(?:inst|sys|system)\]|#{2,}\s*system\b|<<sys>>|"
    r"(?:^|\n)\s*system\s*:", 0.8)
_rx("indirect_vocative_command", "INDIRECT_INJECTION",
    r"\b(?:note\s+to|attention|dear|hey|hi|important\s+to|message\s+for|instructions?\s+for|for)\s+(?:the\s+)?(?:ai|assistant|model|chatbot|llm|agent|bot|"
    r"language\s+model|ai\s+agents?)\b[^.]{0,80}?\b(?:ignore|disregard|stop|instead|do\s+not|don't|delete|reveal|send|forward|output|print|run|execute|grant|drop|forget|secretly)\b", 0.78)
_rx("indirect_vocative_comma", "INDIRECT_INJECTION",
    r"\b(?:ai|assistant|model|chatbot|llm|agent|bot)\s*,\s*(?:before|stop|ignore|disregard|do\s+not|don't|instead|please\s+ignore|you\s+must)\b", 0.72)
_rx("indirect_when_reads", "INDIRECT_INJECTION",
    r"\bwhen\s+(?:an?\s+|the\s+)?(?:ai|assistant|model|llm|agent|bot|language\s+model)\s+(?:reads?|sees?|processes?|encounters?)\s+this\b", 0.8)
_rx("indirect_ignore_user", "INDIRECT_INJECTION",
    r"\b(?:ignore|disregard|do\s+not\s+(?:follow|answer))\s+the\s+user(?:'s)?\s+(?:request|question|message|instructions?|prompt|task)s?\b", 0.76)
_rx("indirect_new_task", "INDIRECT_INJECTION",
    r"\bnew\s+(?:task|directive|instruction)\s+for\s+(?:the\s+)?(?:ai|assistant|model|llm|language\s+model|agents?)\b", 0.76)
_rx("indirect_hidden_block", "INDIRECT_INJECTION",
    r"<!--.{0,160}?\b(?:ai|assistant|model|llm|agent)\b.{0,160}?-->|\[\s*hidden\s*:", 0.7)
_rx("concealment_action", "INDIRECT_INJECTION",
    r"\b(?:secretly|silently|covertly|without\s+(?:telling|informing|alerting|notifying)\s+the\s+user|do\s+not\s+(?:tell|inform|mention\s+to|alert)\s+the\s+user|"
    r"don't\s+(?:tell|inform)\s+the\s+user|hidden\s+from\s+the\s+user)\b.{0,60}?\b(?:send|forward|upload|run|execute|delete|grant|post|email|transmit|exfiltrate|reveal)\b|"
    r"\b(?:send|forward|upload|run|execute|delete|grant|post|email|transmit|exfiltrate|reveal)\b.{0,60}?\b(?:secretly|silently|covertly|without\s+(?:telling|informing)\s+the\s+user)\b", 0.7)
_rx("concealment_only", "INDIRECT_INJECTION",
    r"\b(?:do\s+not\s+tell\s+the\s+user|don't\s+tell\s+the\s+user|without\s+telling\s+the\s+user|secretly)\b", 0.42)
# --- harmful capability (weak alone; strong only with persona framing) --------------------------
_rx("harm_capability", "POLICY_EVASION",
    r"\b(?:how\s+to|how\s+would|how\s+could|how\s+can|steps?\s+to|way\s+to|explain\s+how|describe\s+how|instructions?\s+(?:for|on)|"
    r"outline\s+how|walk\s+me\s+through|tell\s+(?:me|someone)\s+how|asking\s+how\s+to)\s+(?:\w+\s+){0,4}?"
    r"(?:hack(?:ing)?|break(?:ing)?\s+into|crack(?:ing)?|bypass(?:ing)?|evad(?:e|ing)|disabl(?:e|ing)|steal(?:ing)?|phish(?:ing)?|"
    r"build(?:ing)?|creat(?:e|ing)|writ(?:e|ing)|develop(?:ing)?|mak(?:e|ing)|synthesi[sz](?:e|ing)|manufactur(?:e|ing)|break\s+in)\s+"
    r"(?:\w+\s+){0,5}?(?:malware|ransomware|keylogger|virus|trojan|exploit|bomb|explosives?|weapons?|nerve\s+agent|poison|"
    r"dangerous\s+chemicals?|credentials?|passwords?|corporate\s+network|login\s+authentication|authentication|antivirus|"
    r"security\s+monitoring|firewalls?|bank|surveillance)", 0.5)
_rx("harm_persona_dangerous", "POLICY_EVASION",
    r"\b(?:recite|read|tell|explain|give)\b.{0,40}?\binstructions?\s+for\s+(?:making|making\s+dangerous|building|synthesi[sz]ing)\b.{0,30}?"
    r"(?:chemicals?|weapons?|explosives?|poison|drugs?)", 0.55)
# --- unrestricted semantics next to the assistant (weak: needs help from persona/framing) -------
_rx("unrestricted_semantics", "DIRECT_JAILBREAK",
    r"\byou\b.{0,60}?\b(?:no\s+(?:rules|restrictions|limits|ethics|filters)|without\s+(?:any\s+)?(?:restrictions?|limits?|filters?|rules|ethics|censorship)|"
    r"uncensored|unfiltered|unrestricted)\b", 0.45)

_FRAMING = re.compile(
    r"\b(?:pretend|imagine|role[- ]?play(?:ing)?|act\s+as|play\s+the\s+role|simulate|hypothetical(?:ly)?|fictional|thought\s+experiment|"
    r"for\s+a\s+(?:novel|story)|in\s+a\s+story|write\s+a\s+story|what\s+if\s+you|let's\s+(?:play|say)|as\s+a\s+character|"
    r"late\s+grandmother)\b")

_DEFENSIVE_CUES = (
    r"\bexplain\b", r"\bdescribe\b", r"\bwhat\s+(?:is|are|does)\b", r"\bhow\s+(?:does|do|can\s+(?:i|we|developers?))\b", r"\bwhy\b",
    r"\bdefin(?:e|ition)\b", r"\boverview\b", r"\bsummari[sz]e\b", r"\bcompare\b", r"\bdifference\s+between\b", r"\bbest\s+practices?\b",
    r"\bguide\b", r"\btutorial\b", r"\bawareness\b", r"\btraining\b", r"\bdefen[cd]\w*\b", r"\bmitigat\w+\b", r"\bprevent\w*\b",
    r"\bdetect\w*\b", r"\bprotect\w*\b", r"\bharden\w*\b", r"\baudit\w*\b", r"\bunit\s+tests?\b", r"\bverify\b", r"\bvalidat\w+\b",
    r"\bresponsibl[ey]\b", r"\bresearch\w*\b", r"\bacademic\w*\b", r"\beducational\b", r"\bchecklist\b", r"\bred[- ]team\w*\b",
    r"\bowasp\b", r"\bsecurity\s+(?:engineer|team|researcher|training)\b", r"\bslides?\b",
)
_DEFENSIVE = [re.compile(p) for p in _DEFENSIVE_CUES]

_SECRET_EXFIL = re.compile(
    r"\b" + _EXFIL_VERB + r"\b(?:\s+\S+){0,8}?\s+(?:(?:the|all|any|every|your|my|their|other)\s+)?(?:\w+\s+){0,3}?" + _SEC_NOUN)
_STRONG_EXFIL = re.compile(r"\b" + _STRONG_EXFIL_VERB + r"\b")
_CAP = re.compile(_CAPABILITY)
_EXT = re.compile(_EXTERNAL)

# ------------------------------------------------------------------------------------------------
# Token-window features
# ------------------------------------------------------------------------------------------------


def _tokens(text: str) -> List[Tuple[str, int, int]]:
    return [(stem(m.group()), m.start(), m.end()) for m in _TOKEN.finditer(text)][:4000]


def _raw_before(text: str, toks: List[Tuple[str, int, int]], i: int, n: int) -> List[str]:
    return [text[toks[k][1]:toks[k][2]] for k in range(max(0, i - n), i)]


def _override_pairs(text: str, toks: List[Tuple[str, int, int]], quotes) -> Optional[Feature]:
    """Override verb x policy noun within 6 tokens, directed at the assistant, not negated/preventive."""
    best: Optional[Feature] = None
    stems = [t[0] for t in toks]
    verbs = [i for i, s in enumerate(stems) if s in OVERRIDE_VERBS]
    nouns = [j for j, s in enumerate(stems) if s in STRONG_NOUNS or s in WEAK_NOUNS]
    for i in verbs:
        before = _raw_before(text, toks, i, 3)
        if any(b in NEGATIONS for b in before):
            continue
        wider = [stems[k] for k in range(max(0, i - 5), i)]
        if any(w in PREVENTION for w in wider):
            continue
        for j in nouns:
            gap = j - i
            order = 1.0
            if gap < 0:
                gap, order = -gap, 0.8                      # noun before verb: "the rules are void"
            if not 1 <= gap <= 6:
                continue
            lo, hi = max(0, min(i, j) - 4), min(len(toks), max(i, j) + 5)
            directed = any(stems[k] in DIRECTED for k in range(lo, hi))
            modified = any(stems[k] in NOUN_MODIFIERS for k in range(max(0, j - 3), j))
            lead = text[_sentence_start(text, toks[i][1]):toks[i][1]].lower()
            imperative = bool(IMPERATIVE_LEAD.match(lead))
            strong = stems[j] in STRONG_NOUNS
            ok = (directed or modified or imperative) if strong else (directed or modified)
            if not ok:
                continue
            # A generic noun ("rules", "filters") is weak evidence by itself ("firewall rule"), but "your <noun>" is
            # a direct reference to the assistant's own configuration and is treated as strong.
            possessive = any(stems[k] in ("your", "yourself") for k in range(max(0, j - 2), j))
            weight = (0.78 if (strong or possessive) else 0.62) * order
            span_start, span_end = toks[min(i, j)][1], toks[max(i, j)][2]
            mention = is_mention(text, span_start, span_end, quotes)
            if best is None or weight > best.weight:
                best = Feature("override_instructions", "INSTRUCTION_OVERRIDE", weight, mention)
    return best


def _sentence_start(text: str, pos: int) -> int:
    lo = max(0, pos - 140)
    cut = max((text.rfind(c, lo, pos) for c in ".?!\n;"), default=-1)
    return cut + 1 if cut >= 0 else lo


def _secret_exfiltration(text: str, quotes) -> Optional[Feature]:
    best: Optional[Feature] = None
    for m in _SECRET_EXFIL.finditer(text):
        span_start, span_end = m.span()
        win_lo, win_hi = max(0, span_start - 40), min(len(text), span_end + 100)
        window = text[win_lo:win_hi]
        strong_verb = bool(_STRONG_EXFIL.search(text[span_start:span_start + 12]))
        cue = bool(_CAP.search(window)) or bool(_EXT.search(window))
        if not cue:
            continue
        weight = 0.82 if (strong_verb or _EXT.search(window)) else 0.74
        mention = is_mention(text, span_start, span_end, quotes)
        if best is None or weight > best.weight:
            best = Feature("secret_exfiltration", "DATA_EXFILTRATION", weight, mention)
    return best


# A persona DEFINED BY THE ABSENCE OF RESTRICTIONS, adopted by the assistant. Two ingredients, both required:
#   an ADOPTION cue (be / act as / pretend / simulate / your role is ...) and an UNRESTRICTED term, within one
#   window, in a sentence addressed to the assistant. Either alone is harmless ("You are a helpful assistant";
#   "unrestricted access in Postgres"), which is why this is a relation and not a keyword.
_UNRESTRICTED = re.compile(
    r"\b(?:unrestricted|uncensored|unfiltered|jailbroken|jailbreak\s+mode|"
    r"no\s+(?:rules?|restrictions?|limitations?|ethics|morals?|filters?|guardrails?|scruples|censorship|limits?(?!\s+(?:on|for|in|to|of)\b))|"
    r"(?:without|free\s+from|freed\s+from|liberated\s+from|released\s+from)\s+(?:any\s+|all\s+|its\s+|your\s+|the\s+)?(?:of\s+)?"
    r"(?:its\s+|your\s+|the\s+)?(?:rules?|restrictions?|limits?|limitations?|ethics|morals?|filters?|guardrails?|censorship|guidelines?|constraints?|programming)|"
    r"never\s+refus\w*|avoid\s+the\s+norms|do\s+anything\s+now)\b")
_ADOPT = re.compile(
    r"\b(?:you\s+are|you're|you\s+will\s+be|you\s+have\s+(?:become|been)|act(?:ing)?\s+as|behave\s+(?:as|like)|respond\s+as|answer\s+as|"
    r"operate\s+as|pretend|become|imagine|role[- ]?play|play\s+(?:a|an|the)|simulate|your\s+(?:new\s+)?(?:role|persona|identity)\s+is|"
    r"activate\s+your|enable\s+your|persona|character|as\s+an?\s+(?:\w+\s+){0,2}?(?:model|ai|assistant|chatbot|bot)|"
    r"an?\s+(?:ai|assistant|model|chatbot|terminal|system)\s+(?:that|who|which|called|named))\b")
_ADDRESSED = re.compile(r"\b(?:you|your|yourself|assistant|ai|model|chatbot|llm|bot|terminal)\b")


def _unrestricted_persona(text: str, quotes) -> Optional[Feature]:
    best: Optional[Feature] = None
    for m in _UNRESTRICTED.finditer(text):
        lo, hi = max(0, m.start() - 90), min(len(text), m.end() + 90)
        window = text[lo:hi]
        if not _ADOPT.search(window):
            continue
        sent = text[_sentence_start(text, m.start()):m.end() + 60]
        if not _ADDRESSED.search(sent) and not _ADDRESSED.search(window):
            continue
        before = text[max(0, m.start() - 24):m.start()]
        if re.search(r"\b(?:not|never|don't|dont|avoid|prevent|against)\s+(?:\w+\s+){0,2}$", before):
            continue
        weight = 0.72
        mention = is_mention(text, m.start(), m.end(), quotes)
        if best is None or weight > best.weight or (best.mention and not mention):
            best = Feature("unrestricted_persona", "DIRECT_JAILBREAK", weight, mention)
    return best


# ------------------------------------------------------------------------------------------------
# Feature extraction
# ------------------------------------------------------------------------------------------------


def extract_features(text: str) -> Tuple[List[Feature], bool]:
    """Features for ONE normalised string. Returns (features, framing_present)."""
    quotes = _quote_spans(text)
    feats: List[Feature] = []
    toks = _tokens(text)
    f = _override_pairs(text, toks, quotes)
    if f:
        feats.append(f)
    f = _secret_exfiltration(text, quotes)
    if f:
        feats.append(f)
    f = _unrestricted_persona(text, quotes)
    if f:
        feats.append(f)
    for name, category, rx, weight in _REGEX_FEATURES:
        m = rx.search(text)
        if m:
            feats.append(Feature(name, category, weight, is_mention(text, m.start(), m.end(), quotes)))
    return feats, bool(_FRAMING.search(text))


def _noisy_or(values: List[float]) -> float:
    p = 1.0
    for v in values:
        p *= (1.0 - min(max(v, 0.0), 0.99))
    return 1.0 - p


def _defensive_score(text: str) -> float:
    n = sum(1 for rx in _DEFENSIVE if rx.search(text))
    return min(1.0, 0.2 * n)


MENTION_SCALE = 0.35
FRAMING_BOOST = 0.30
OBFUSCATION_WEIGHT = 0.30
OPAQUE_EXEC_WEIGHT = 0.35
DECODED_SCALE = 0.95
BASELINE_RISK = 0.03


def classify(prompt: str, norm: NormalizedText, stage1: Stage1Result, policy: Policy) -> Stage2Result:
    """The default Stage 2 classifier (simulator). Pure function of its inputs; never raises on text."""
    text = norm.text
    feats, framing = extract_features(text)

    # ---- encoded payloads: analyse decoded text with the same extractor --------------------
    decoded_feats: List[Feature] = []
    for seg in norm.decoded:
        if seg.encoding == "rot13":
            continue
        sub, _ = extract_features(seg.text)
        for s in sub:
            decoded_feats.append(Feature("encoded_" + s.name, "ENCODED_PAYLOAD", s.weight * DECODED_SCALE, False))
    rot = next((s for s in norm.decoded if s.encoding == "rot13"), None)
    if rot is not None:
        rsub, _ = extract_features(rot.text)
        own = _noisy_or([x.weight for x in feats])
        rot_score = _noisy_or([x.weight for x in rsub])
        if rot_score >= 0.6 and rot_score > own:
            decoded_feats.extend(Feature("encoded_rot13_" + s.name, "ENCODED_PAYLOAD", s.weight * DECODED_SCALE, False) for s in rsub)
    feats.extend(decoded_feats)
    if norm.opaque_blob and not decoded_feats and re.search(r"\b(?:decode|decrypt|deobfuscate|decipher|eval|execute|run|follow|obey)\b", text):
        if not norm.decoded or all(d.encoding == "rot13" for d in norm.decoded):
            feats.append(Feature("decode_execute_opaque", "ENCODED_PAYLOAD", OPAQUE_EXEC_WEIGHT, False))
    if norm.obfuscation_suspected:
        feats.append(Feature("obfuscation_artifacts", "ENCODED_PAYLOAD", OBFUSCATION_WEIGHT, False))

    defensive = _defensive_score(text)

    # ---- effective weights ------------------------------------------------------------------
    for f in feats:
        w = f.weight * (MENTION_SCALE if f.mention else 1.0)
        # Defensive framing discounts only WEAK, non-command evidence. A strong command keeps full weight.
        if w < 0.6 or f.mention:
            w *= (1.0 - 0.5 * defensive)
        f.effective = w
    # Stage 1's SUSPICIOUS verdict deliberately adds NO prior here: every soft signal it saw is also a
    # Stage 2 feature, and counting it twice would push discussed-but-harmless text into the uncertain band.
    live =[f for f in feats if f.effective > 0.0]
    core = _noisy_or([f.effective for f in live])
    risk = core
    if framing and core >= 0.25:
        risk = 1.0 - (1.0 - risk) * (1.0 - FRAMING_BOOST)
    if not live:
        risk = BASELINE_RISK

    score = max(1, min(100, int(round(risk * 100))))

    # ---- category / confidence / reasoning ---------------------------------------------------
    top = max(live, key=lambda f: f.effective) if live else None
    category = top.category if top and score >= policy.uncertain_low else "BENIGN"
    if framing and top and top.category in ("POLICY_EVASION", "DIRECT_JAILBREAK") and score >= policy.uncertain_low:
        category = "POLICY_EVASION"
    strong_use = any(f.effective >= 0.6 and not f.mention for f in live)
    if not live:
        confidence = "HIGH"
    elif strong_use and score > policy.risk_threshold + 10:
        confidence = "HIGH"
    elif policy.uncertain_low - 5 <= score <= policy.risk_threshold + 5:
        confidence = "LOW"
    else:
        confidence = "MEDIUM"
    names = [f.name for f in sorted(live, key=lambda f: -f.effective)][:6]
    reasoning = (f"Heuristic simulator (not an LLM): "
                 + (f"evidence [{', '.join(names)}]" if names else "no attack-shaped structure found")
                 + (", persona framing amplified it" if framing and core >= 0.25 else "")
                 + (f", defensive/educational wording discounted weak signals" if defensive >= 0.4 and live else "")
                 + f" -> risk {score}/100.")
    return Stage2Result(score, category, confidence, live, reasoning, framing, defensive)


# Convenience for callers that only have text (tests, dataset tooling).
def classify_text(prompt: str, policy: Optional[Policy] = None) -> Stage2Result:
    from guardrails import analyze_stage1
    from normalization import normalize

    policy = policy or Policy()
    norm = normalize(prompt)
    return classify(prompt, norm, analyze_stage1(prompt, policy, norm), policy)
