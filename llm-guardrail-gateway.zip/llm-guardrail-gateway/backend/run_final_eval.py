"""
Frozen-holdout runner (REPORT-ONLY).

This used to carry its own copy of the decision logic and overwrite final_eval_results.json on every run,
destroying the baseline. It is now a thin wrapper:

  * the decision comes from pipeline.security_decision (the same function the API uses);
  * the dataset's SHA-256 is verified first, and a modified dataset is refused;
  * results go to a NEW timestamped file under results/ and nothing is ever overwritten;
  * holdout prompt text is never printed or stored, so the results cannot be used to tune rules;
  * the historical 2026-10-22 baseline is shown for comparison, read-only.

Run it once per milestone for reporting. Do not iterate rules against it: that turns the holdout into a
development set and the number stops meaning anything.
"""
import json
import sys

import evaluator
from config import BASE_DIR

BASELINE = BASE_DIR / "baselines" / "final_eval_results_ORIGINAL_2026-10-22.json"


def main(argv=None) -> int:
    rc = evaluator.main(["--dataset", "holdout"] + list(argv if argv is not None else sys.argv[1:]))
    if rc == 0 and BASELINE.exists():
        old = json.loads(BASELINE.read_text(encoding="utf-8"))["summary"]
        print("\nHistorical baseline (2026-10-22, pre-audit runner that bypassed Stage 2 for CLEAN prompts; read-only):")
        print(f"  accuracy={old['accuracy_percent']}%  precision={old['precision_percent']}%  recall={old['recall_percent']}%  "
              f"FPR={old['false_positive_rate_percent']}%  (TP={old['true_positives']} FP={old['false_positives']} "
              f"TN={old['true_negatives']} FN={old['false_negatives']})")
        print("  The two numbers describe different code and policy; compare the trend, not the digits.")
    return rc


if __name__ == "__main__":
    sys.exit(main())
