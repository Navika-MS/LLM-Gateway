"""
Shared test fixtures.

Hermetic by construction: before anything imports `config`, the environment is scrubbed of every GATEWAY_*
variable and .env loading is disabled, so a developer's real .env (which may hold a live API key) is never
read and local settings cannot change test outcomes. No test makes a network call.
"""
import os
import sys
from pathlib import Path

os.environ["GATEWAY_SKIP_DOTENV"] = "1"
for _k in list(os.environ):
    if _k.startswith("GATEWAY_") and _k != "GATEWAY_SKIP_DOTENV":
        del os.environ[_k]
for _k in ("STAGE2_RISK_THRESHOLD", "ANTHROPIC_API_KEY", "HOST", "PORT"):
    os.environ.pop(_k, None)

# The prompt list must never touch the developer's real backend/data folder from a test run.
import tempfile  # noqa: E402

os.environ["GATEWAY_DATA_DIR"] = tempfile.mkdtemp(prefix="guardrail-test-data-")

BACKEND = Path(__file__).resolve().parent.parent
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

import dataclasses  # noqa: E402

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

import config  # noqa: E402
import main  # noqa: E402
import pipeline  # noqa: E402
from config import settings  # noqa: E402
from schemas import Policy  # noqa: E402


@pytest.fixture()
def policy() -> Policy:
    return Policy()


@pytest.fixture()
def client():
    main.app.state.classifier = None
    main.app.state.generator = None
    return TestClient(main.app, raise_server_exceptions=False)


@pytest.fixture()
def with_settings(monkeypatch):
    """Replace the settings object seen by main/pipeline for ONE test (settings is frozen)."""
    def apply(**changes):
        new = dataclasses.replace(settings, **changes)
        monkeypatch.setattr(main, "settings", new)
        monkeypatch.setattr(pipeline, "settings", new)
        monkeypatch.setattr(config, "settings", new)          # prompt_log / evaluator read config.settings at call time
        return new
    return apply


def decide(prompt: str, **policy_changes):
    """Convenience: the shared decision function under a (possibly modified) default policy."""
    return pipeline.security_decision(prompt, Policy(**policy_changes))
