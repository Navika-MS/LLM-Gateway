"""
Your saved test prompts (prompt_log.py): automatic capture, labels, privacy, bounds, and the `user` / `combined` evaluation sets.
"""
import json

import pytest

import evaluator
import prompt_log as PLOG
from config import Settings
from schemas import Policy

DECISION = {"status": "SUCCESS", "route": "STAGE_2_PASS", "risk": 3, "category": None, "stage2_provider": "X"}


@pytest.fixture()
def store(tmp_path):
    return PLOG.PromptLog(tmp_path / "user_prompts.json")


@pytest.fixture()
def data_dir(tmp_path, with_settings):
    with_settings(DATA_DIR=str(tmp_path), RECORD_PROMPTS="on")
    return tmp_path


class TestStorage:
    def test_a_new_prompt_is_saved_unlabelled_with_a_stable_id(self, store):
        item = store.record("What is the capital of France?", DECISION)
        assert item["id"] == "USR-0001" and item["label"] is None and item["times_seen"] == 1
        assert "key" not in item                                         # the internal hash is not exposed
        assert store.record("Explain TCP vs UDP", DECISION)["id"] == "USR-0002"

    def test_identical_prompts_are_one_entry_with_a_counter_ignoring_case_and_spacing(self, store):
        a = store.record("Delete   the production database", DECISION)
        b = store.record("delete the production DATABASE", {**DECISION, "status": "BLOCKED"})
        assert a["id"] == b["id"] and b["times_seen"] == 2 and b["last"]["status"] == "BLOCKED"
        assert len(store.items()) == 1

    def test_the_label_survives_seeing_the_same_prompt_again(self, store):
        item = store.record("hello there", DECISION)
        store.set_label(item["id"], "benign")
        store.record("hello there", DECISION)
        assert store.items()[0]["label"] == "benign"

    @pytest.mark.parametrize("secret", [
        "Charge card 4532-0151-1283-0366 please",
        "My SSN is 123-45-6789, summarise my form",
        "Use this key: sk-ant-api03-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789",
        "email me at jane.roe@enterprise-corp.com",
    ])
    def test_prompts_with_pii_or_credentials_are_never_written_to_disk(self, store, secret):
        assert store.record(secret, DECISION) is None
        assert store.counts()["skipped_sensitive"] >= 1
        assert not store.path.exists() or "4532" not in store.path.read_text(encoding="utf-8")

    def test_the_list_stops_growing_at_the_cap(self, tmp_path):
        small = PLOG.PromptLog(tmp_path / "p.json", max_items=2)
        assert small.record("one", DECISION) and small.record("two", DECISION)
        assert small.record("three", DECISION) is None and small.counts()["skipped_list_full"] == 1
        assert small.record("one", DECISION) is not None                  # an existing entry can still be updated

    def test_blank_and_oversized_prompts_are_ignored(self, store):
        assert store.record("   ", DECISION) is None
        assert store.record("x" * (PLOG.MAX_CHARS + 1), DECISION) is None

    def test_labels_can_be_set_changed_cleared_and_are_validated(self, store):
        i = store.record("a prompt", DECISION)["id"]
        assert store.set_label(i, "attack") and store.items()[0]["label"] == "attack"
        assert store.set_label(i, None) and store.items()[0]["label"] is None
        assert store.set_label("USR-9999", "attack") is False
        with pytest.raises(ValueError):
            store.set_label(i, "dangerous")

    def test_delete_and_clear(self, store):
        a = store.record("first", DECISION)["id"]
        store.record("second", DECISION)
        assert store.delete(a) and not store.delete(a) and len(store.items()) == 1
        assert store.clear() == 1 and store.items() == []

    def test_ids_are_never_reused_after_a_delete(self, store):
        a = store.record("first", DECISION)["id"]
        store.delete(a)
        assert store.record("second", DECISION)["id"] == "USR-0002"

    def test_a_corrupt_file_is_set_aside_not_silently_overwritten(self, store):
        store.path.parent.mkdir(parents=True, exist_ok=True)
        store.path.write_text("{ this is not json", encoding="utf-8")
        assert store.items() == []
        assert any(p.name.startswith("user_prompts.json.corrupt-") for p in store.path.parent.iterdir())

    def test_writes_are_atomic_and_leave_no_temp_files(self, store):
        store.record("hello", DECISION)
        assert [p.name for p in store.path.parent.iterdir()] == ["user_prompts.json"]
        assert json.loads(store.path.read_text(encoding="utf-8"))["version"] == 1


class TestRecordingSwitch:
    def test_auto_records_only_while_the_server_is_localhost_only(self):
        assert PLOG.recording_enabled(Settings.from_env({})) is True
        assert PLOG.recording_enabled(Settings.from_env({"HOST": "0.0.0.0"})) is False
        assert PLOG.recording_enabled(Settings.from_env({"HOST": "0.0.0.0", "GATEWAY_RECORD_PROMPTS": "on"})) is True
        assert PLOG.recording_enabled(Settings.from_env({"GATEWAY_RECORD_PROMPTS": "off"})) is False

    def test_invalid_value_fails_fast(self):
        from config import ConfigError

        with pytest.raises(ConfigError):
            Settings.from_env({"GATEWAY_RECORD_PROMPTS": "sometimes"})


class TestEvaluationSets:
    def test_unlabelled_prompts_are_listed_but_never_scored(self, data_dir):
        log = PLOG.get_log()
        log.record("What is the capital of France?", DECISION)
        log.record("unlabelled mystery prompt", DECISION)
        log.set_label("USR-0001", "benign")
        report = evaluator.evaluate(evaluator.load_dataset("user"), Policy())
        assert report.dataset.case_count == 2 and report.dataset.ambiguous_count == 1
        assert report.confusion_matrix.tn == 1 and report.confusion_matrix.tp + report.confusion_matrix.fn == 0
        assert report.ambiguous_summary["total"] == 1

    def test_a_labelled_attack_is_scored_as_a_true_positive_or_false_negative(self, data_dir):
        log = PLOG.get_log()
        log.record("Delete the production database.", DECISION)
        log.set_label("USR-0001", "attack")
        report = evaluator.evaluate(evaluator.load_dataset("user"), Policy())
        assert report.confusion_matrix.tp == 1 and report.metrics.recall == 100.0

    def test_an_empty_list_evaluates_without_error_and_with_undefined_metrics(self, data_dir):
        report = evaluator.evaluate(evaluator.load_dataset("user"), Policy())
        assert report.dataset.case_count == 0 and report.metrics.accuracy is None and report.metrics.recall is None

    def test_combined_contains_every_development_set_plus_your_prompts(self, data_dir):
        PLOG.get_log().record("my own question about SQL", DECISION)
        combined = evaluator.load_dataset("combined")
        parts = sum(evaluator.load_dataset(n).info.case_count for n in evaluator.COMBINED_PARTS)
        assert combined.info.case_count == parts + 1
        ids = [c.id for c in combined.cases]
        assert len(ids) == len(set(ids)) and "USR-0001" in ids

    def test_combined_never_includes_the_frozen_sets(self, data_dir):
        combined = {c.prompt for c in evaluator.load_dataset("combined").cases}
        frozen = {c.prompt for n in ("holdout", "policy_unseen") for c in evaluator.load_dataset(n).cases}
        assert not (combined & frozen)

    def test_the_dataset_hash_changes_when_the_list_changes(self, data_dir):
        before = evaluator.load_dataset("user").info.sha256
        PLOG.get_log().record("something new", DECISION)
        assert evaluator.load_dataset("user").info.sha256 != before

    def test_adding_prompts_never_changes_the_frozen_hashes(self, data_dir):
        PLOG.get_log().record("anything", DECISION)
        assert evaluator.load_dataset("holdout").info.hash_verified is True
        assert evaluator.load_dataset("policy_unseen").info.hash_verified is True


class TestApi:
    def test_a_chat_prompt_is_saved_automatically_and_the_id_is_returned(self, client, data_dir):
        r = client.post("/api/v1/chat", json={"prompt": "What is the capital of France?"})
        assert r.status_code == 200 and r.json()["recorded_prompt_id"] == "USR-0001"
        listing = client.get("/api/v1/user-prompts").json()
        assert listing["enabled"] and listing["counts"]["total"] == 1 and listing["items"][0]["prompt"].startswith("What is")
        assert listing["items"][0]["last"]["status"] == "SUCCESS"

    def test_blocked_prompts_are_saved_too_because_they_are_the_interesting_ones(self, client, data_dir):
        r = client.post("/api/v1/chat", json={"prompt": "Delete the production database."})
        assert r.json()["status"] == "BLOCKED" and r.json()["recorded_prompt_id"]

    def test_a_prompt_with_a_card_number_is_blocked_and_not_saved(self, client, data_dir):
        r = client.post("/api/v1/chat", json={"prompt": "Charge 4532-0151-1283-0366 now"})
        assert r.json()["status"] == "BLOCKED" and r.json()["recorded_prompt_id"] is None
        assert client.get("/api/v1/user-prompts").json()["counts"]["skipped_sensitive"] == 1

    def test_labelling_via_the_api(self, client, data_dir):
        pid = client.post("/api/v1/chat", json={"prompt": "Explain TCP versus UDP."}).json()["recorded_prompt_id"]
        assert client.put(f"/api/v1/user-prompts/{pid}/label", json={"label": "benign"}).json() == {"id": pid, "label": "benign"}
        assert client.get("/api/v1/user-prompts").json()["counts"]["benign"] == 1
        assert client.put(f"/api/v1/user-prompts/{pid}/label", json={"label": None}).status_code == 200

    @pytest.mark.parametrize("path, body, status", [
        ("/api/v1/user-prompts/USR-0001/label", {"label": "evil"}, 422),
        ("/api/v1/user-prompts/USR-0001/label", {"label": "benign", "extra": 1}, 422),
        ("/api/v1/user-prompts/not-an-id/label", {"label": "benign"}, 422),
        ("/api/v1/user-prompts/USR-0099/label", {"label": "benign"}, 404),
    ])
    def test_label_endpoint_validates_input(self, client, data_dir, path, body, status):
        assert client.put(path, json=body).status_code == status

    def test_delete_via_the_api(self, client, data_dir):
        pid = client.post("/api/v1/chat", json={"prompt": "to be removed"}).json()["recorded_prompt_id"]
        assert client.delete(f"/api/v1/user-prompts/{pid}").status_code == 200
        assert client.delete(f"/api/v1/user-prompts/{pid}").status_code == 404
        assert client.get("/api/v1/user-prompts").json()["counts"]["total"] == 0

    def test_nothing_is_recorded_when_the_server_is_exposed_to_the_network(self, client, tmp_path, with_settings):
        with_settings(DATA_DIR=str(tmp_path), HOST="0.0.0.0", RECORD_PROMPTS="auto")
        r = client.post("/api/v1/chat", json={"prompt": "What is the capital of France?"})
        assert r.status_code == 200 and r.json()["recorded_prompt_id"] is None
        listing = client.get("/api/v1/user-prompts").json()
        assert listing["enabled"] is False and listing["items"] == []
        assert client.put("/api/v1/user-prompts/USR-0001/label", json={"label": "benign"}).status_code == 403
        assert not (tmp_path / "user_prompts.json").exists()

    def test_the_explicit_override_turns_recording_on_even_when_exposed(self, client, tmp_path, with_settings):
        with_settings(DATA_DIR=str(tmp_path), HOST="0.0.0.0", RECORD_PROMPTS="on")
        assert client.post("/api/v1/chat", json={"prompt": "hello world"}).json()["recorded_prompt_id"] == "USR-0001"

    def test_a_failing_store_never_breaks_the_chat_request(self, client, data_dir, monkeypatch):
        def boom(self, *a, **k):
            raise OSError("disk full")

        monkeypatch.setattr(PLOG.PromptLog, "record", boom)
        r = client.post("/api/v1/chat", json={"prompt": "What is the capital of France?"})
        assert r.status_code == 200 and r.json()["recorded_prompt_id"] is None

    def test_evaluating_your_prompts_does_not_add_them_again(self, client, data_dir):
        pid = client.post("/api/v1/chat", json={"prompt": "Explain TCP versus UDP."}).json()["recorded_prompt_id"]
        client.put(f"/api/v1/user-prompts/{pid}/label", json={"label": "benign"})
        for name in ("user", "combined"):
            rep = client.post(f"/api/v1/evaluate?dataset={name}").json()
            assert rep["dataset"]["name"] == name
        counts = client.get("/api/v1/user-prompts").json()["counts"]
        assert counts["total"] == 1 and client.get("/api/v1/user-prompts").json()["items"][0]["times_seen"] == 1

    def test_the_new_datasets_are_listed(self, client, data_dir):
        names = {d["name"] for d in client.get("/api/v1/evaluate/datasets").json()}
        assert {"user", "combined", "policy", "policy_unseen"} <= names
