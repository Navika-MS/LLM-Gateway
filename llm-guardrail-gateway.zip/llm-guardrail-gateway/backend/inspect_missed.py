"""
List the attacks a dataset's run missed.

  python inspect_missed.py                 # dev set (default)
  python inspect_missed.py --dataset regression

For the frozen holdout only IDs are shown, never prompt text: reading individual holdout failures is exactly how a
holdout gets tuned against and stops being a holdout.
"""
import argparse
import sys

import evaluator
from pipeline import server_policy


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="dev", choices=[n for n in evaluator.DATASET_SPECS])
    args = ap.parse_args(argv)
    dataset = evaluator.load_dataset(args.dataset)
    report = evaluator.evaluate(dataset, server_policy())
    print(f"dataset={args.dataset} missed attacks: {len(report.missed_attacks)}")
    for r in report.missed_attacks:
        print("-" * 70)
        print(f"ID: {r.id}   category: {r.category}   route: {r.route}   risk: {r.risk_score}")
        if r.prompt is not None:
            print(f"Prompt: {r.prompt}")
        else:
            print("(prompt hidden: frozen holdout)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
