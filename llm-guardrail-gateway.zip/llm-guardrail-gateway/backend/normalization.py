"""
Text normalisation and bounded payload decoding.

Why this module exists (audit C2/M12): the pre-audit gateway matched raw text, so a zero-width
space, a fullwidth letter, a Cyrillic homoglyph or leetspeak defeated every rule. Normalising once,
up front, is the root-cause fix; adding more phrase variants would not be.

Everything here is deterministic, linear-time and bounded: callers cannot make it do unbounded work.
"""
from __future__ import annotations

import base64
import binascii
import codecs
import re
import unicodedata
import urllib.parse
from dataclasses import dataclass, field
from typing import List, Tuple

# --- limits (defence against decode bombs; see also MAX_PROMPT_CHARS in config) -----------------
MAX_DECODE_DEPTH = 2
MAX_DECODED_SEGMENTS = 8
MAX_DECODED_BYTES = 4096
MIN_BASE64_LEN = 16
MIN_HEX_LEN = 24

# Common Cyrillic / Greek / misc look-alikes -> ASCII. Not exhaustive by design: NFKC already
# folds fullwidth/compat forms; this covers the confusables attackers actually use.
_CONFUSABLES = {
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "у": "y", "х": "x", "і": "i",
    "ј": "j", "ѕ": "s", "ԁ": "d", "һ": "h", "ԛ": "q", "ԝ": "w", "к": "k", "м": "m",
    "н": "h", "т": "t", "в": "b", "ѵ": "v",
    "ο": "o", "α": "a", "ε": "e", "ι": "i", "κ": "k", "ν": "v", "ρ": "p", "τ": "t",
    "υ": "u", "χ": "x", "ƅ": "b", "ɡ": "g", "ɑ": "a", "ǝ": "e", "ı": "i",
}
_UPPER = {"А": "A", "В": "B", "Е": "E", "К": "K", "М": "M", "Н": "H", "О": "O", "Р": "P", "С": "C",
          "Т": "T", "Х": "X", "І": "I", "Ј": "J", "Ѕ": "S", "Ү": "Y", "Ь": "b"}
_CONFUSABLE_TABLE = {ord(k): v for k, v in {**_CONFUSABLES, **_UPPER}.items()}

# Digits/symbols commonly substituted for letters ("1gn0re").
_LEET = {"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t", "@": "a", "$": "s"}

_WS_RE = re.compile(r"\s+")
_WORD_RE = re.compile(r"[a-z0-9@$']+")
_B64_RE = re.compile(r"[A-Za-z0-9+/_-]{%d,}={0,2}" % MIN_BASE64_LEN)
_HEX_RE = re.compile(r"(?:[0-9a-fA-F]{2}){%d,}" % (MIN_HEX_LEN // 2))
_PCT_RE = re.compile(r"(?:%[0-9a-fA-F]{2}){3,}")


@dataclass
class DecodedSegment:
    encoding: str          # base64 | hex | url | rot13
    text: str              # decoded, already normalised
    depth: int


@dataclass
class NormalizedText:
    original_len: int
    light: str                          # NFKC, invisibles removed, confusables folded; CASE PRESERVED
                                        # (PII / secret detectors need case: AKIA..., JWT, base64 keys)
    text: str                           # primary view: light + casefold + de-leet + collapsed whitespace
    tight: str                          # letters+digits only (defeats "i g n o r e", "i.g.n.o.r.e")
    reversed_text: str                  # primary view reversed (defeats trivial reversal)
    decoded: List[DecodedSegment] = field(default_factory=list)
    changed_chars: int = 0              # how many characters normalisation had to alter/remove
    invisible_removed: int = 0
    confusables_folded: int = 0
    opaque_blob: bool = False           # a long encoded-looking token exists (decoded or not)

    @property
    def obfuscation_suspected(self) -> bool:
        return (self.invisible_removed >= 1 or self.confusables_folded >= 2)


def _is_invisible(ch: str) -> bool:
    cat = unicodedata.category(ch)
    if cat == "Cf":                       # zero-width space/joiner, BOM, bidi controls, soft hyphen
        return True
    if cat == "Cc" and ch not in "\n\t\r":
        return True
    return False


def _fold(text: str) -> Tuple[str, str, int, int]:
    """NFKC -> drop invisibles -> fold confusables -> casefold.

    Returns (primary_folded, light, invisible_removed, mixed_script_confusables).
    `mixed_script_confusables` counts look-alike letters only inside tokens that ALSO contain Latin
    letters: that is the real homoglyph-evasion signature. A plain Russian or Greek sentence is not
    obfuscation and must not be flagged as such.
    """
    nfkc = unicodedata.normalize("NFKC", text)
    invisible = 0
    kept = []
    for ch in nfkc:
        if _is_invisible(ch):
            invisible += 1
            continue
        kept.append(ch)
    s = "".join(kept)
    mixed = 0
    for tok in s.split():
        has_latin = any("a" <= c.lower() <= "z" for c in tok)
        if has_latin:
            mixed += sum(1 for c in tok if ord(c) in _CONFUSABLE_TABLE)
    light = s.translate(_CONFUSABLE_TABLE)
    folded = light.casefold()
    # Strip combining marks (e.g. "i̇gnore") after NFKD so accents cannot split a word.
    decomposed = unicodedata.normalize("NFKD", folded)
    folded = "".join(ch for ch in decomposed if unicodedata.category(ch) != "Mn")
    return folded, light, invisible, mixed


def _collapse_ws(s: str) -> str:
    return _WS_RE.sub(" ", s).strip()


def unleet(text: str) -> str:
    """Replace leet characters only inside tokens that also contain letters (keeps '2024' intact)."""
    def fix(m: "re.Match[str]") -> str:
        tok = m.group(0)
        letters = sum(c.isalpha() for c in tok)
        subs = sum(c in _LEET for c in tok)
        if letters >= 2 and subs >= 1:
            return "".join(_LEET.get(c, c) for c in tok)
        return tok
    return _WORD_RE.sub(fix, text)


def _printable_ratio(s: str) -> float:
    if not s:
        return 0.0
    ok = sum(1 for c in s if c.isprintable() or c in "\n\t\r")
    return ok / len(s)


def _try_base64(token: str) -> str:
    tok = token.strip("=")
    pad = "=" * (-len(tok) % 4)
    for alphabet_fix in (lambda t: t, lambda t: t.replace("-", "+").replace("_", "/")):
        try:
            raw = base64.b64decode(alphabet_fix(tok) + pad, validate=True)
        except (binascii.Error, ValueError):
            continue
        if len(raw) > MAX_DECODED_BYTES:
            raw = raw[:MAX_DECODED_BYTES]
        text = raw.decode("utf-8", errors="ignore")
        if len(text) >= 6 and _printable_ratio(text) >= 0.9 and sum(c.isalpha() for c in text) / len(text) > 0.5:
            return text
    return ""


def _try_hex(token: str) -> str:
    try:
        raw = bytes.fromhex(token[: MAX_DECODED_BYTES * 2])
    except ValueError:
        return ""
    text = raw.decode("utf-8", errors="ignore")
    if len(text) >= 6 and _printable_ratio(text) >= 0.9 and sum(c.isalpha() for c in text) / len(text) > 0.5:
        return text
    return ""


def _decode_segments(view: str, depth: int, budget: List[int]) -> List[DecodedSegment]:
    """Find and decode encoded-looking segments in `view` (raw-cased text!). Bounded."""
    out: List[DecodedSegment] = []
    if depth > MAX_DECODE_DEPTH or budget[0] <= 0:
        return out

    def add(enc: str, decoded: str) -> None:
        if budget[0] <= 0 or not decoded:
            return
        budget[0] -= 1
        norm = _collapse_ws(unleet(_fold(decoded)[0]))
        out.append(DecodedSegment(enc, norm, depth))
        out.extend(_decode_segments(decoded, depth + 1, budget))

    for m in _B64_RE.finditer(view):
        tok = m.group(0)
        if tok.isalpha() and tok.islower():      # an ordinary long lowercase word is not base64
            continue
        dec = _try_base64(tok)
        if dec:
            add("base64", dec)
    for m in _HEX_RE.finditer(view):
        dec = _try_hex(m.group(0))
        if dec:
            add("hex", dec)
    for m in _PCT_RE.finditer(view):
        try:
            dec = urllib.parse.unquote(m.group(0))
        except Exception:
            dec = ""
        if dec and dec != m.group(0):
            add("url", dec)
    return out


def normalize(text: str) -> NormalizedText:
    """Normalise untrusted text. Always returns; never raises on weird input."""
    if not isinstance(text, str):
        text = str(text)
    folded, light, invisible, confusables = _fold(text)
    unleeted = unleet(folded)                      # 1:1 character replacement, so zip() is aligned
    leet_subs = sum(1 for a, b in zip(folded, unleeted) if a != b)
    primary = _collapse_ws(unleeted)
    # `changed_chars` is a weak "how much did we have to repair" hint, never a verdict by itself.
    changed = invisible + confusables + leet_subs
    tight = "".join(ch for ch in primary if ch.isalnum())
    budget = [MAX_DECODED_SEGMENTS]
    decoded = _decode_segments(text, 1, budget)
    # ROT13 is only reported when it *creates* more recognisable English than the original does;
    # the scorer decides that, so we expose the transformed text as a candidate segment.
    rot = _collapse_ws(_fold(codecs.encode(text, "rot13"))[0])
    opaque = bool(_B64_RE.search(text) or _HEX_RE.search(text) or _PCT_RE.search(text))
    nt = NormalizedText(
        original_len=len(text),
        light=light,
        text=primary,
        tight=tight,
        reversed_text=primary[::-1],
        decoded=decoded,
        changed_chars=changed,
        invisible_removed=invisible,
        confusables_folded=confusables,
        opaque_blob=opaque,
    )
    nt.decoded.append(DecodedSegment("rot13", rot, 1))   # filtered by consumers via lexicon hits
    return nt
