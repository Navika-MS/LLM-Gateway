"""
Pluggable Stage 2 backends.

Stage 2 is any callable with the signature `(prompt, norm, stage1, policy) -> Stage2Result` (the `Classifier`
type in stage2_simulator.py). The pipeline, evaluator and API do not care which one they get, so this module only
has to build the right callable from configuration (`GATEWAY_STAGE2_BACKEND`):

    simulator            the deterministic heuristic scorer (default; no model, no downloads)
    deberta              protectai/deberta-v3-base-prompt-injection-v2 through PyTorch
    deberta_onnx         the same model through ONNX Runtime
    <a>+<b>              highest-risk-wins ensemble, e.g. "simulator+deberta"

Properties that matter for a security component
-----------------------------------------------
* Offline by construction. Models load from a LOCAL folder with `local_files_only`; the server never reaches the
  network. The only code that downloads anything is `download_model()`, run on purpose via
  `python manage.py setup-model`. It pins a model revision and refuses pickle files (safetensors/ONNX only).
* Fail closed. A missing model, a missing library, or input too long to cover raises; the pipeline turns that into
  status=ERROR (HTTP 502), never into a pass.
* No truncation evasion. Inputs longer than one 512-token window are scanned with overlapping windows and the
  MAXIMUM probability is used, so padding an attack past the model's context does not hide it. If the windows
  needed exceed `GATEWAY_STAGE2_MAX_WINDOWS` the request fails closed rather than scanning only a prefix.
* Honest labelling. `simulated=False` for a trained model (it is real inference), `live=False` because nothing is
  paid or remote. The provider string names the model and runtime.
* Decoded payloads (base64/hex/url found by normalisation) are classified too.
"""
from __future__ import annotations

import json
import math
import os
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import config
from guardrails import Stage1Result
from normalization import NormalizedText
from schemas import Policy
import stage2_simulator
from stage2_simulator import Classifier, Feature, Stage2Result

MODEL_ID = "protectai/deberta-v3-base-prompt-injection-v2"
MODEL_REVISION = "90c9989b1a342275dd0d1a95aad283c04e075671"      # pinned commit of the model repository
MODEL_LICENSE = "Apache-2.0"
MODEL_SHA256 = "6521cb8d0ac08148c81464899c424e6148fcc62befa371089fa4061d8b6e0424"   # model.safetensors at MODEL_REVISION
DEFAULT_MODEL_DIR = config.BASE_DIR / "models" / "deberta-v3-base-prompt-injection-v2"
SAFE_PATTERNS = ["config.json", "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json", "added_tokens.json",
                 "spm.model", "model.safetensors", "LICENSE", "README.md"]
ONNX_PATTERNS = ["onnx/model.onnx", "onnx/config.json", "onnx/tokenizer.json", "onnx/tokenizer_config.json",
                 "onnx/special_tokens_map.json", "onnx/added_tokens.json", "onnx/spm.model"]
WINDOW = 510                      # content tokens per window (+ [CLS] and [SEP] = 512)
STRIDE = 255
BATCH = 8
MAX_DECODED_SEGMENTS = 3


def model_inputs(prompt: str, norm: NormalizedText) -> List[str]:
    """The texts the model should read: the prompt itself plus real decoded payloads (base64 / hex / url).

    Normalisation attaches a rot13 reading to EVERY prompt (it cannot know whether the text is English). Sending that
    gibberish to the model would double the cost of every request for nothing, so it is skipped, exactly as the simulator does.
    A rot13-encoded known attack phrase is still caught by Stage 1, which matches signatures on the rot13 view.
    """
    texts = [norm.light or prompt]
    for seg in norm.decoded[:MAX_DECODED_SEGMENTS + 1]:
        if seg.encoding != "rot13" and seg.text.strip() and len(texts) <= MAX_DECODED_SEGMENTS:
            texts.append(seg.text)
    return texts


class Stage2Unavailable(RuntimeError):
    """The configured model cannot be used (files or libraries missing). The pipeline reports ERROR."""


class InputTooLong(RuntimeError):
    """The prompt needs more windows than configured; scanning only a prefix would be an evasion route."""


def model_dir(s: Optional[config.Settings] = None) -> Path:
    s = s or config.settings
    return Path(s.STAGE2_MODEL_DIR).expanduser() if s.STAGE2_MODEL_DIR else DEFAULT_MODEL_DIR


# ------------------------------------------------------------------------------------------------
# Simulator as a component (so it can be an ensemble member)
# ------------------------------------------------------------------------------------------------


class SimulatorClassifier:
    live = False
    simulated = True
    provider = stage2_simulator.PROVIDER
    model_id: Optional[str] = None

    def __call__(self, prompt: str, norm: NormalizedText, stage1: Stage1Result, policy: Policy) -> Stage2Result:
        return stage2_simulator.classify(prompt, norm, stage1, policy)


# ------------------------------------------------------------------------------------------------
# Trained model (shared logic; runtimes differ only in `_load` and `_infer`)
# ------------------------------------------------------------------------------------------------


class ModelClassifier:
    live = False
    simulated = False
    runtime = "base"
    model_id = MODEL_ID

    def __init__(self, directory: Path, threads: int = 0, max_windows: int = 12):
        self.directory = Path(directory)
        self.threads = threads
        self.max_windows = max_windows
        self._lock = threading.Lock()
        self._infer_lock = threading.Lock()      # FastAPI runs requests in threads; serialise inference instead of oversubscribing the CPU
        self._ready = False
        self.load_seconds: Optional[float] = None
        self.load_error: Optional[str] = None
        self._tok = None
        self._injection_index = 1

    @property
    def provider(self) -> str:
        return f"LOCAL_DEBERTA_PROMPT_INJECTION_V2_{self.runtime.upper()}"

    # ---- lifecycle -------------------------------------------------------------------------
    def load(self) -> None:
        if self._ready:
            return
        with self._lock:
            if self._ready:
                return
            t0 = time.perf_counter()
            try:
                os.environ.setdefault("HF_HUB_OFFLINE", "1")          # belt and braces: never touch the network
                os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
                os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
                self._check_files()
                self._load_tokenizer()
                self._injection_index = self._find_injection_index()
                self._load_runtime()
            except Stage2Unavailable as exc:
                self.load_error = str(exc)
                raise
            except ImportError as exc:
                self.load_error = f"missing Python library '{exc.name}' (run: python manage.py setup-model)"
                raise Stage2Unavailable(self.load_error) from exc
            except Exception as exc:                                    # corrupt file, unsupported format, ...
                self.load_error = f"{type(exc).__name__}: {str(exc)[:200]}"
                raise Stage2Unavailable(self.load_error) from exc
            self.load_seconds = time.perf_counter() - t0
            self._ready = True

    def status(self) -> Dict[str, object]:
        return {"provider": self.provider, "model": self.model_id, "runtime": self.runtime, "ready": self._ready,
                "load_seconds": None if self.load_seconds is None else round(self.load_seconds, 2),
                "error": self.load_error, "model_dir_present": self.directory.is_dir()}

    def _check_files(self) -> None:
        if not (self.directory / "config.json").is_file():
            raise Stage2Unavailable(f"model folder not found or incomplete: {self.directory} "
                                    "(run: python manage.py setup-model)")

    def _load_tokenizer(self) -> None:
        from transformers import AutoTokenizer                            # imported lazily: simulator mode needs none of this

        self._tok = AutoTokenizer.from_pretrained(str(self.directory), local_files_only=True)

    def _find_injection_index(self) -> int:
        cfg = json.loads((self.directory / "config.json").read_text(encoding="utf-8"))
        for idx, label in cfg.get("id2label", {}).items():
            if any(w in str(label).upper() for w in ("INJECTION", "JAILBREAK", "MALICIOUS", "UNSAFE")):
                return int(idx)
        raise Stage2Unavailable("model config has no recognisable injection label; refusing to guess")

    def _load_runtime(self) -> None:
        raise NotImplementedError

    def _infer(self, batch: List[List[int]]) -> List[List[float]]:
        raise NotImplementedError

    # ---- classification --------------------------------------------------------------------
    def _windows(self, text: str) -> List[List[int]]:
        tok = self._tok
        ids = tok(text, add_special_tokens=False)["input_ids"]
        out: List[List[int]] = []
        start = 0
        while True:
            chunk = ids[start:start + WINDOW]
            out.append([tok.cls_token_id] + chunk + [tok.sep_token_id])
            if start + WINDOW >= len(ids):
                break
            start += STRIDE
        return out

    def p_injection(self, texts: Sequence[str]) -> Tuple[float, int]:
        """Highest P(injection) over every window of every text, and the window count."""
        windows: List[List[int]] = []
        for text in texts:
            windows.extend(self._windows(text))
            if len(windows) > self.max_windows:
                raise InputTooLong(f"needs more than {self.max_windows} windows")
        best = 0.0
        with self._infer_lock:
            for i in range(0, len(windows), BATCH):
                for logits in self._infer(windows[i:i + BATCH]):
                    m = max(logits)
                    exps = [math.exp(v - m) for v in logits]
                    best = max(best, exps[self._injection_index] / sum(exps))
        return best, len(windows)

    def __call__(self, prompt: str, norm: NormalizedText, stage1: Stage1Result, policy: Policy) -> Stage2Result:
        self.load()
        p, n_windows = self.p_injection(model_inputs(prompt, norm))
        risk = max(1, min(100, int(round(p * 100))))
        confidence = "HIGH" if p >= 0.95 or p <= 0.05 else ("MEDIUM" if p >= 0.8 or p <= 0.2 else "LOW")
        category = "PROMPT_INJECTION" if risk >= policy.uncertain_low else "BENIGN"
        return Stage2Result(
            risk_score=risk, category=category, confidence=confidence,
            features=[Feature(f"model_p_injection={p:.3f}", "PROMPT_INJECTION", p, False, p)],
            reasoning=f"{self.model_id} via {self.runtime}: P(injection)={p:.3f} over {n_windows} window(s)",
            provider=self.provider)


class TorchDebertaClassifier(ModelClassifier):
    runtime = "torch"

    def _check_files(self) -> None:
        super()._check_files()
        if not (self.directory / "model.safetensors").is_file():
            raise Stage2Unavailable(f"model.safetensors missing in {self.directory} (run: python manage.py setup-model)")

    def _load_runtime(self) -> None:
        import torch
        from transformers import AutoModelForSequenceClassification

        if self.threads > 0:
            torch.set_num_threads(self.threads)
        self._torch = torch
        self._model = AutoModelForSequenceClassification.from_pretrained(
            str(self.directory), local_files_only=True, use_safetensors=True).eval()

    def _infer(self, batch: List[List[int]]) -> List[List[float]]:
        torch = self._torch
        width = max(len(b) for b in batch)
        pad = self._tok.pad_token_id
        ids = torch.tensor([b + [pad] * (width - len(b)) for b in batch], dtype=torch.long)
        mask = torch.tensor([[1] * len(b) + [0] * (width - len(b)) for b in batch], dtype=torch.long)
        with torch.inference_mode():
            return self._model(input_ids=ids, attention_mask=mask).logits.tolist()


class OnnxDebertaClassifier(ModelClassifier):
    runtime = "onnx"

    def __init__(self, directory: Path, onnx_file: str = "onnx/model.onnx", threads: int = 0, max_windows: int = 12):
        super().__init__(directory, threads, max_windows)
        self.onnx_path = self.directory / onnx_file

    def _check_files(self) -> None:
        super()._check_files()
        if not self.onnx_path.is_file():
            raise Stage2Unavailable(f"ONNX model not found: {self.onnx_path} (run: python manage.py setup-model --onnx)")

    def _load_runtime(self) -> None:
        import numpy as np
        import onnxruntime as ort

        opts = ort.SessionOptions()
        if self.threads > 0:
            opts.intra_op_num_threads = self.threads
        self._np = np
        self._session = ort.InferenceSession(str(self.onnx_path), opts, providers=["CPUExecutionProvider"])
        self._input_names = {i.name for i in self._session.get_inputs()}

    def _infer(self, batch: List[List[int]]) -> List[List[float]]:
        np = self._np
        width = max(len(b) for b in batch)
        pad = self._tok.pad_token_id
        ids = np.array([b + [pad] * (width - len(b)) for b in batch], dtype=np.int64)
        mask = np.array([[1] * len(b) + [0] * (width - len(b)) for b in batch], dtype=np.int64)
        feed = {"input_ids": ids, "attention_mask": mask}
        if "token_type_ids" in self._input_names:
            feed["token_type_ids"] = np.zeros_like(ids)
        return self._session.run(None, {k: v for k, v in feed.items() if k in self._input_names})[0].tolist()


# ------------------------------------------------------------------------------------------------
# Ensemble and factory
# ------------------------------------------------------------------------------------------------


class EnsembleClassifier:
    """Highest risk wins. Any member failing fails the whole call (closed), never silently drops a member."""

    live = False

    def __init__(self, members: Sequence[Classifier]):
        self.members = list(members)
        self.simulated = all(getattr(m, "simulated", True) for m in self.members)
        self.provider = "LOCAL_ENSEMBLE(" + "+".join(getattr(m, "provider", "?") for m in self.members) + ")"
        self.model_id = next((getattr(m, "model_id", None) for m in self.members if getattr(m, "model_id", None)), None)

    def __call__(self, prompt: str, norm: NormalizedText, stage1: Stage1Result, policy: Policy) -> Stage2Result:
        results = [m(prompt, norm, stage1, policy) for m in self.members]
        top = max(results, key=lambda r: r.risk_score)
        parts = ", ".join(f"{r.provider}={r.risk_score}" for r in results)
        return Stage2Result(
            risk_score=top.risk_score, category=top.category, confidence=top.confidence,
            features=[f for r in results for f in r.features], reasoning=f"max-risk ensemble: {parts}",
            framing=any(r.framing for r in results), defensive=top.defensive, provider=self.provider)

    def load(self) -> None:
        for m in self.members:
            if hasattr(m, "load"):
                m.load()

    def status(self) -> Dict[str, object]:
        members = [m.status() if hasattr(m, "status") else {"provider": getattr(m, "provider", "?"), "ready": True} for m in self.members]
        errors = [m["error"] for m in members if m.get("error")]
        return {"provider": self.provider, "model": self.model_id, "ready": all(m.get("ready", True) for m in members),
                "error": errors[0] if errors else None, "members": members}


def build_classifier(s: Optional[config.Settings] = None) -> Optional[Classifier]:
    """None means "use the built-in simulator" (the pipeline's default path, unchanged)."""
    s = s or config.settings
    parts = s.STAGE2_BACKEND.split("+")
    if parts == ["simulator"]:
        return None
    directory = model_dir(s)
    members: List[Classifier] = []
    for part in parts:
        if part == "simulator":
            members.append(SimulatorClassifier())
        elif part == "deberta":
            members.append(TorchDebertaClassifier(directory, s.STAGE2_THREADS, s.STAGE2_MAX_WINDOWS))
        elif part == "deberta_onnx":
            members.append(OnnxDebertaClassifier(directory, s.STAGE2_ONNX_FILE, s.STAGE2_THREADS, s.STAGE2_MAX_WINDOWS))
    return members[0] if len(members) == 1 else EnsembleClassifier(members)


def warm_up(classifier: Optional[Classifier]) -> Dict[str, object]:
    """Load model weights now (server start) instead of on the first request. Never raises."""
    if classifier is None:
        return {"provider": stage2_simulator.PROVIDER, "ready": True, "model": None}
    try:
        if hasattr(classifier, "load"):
            classifier.load()
    except Exception:
        pass                                    # status() carries the reason; requests will fail closed (ERROR)
    return describe(classifier)


def describe(classifier: Optional[Classifier]) -> Dict[str, object]:
    if classifier is None:
        return {"provider": stage2_simulator.PROVIDER, "ready": True, "model": None, "runtime": "heuristic"}
    if hasattr(classifier, "status"):
        return classifier.status()
    return {"provider": getattr(classifier, "provider", "CUSTOM"), "ready": True}


# ------------------------------------------------------------------------------------------------
# The ONLY code that touches the network: an explicit, pinned download (python manage.py setup-model)
# ------------------------------------------------------------------------------------------------


def verify_model(directory: Optional[Path] = None) -> bool:
    """True iff model.safetensors in `directory` is byte-identical to the weights this project was measured with."""
    import hashlib

    path = Path(directory or DEFAULT_MODEL_DIR) / "model.safetensors"
    if not path.is_file():
        return False
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest() == MODEL_SHA256


def download_model(destination: Optional[Path] = None, include_onnx: bool = False) -> Path:
    from huggingface_hub import snapshot_download

    destination = Path(destination or DEFAULT_MODEL_DIR)
    patterns = SAFE_PATTERNS + (ONNX_PATTERNS if include_onnx else [])
    snapshot_download(repo_id=MODEL_ID, revision=MODEL_REVISION, local_dir=str(destination), allow_patterns=patterns)
    if not verify_model(destination):
        raise RuntimeError("model.safetensors does not match the recorded SHA-256; delete the folder and retry, "
                           "or update MODEL_SHA256 deliberately after reviewing the new revision")
    return destination


def main(argv: Optional[List[str]] = None) -> int:
    import argparse

    ap = argparse.ArgumentParser(description="Download the pinned Stage 2 model (safetensors/ONNX only, no pickle files).")
    ap.add_argument("--dest", default=str(DEFAULT_MODEL_DIR))
    ap.add_argument("--onnx", action="store_true", help="also download the ONNX export (about 740 MB more)")
    args = ap.parse_args(argv)
    print(f"Downloading {MODEL_ID} @ {MODEL_REVISION[:12]} ({MODEL_LICENSE}) to {args.dest} ...", flush=True)
    path = download_model(Path(args.dest), include_onnx=args.onnx)
    print(f"Done: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
