"""
Thin wrapper kept for backward compatibility: `python test_unseen.py`.

The original 24 hand-written cases now live, unchanged, in datasets/legacy_unseen_24.json and are run through the
shared decision function by evaluator.py. This script no longer overwrites unseen_test_results.json (the historical
95.83% result is preserved under baselines/).

NOTE: despite the original name these were iterated against during development, so they are a DEVELOPMENT set.
"""
import sys

import evaluator

__test__ = False        # not a pytest module (the real tests live in tests/)

if __name__ == "__main__":
    sys.exit(evaluator.main(["--dataset", "legacy_unseen"] + sys.argv[1:]))
