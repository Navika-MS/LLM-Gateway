"""
The ONE authoritative security decision flow (audit C4, M1, M2, M4, M8).

    request -> resolve policy (server-owned; clients may only tighten)
            -> Stage 1 deterministic checks            [block high-confidence threats immediately]
            -> Stage 2 heuristic simulator             [every prompt Stage 1 did not block, when enabled]
            -> threshold / uncertainty bands           [risk > threshold blocks; the uncertain band is flagged]
            -> (only if allowed) generation -> strict schema validation (<= 1 retry) -> output guard
            -> response with accurate decision metadata

`security_decision()` is the only function that decides block / allow / error for a prompt. The API
(`run_gateway`), the evaluator and the tests all call it, so the policy cannot drift between them.

Semantics, defined once:
  * `bypassed_stage2` means "Stage 2 did not execute"; `stage2_skip_reason` says why.
  * A prompt is blocked by Stage 2 iff `risk_score > risk_threshold` (strictly greater).
  * `uncertain_low <= risk_score <= risk_threshold` is the UNCERTAIN band: flagged (default) or blocked (strict).
  * Stage 1 SUSPICIOUS + Stage 2 unavailable => fail CLOSED. A classifier error is reported as ERROR, never as PASS.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import config
from config import settings
from generation import (GenerationContext, Generator, MockGenerator, generate_validated, output_text_for_scan)
from guardrails import Stage1Result, analyze_stage1, scan_output
from normalization import NormalizedText, normalize
import risk_policy
from schemas import (ChatResponse, ClientPolicyRequest, Policy, PolicyReport, RiskPolicyInfo, SecurityLog, SimulationFlags,
                     Stage1Info, Stage2Info)
import stage2_simulator
from stage2_simulator import Classifier, Stage2Result

log = logging.getLogger("gateway")

BOOLEAN_CONTROLS = ("pii_check", "injection_check", "ai_classifier_check", "schema_enforcement", "output_pii_check")


# ------------------------------------------------------------------------------------------------
# Policy
# ------------------------------------------------------------------------------------------------


def server_policy(s=None) -> Policy:
    """The policy the operator configured. This is what applies unless a client TIGHTENS it."""
    s = s or settings                    # looked up at call time, not bound at import
    return Policy(
        pii_check=s.PII_CHECK, injection_check=s.INJECTION_CHECK, ai_classifier_check=s.AI_CLASSIFIER_CHECK,
        schema_enforcement=s.SCHEMA_ENFORCEMENT, output_pii_check=s.OUTPUT_PII_CHECK,
        risk_threshold=s.RISK_THRESHOLD, uncertain_low=s.UNCERTAIN_LOW,
        uncertain_action=s.UNCERTAIN_ACTION, stage2_error_policy=s.STAGE2_ERROR_POLICY,
        sensitive_data_policy=s.SENSITIVE_DATA_POLICY, destructive_action_policy=s.DESTRUCTIVE_ACTION_POLICY,
    )


@dataclass(frozen=True)
class PolicyResolution:
    effective: Policy
    source: str
    applied: List[str] = field(default_factory=list)
    rejected: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def report(self) -> PolicyReport:
        return PolicyReport(effective=self.effective, source=self.source, applied=list(self.applied),
                            rejected=list(self.rejected), warnings=list(self.warnings))


def resolve_policy(server: Policy, requested: Optional[ClientPolicyRequest] = None,
                   enforce_schema: Optional[bool] = None, allow_override: bool = False) -> PolicyResolution:
    """Merge a client's request into the server policy. A client may only make things STRICTER.

    Weakening requests (turning a check off, raising the threshold, disabling schema enforcement) are
    refused and reported, unless the operator explicitly enabled the demo-only override.
    """
    values = server.model_dump()
    applied: List[str] = []
    rejected: List[str] = []
    warnings: List[str] = []
    weakened = False

    asked = {}
    if requested is not None:
        asked = {k: v for k, v in requested.model_dump().items() if v is not None}
    if enforce_schema is not None:
        # "enforce_schema" is the legacy spelling of schema_enforcement; the stricter of the two wins.
        asked["schema_enforcement"] = asked.get("schema_enforcement", True) and enforce_schema

    for key in BOOLEAN_CONTROLS:
        if key not in asked or asked[key] == values[key]:
            continue
        if asked[key]:                                      # server had it OFF, client asks ON: stricter
            values[key] = True
            applied.append(f"{key}=true (tightened)")
        elif allow_override:                                # client asks OFF while server has it ON
            values[key] = False
            applied.append(f"{key}=false (DEMO OVERRIDE)")
            warnings.append(f"security control '{key}' was disabled by the client (demo override enabled on this server)")
            weakened = True
        else:
            rejected.append(f"{key}=false (a client cannot disable a server-enforced control)")

    if "risk_threshold" in asked and asked["risk_threshold"] != values["risk_threshold"]:
        r = asked["risk_threshold"]
        if r < values["risk_threshold"]:
            values["risk_threshold"] = r
            applied.append(f"risk_threshold={r} (tightened)")
        elif allow_override:
            values["risk_threshold"] = r
            applied.append(f"risk_threshold={r} (DEMO OVERRIDE)")
            warnings.append(f"risk threshold raised to {r} by the client (demo override enabled on this server)")
            weakened = True
        else:
            rejected.append(f"risk_threshold={r} (a client cannot raise the server threshold of {values['risk_threshold']})")

    # Keep the uncertain band below the (possibly tightened) threshold.
    values["uncertain_low"] = max(0, min(values["uncertain_low"], values["risk_threshold"] - 1))

    source = "CLIENT_OVERRIDE_DEMO" if weakened else ("SERVER_PLUS_CLIENT_TIGHTENING" if applied else "SERVER")
    return PolicyResolution(Policy(**values), source, applied, rejected, warnings)


# ------------------------------------------------------------------------------------------------
# The security decision
# ------------------------------------------------------------------------------------------------


@dataclass
class SecurityDecision:
    action: str                                 # ALLOW | BLOCK | ERROR
    route: str
    stage_triggered: str
    risk_score: int
    category: Optional[str]
    reason: Optional[str]
    confidence: Optional[str]
    label: Optional[str]                        # BENIGN | UNCERTAIN | MALICIOUS (Stage 2 only)
    flagged_uncertain: bool
    stage1: Stage1Result
    stage2: Optional[Stage2Result]
    stage2_executed: bool
    stage2_skip_reason: Optional[str]
    stage2_status: str                          # OK | ERROR | SKIPPED
    stage2_provider: str
    stage2_error_code: Optional[str]
    error_code: Optional[str]
    timings_ms: Dict[str, float]
    warnings: List[str] = field(default_factory=list)
    risk_policy: Optional[risk_policy.RiskFinding] = None   # sensitive-data / destructive-action layer
    stage2_model: Optional[str] = None                      # model id when Stage 2 is a trained model
    stage2_simulated: bool = True                           # False when Stage 2 is real inference


def _validate_stage2(result: object) -> Optional[str]:
    """Return an error code if the classifier's output is not a usable Stage2Result."""
    if not isinstance(result, Stage2Result):
        return "STAGE2_INVALID_OUTPUT"
    if isinstance(result.risk_score, bool) or not isinstance(result.risk_score, int) or not 1 <= result.risk_score <= 100:
        return "STAGE2_INVALID_OUTPUT"
    return None


def security_decision(prompt: str, policy: Policy, classifier: Optional[Classifier] = None) -> SecurityDecision:
    """Decide ALLOW / BLOCK / ERROR for a prompt. The single decision authority. Never raises.

    A risk-policy FLAG (a sensitive-data / destructive-action finding below BLOCK level) never blocks by itself: it
    marks an otherwise-allowed prompt as flagged for review, exactly like Stage 2's uncertain band.
    """
    d = _decide(prompt, policy, classifier)
    rp = d.risk_policy
    if rp is not None and rp.action == "FLAG" and d.action == "ALLOW":
        d.flagged_uncertain = True
        d.category = d.category or rp.category
        d.reason = ((d.reason + " | ") if d.reason else "") + f"risk policy flagged for review: {rp.category} ({rp.rule})"
    return d


def _decide(prompt: str, policy: Policy, classifier: Optional[Classifier]) -> SecurityDecision:
    classifier = classifier or stage2_simulator.classify
    simulated = bool(getattr(classifier, "simulated", not getattr(classifier, "live", False)))
    model_id = getattr(classifier, "model_id", None)
    timings: Dict[str, float] = {"stage1_local": 0.0, "risk_policy": 0.0, "stage2_classifier": 0.0}

    t0 = time.perf_counter()
    norm: NormalizedText = normalize(prompt)
    s1 = analyze_stage1(prompt, policy, norm)
    timings["stage1_local"] = (time.perf_counter() - t0) * 1000.0

    rp: Optional[risk_policy.RiskFinding] = None

    def decision(**kw) -> SecurityDecision:
        base = dict(flagged_uncertain=False, stage2=None, stage2_executed=False, stage2_skip_reason=None,
                    stage2_status="SKIPPED", stage2_provider="NOT_USED", stage2_error_code=None, error_code=None,
                    label=None, confidence=None, category=None, reason=None, stage1=s1, timings_ms=timings,
                    risk_policy=rp, stage2_model=model_id, stage2_simulated=simulated)
        base.update(kw)
        return SecurityDecision(**base)

    # --- Stage 1 blocks high-confidence threats immediately ---------------------------------
    if s1.route == "BLOCK":
        return decision(action="BLOCK", route="STAGE_1_BLOCK", stage_triggered="STAGE_1_DETERMINISTIC",
                        risk_score=s1.risk_score, category=s1.category, reason=s1.reason,
                        stage2_skip_reason="STAGE_1_BLOCKED", confidence="HIGH")

    # --- risk-policy layer: sensitive-data requests and destructive commands (independent of Stage 2) ----
    t_rp = time.perf_counter()
    try:
        rp = risk_policy.assess(norm, policy)
    except Exception:                                     # a bug here must neither crash the request nor silently pass it
        log.exception("risk policy layer failed")
        timings["risk_policy"] = (time.perf_counter() - t_rp) * 1000.0
        return decision(action="ERROR", route="STAGE_2_ERROR_BLOCK", stage_triggered="STAGE_2_ERROR", risk_score=0,
                        reason="The risk-policy layer failed; the request was not processed (fail closed).",
                        error_code="RISK_POLICY_EXCEPTION", confidence="LOW")
    timings["risk_policy"] = (time.perf_counter() - t_rp) * 1000.0
    if rp is not None and rp.action == "BLOCK":
        return decision(action="BLOCK", route="RISK_POLICY_BLOCK", stage_triggered="RISK_POLICY", risk_score=rp.risk_score,
                        category=rp.category, stage2_skip_reason="RISK_POLICY_BLOCKED", confidence="HIGH",
                        reason=f"Risk policy blocked: {rp.category.replace('_', ' ').lower()} ({rp.rule})")

    # --- Stage 2 disabled by policy ----------------------------------------------------------
    if not policy.ai_classifier_check:
        if s1.route == "SUSPICIOUS":                         # cannot resolve the ambiguity: fail closed
            return decision(action="BLOCK", route="ESCALATION_UNAVAILABLE_BLOCK", stage_triggered="ESCALATION_UNAVAILABLE",
                            risk_score=s1.risk_score, reason="Stage 1 flagged this prompt as suspicious but Stage 2 is disabled; "
                            "failing closed.", stage2_skip_reason="DISABLED_BY_POLICY", confidence="LOW")
        return decision(action="ALLOW", route="STAGE_1_ONLY_PASS", stage_triggered="NONE_PASSED", risk_score=s1.risk_score,
                        stage2_skip_reason="DISABLED_BY_POLICY", confidence="MEDIUM",
                        reason="Stage 2 is disabled by policy; only Stage 1 checks were applied.")

    # --- Stage 2 --------------------------------------------------------------------------------
    t1 = time.perf_counter()
    result: object = None
    error_code: Optional[str] = None
    try:
        result = classifier(prompt, norm, s1, policy)
        error_code = _validate_stage2(result)
    except Exception as exc:                                  # never leak the exception text to a client
        log.warning("stage 2 classifier failed: %s", type(exc).__name__)    # server log only: class name, no prompt text
        error_code = "STAGE2_EXCEPTION"
        result = None
    timings["stage2_classifier"] = (time.perf_counter() - t1) * 1000.0

    if error_code is not None:
        provider = getattr(classifier, "provider", stage2_simulator.PROVIDER)
        fail_closed = policy.stage2_error_policy == "block" or s1.route == "SUSPICIOUS"
        if fail_closed:
            return decision(action="ERROR", route="STAGE_2_ERROR_BLOCK", stage_triggered="STAGE_2_ERROR", risk_score=0,
                            reason="Stage 2 could not classify this prompt; the request was not processed (fail closed).",
                            stage2_executed=True, stage2_status="ERROR", stage2_provider=provider,
                            stage2_error_code=error_code, error_code=error_code, confidence="LOW")
        return decision(action="ALLOW", route="STAGE_2_ERROR_ALLOWED", stage_triggered="NONE_PASSED", risk_score=s1.risk_score,
                        reason="Stage 2 failed; allowed because the server policy is fail-open and Stage 1 found nothing.",
                        stage2_executed=True, stage2_status="ERROR", stage2_provider=provider,
                        stage2_error_code=error_code, confidence="LOW",
                        warnings=["Stage 2 failed and the request was allowed by the fail-open error policy."])

    assert isinstance(result, Stage2Result)
    score = result.risk_score
    names = ", ".join(f.name for f in result.features[:4]) or "none"
    who = "simulated classifier" if simulated else "classifier " + result.provider
    common = dict(stage2=result, stage2_executed=True, stage2_status="OK", stage2_provider=result.provider,
                  confidence=result.confidence, category=result.category if result.category != "BENIGN" else None)

    if score > policy.risk_threshold:
        return decision(action="BLOCK", route="STAGE_2_BLOCK", stage_triggered="STAGE_2_CLASSIFIER", risk_score=score,
                        label="MALICIOUS", reason=(f"Stage 2 ({who}) blocked: risk {score}/100 exceeds threshold "
                                                   f"{policy.risk_threshold}; category {result.category}; evidence: {names}"), **common)
    if score >= policy.uncertain_low:
        if policy.uncertain_action == "block":
            return decision(action="BLOCK", route="STAGE_2_BLOCK", stage_triggered="STAGE_2_CLASSIFIER", risk_score=score,
                            label="UNCERTAIN", flagged_uncertain=True,
                            reason=(f"Stage 2 ({who}) is uncertain (risk {score}/100, band "
                                    f"{policy.uncertain_low}-{policy.risk_threshold}); blocked by strict policy"), **common)
        return decision(action="ALLOW", route="STAGE_2_PASS_FLAGGED", stage_triggered="NONE_PASSED", risk_score=score,
                        label="UNCERTAIN", flagged_uncertain=True,
                        reason=(f"Stage 2 ({who}) is uncertain (risk {score}/100, band "
                                f"{policy.uncertain_low}-{policy.risk_threshold}); allowed but flagged for review"), **common)
    return decision(action="ALLOW", route="STAGE_2_PASS", stage_triggered="NONE_PASSED", risk_score=score, label="BENIGN",
                    reason=f"Stage 2 ({who}): risk {score}/100, below the uncertain band", **common)


# ------------------------------------------------------------------------------------------------
# The full gateway (decision + generation + validation + output guard)
# ------------------------------------------------------------------------------------------------

TIMING_NOTE = ("Measured local processing time of the simulated components. It is NOT large-language-model inference latency.")
SIM_NOTE = ("Stage 2 is a deterministic heuristic simulator (not an LLM or trained classifier) and generation is a mock; "
            "no external API was called.")
MODEL_NOTE = ("Stage 2 ran a trained model locally on this machine (real inference, no network, no cost); generation is "
              "still a mock and no external API was called.")


def _stage1_info(s1: Stage1Result) -> Stage1Info:
    return Stage1Info(route=s1.route, category=s1.category, reason=s1.reason, signals=list(s1.signals))


def _risk_policy_info(rp: Optional[risk_policy.RiskFinding]) -> Optional[RiskPolicyInfo]:
    if rp is None:
        return None
    return RiskPolicyInfo(category=rp.category, action=rp.action, rule=rp.rule, evidence=rp.evidence)


def _stage2_info(d: SecurityDecision) -> Stage2Info:
    r = d.stage2
    return Stage2Info(
        executed=d.stage2_executed, skip_reason=d.stage2_skip_reason, status=d.stage2_status, provider=d.stage2_provider,
        simulator_version=config.SIMULATOR_VERSION if d.stage2_provider == stage2_simulator.PROVIDER else None,
        model=d.stage2_model if (d.stage2_executed and not d.stage2_simulated) else None,
        risk_score=r.risk_score if r else None, label=d.label, category=(r.category if r else None),
        confidence=r.confidence if r else d.confidence, flagged_uncertain=d.flagged_uncertain,
        features=[f.name for f in r.features] if r else [], error_code=d.stage2_error_code,
    )


def run_gateway(prompt: str, resolution: PolicyResolution, classifier: Optional[Classifier] = None,
                generator: Optional[Generator] = None) -> ChatResponse:
    """Full request path. Never raises for classifier/generator failures; they become status=ERROR."""
    t_total = time.perf_counter()
    policy = resolution.effective
    generator = generator or MockGenerator()
    gen_provider = getattr(generator, "provider", "LOCAL_MOCK_GENERATOR")
    live_generation = bool(getattr(generator, "live", False))
    live_stage2 = bool(getattr(classifier, "live", False))
    live = live_generation or live_stage2

    d = security_decision(prompt, policy, classifier)
    parts = dict(d.timings_ms)
    parts.update({"generation": 0.0, "output_validation": 0.0})

    def finish(status: str, action: str, *, output=None, block_reason: Optional[str] = None, error_code: Optional[str] = None,
               stage_triggered: Optional[str] = None, route: Optional[str] = None, risk: Optional[int] = None,
               reasoning: Optional[str] = None, retries: int = 0, generated: bool = False) -> ChatResponse:
        total = (time.perf_counter() - t_total) * 1000.0
        measured = sum(parts.values())
        breakdown = {k: round(v, 3) for k, v in parts.items()}
        breakdown["overhead"] = round(max(0.0, total - measured), 3)
        log = SecurityLog(
            stage_triggered=stage_triggered or d.stage_triggered, route=route or d.route,
            risk_score=d.risk_score if risk is None else risk, action=action,
            reasoning=reasoning if reasoning is not None else (block_reason or d.reason),
            category=d.category, execution_time_ms=round(total, 3), breakdown_ms=breakdown,
            stage1=_stage1_info(d.stage1), stage2=_stage2_info(d), risk_policy=_risk_policy_info(d.risk_policy),
            stage2_provider=d.stage2_provider,
            generation_provider=gen_provider if generated else None, timing_note=TIMING_NOTE,
        )
        return ChatResponse(
            status=status, output=output, block_reason=block_reason, error_code=error_code or d.error_code,
            security_metadata=log, bypassed_stage2=not d.stage2_executed, stage2_executed=d.stage2_executed,
            latency_ms=round(total, 3), retries_attempted=retries,
            execution_mode=config.EXECUTION_MODE_LIVE if live else config.EXECUTION_MODE_SIMULATION,
            simulated=SimulationFlags(stage2_simulated=d.stage2_simulated and not live_stage2,
                                      generation_simulated=not live_generation,
                                      note=SIM_NOTE if d.stage2_simulated else MODEL_NOTE),
            policy=resolution.report(), policy_version=config.POLICY_VERSION, simulator_version=config.SIMULATOR_VERSION,
        )

    if d.action == "BLOCK":
        return finish("BLOCKED", "BLOCKED", block_reason=d.reason)
    if d.action == "ERROR":
        return finish("ERROR", "ERROR", error_code=d.error_code, reasoning=d.reason)

    # --- generation, strict validation, bounded retry ---------------------------------------
    ctx = GenerationContext.build(prompt, d.stage1.route, d.stage2_executed,
                                  d.stage2.risk_score if d.stage2 else None, d.flagged_uncertain)
    t_gen = time.perf_counter()
    gen = generate_validated(generator, prompt, ctx, enforce_schema=policy.schema_enforcement)
    parts["generation"] = (time.perf_counter() - t_gen) * 1000.0
    if not gen.ok:
        return finish("ERROR", "ERROR", error_code=gen.error_code, stage_triggered="OUTPUT_VALIDATION", route=d.route,
                      reasoning=f"Generated output failed validation after {gen.retries} retry ({gen.error_code}); nothing was returned.",
                      retries=gen.retries, generated=True)

    # --- output guard ---------------------------------------------------------------------------
    t_out = time.perf_counter()
    finding = scan_output(output_text_for_scan(gen.output), policy)
    parts["output_validation"] = (time.perf_counter() - t_out) * 1000.0
    if finding is not None:
        msg = f"Output guard blocked: generated text contained sensitive data ({finding.label})"
        return finish("BLOCKED", "BLOCKED", block_reason=msg, stage_triggered="OUTPUT_GUARD", risk=90, retries=gen.retries, generated=True)

    return finish("SUCCESS", "PASSED", output=gen.output, retries=gen.retries, generated=True,
                  reasoning=d.reason or "All checks passed.")
