"""
Your own test list: every prompt typed into the gateway is added here automatically, so it can be evaluated later.

Design decisions (each one is a real trade-off, not an accident):

* A typed prompt has NO ground truth. The gateway's verdict is not a label (scoring a system against its own answers
  proves nothing), so each entry starts UNLABELLED and the user marks it "should block" or "should allow". Unlabelled entries
  are listed and run, but are reported as ambiguous and never counted in accuracy, precision or recall.
* Prompts containing PII or secrets are never stored. A gateway that blocks a card number and then writes it to disk
  would defeat its own purpose; those prompts are counted, not saved.
* Local only. The list lives in backend/data/ (git-ignored, excluded from the project zip). Recording is OFF by default
  when the server is bound to a network address, because the list is readable through an unauthenticated API.
* Bounded and de-duplicated. Identical prompts (case/whitespace-insensitive) are one entry with a counter; the list stops
  growing at MAX_ITEMS so an unauthenticated client cannot fill the disk.
* Separate from the frozen sets. Nothing here can touch the frozen holdout, the dev set or any hash-pinned file.
* Atomic writes (temp file + replace), one lock, and a corrupt file is set aside rather than silently overwritten.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import config
import detectors

DATA_DIR = config.BASE_DIR / "data"
DEFAULT_PATH = DATA_DIR / "user_prompts.json"
MAX_ITEMS = 2000
MAX_CHARS = 8000
LABELS = ("attack", "benign")
SCHEMA_VERSION = 1


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _key(prompt: str) -> str:
    return hashlib.sha256(" ".join(prompt.casefold().split()).encode("utf-8")).hexdigest()


def contains_sensitive_data(prompt: str) -> bool:
    """True if the prompt holds PII or a credential. Such prompts are never written to disk."""
    try:
        return bool(detectors.first_blocking_pii(prompt) or detectors.first_secret(prompt))
    except Exception:
        return True                                           # if in doubt, do not store


class PromptLog:
    def __init__(self, path: Path = DEFAULT_PATH, max_items: int = MAX_ITEMS):
        self.path = Path(path)
        self.max_items = max_items
        self._lock = threading.Lock()
        self.skipped_sensitive = 0
        self.skipped_full = 0

    # ---- storage ---------------------------------------------------------------------------
    def _read(self) -> Dict[str, object]:
        if not self.path.is_file():
            return {"version": SCHEMA_VERSION, "next_id": 1, "items": []}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if data.get("version") != SCHEMA_VERSION or not isinstance(data.get("items"), list):
                raise ValueError("unexpected structure")
            return data
        except Exception:
            self.path.replace(self.path.with_name(self.path.name + ".corrupt-" + datetime.now().strftime("%Y%m%d%H%M%S")))
            return {"version": SCHEMA_VERSION, "next_id": 1, "items": []}

    def _write(self, data: Dict[str, object]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=str(self.path.parent), prefix=".user_prompts_", suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
                json.dump(data, fh, indent=1, ensure_ascii=False)
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    # ---- operations ------------------------------------------------------------------------
    def record(self, prompt: str, decision: Dict[str, object]) -> Optional[Dict[str, object]]:
        """Add (or update) an entry. Returns the public item, or None when the prompt is not stored."""
        text = prompt.strip()
        if not text or len(text) > MAX_CHARS:
            return None
        if contains_sensitive_data(text):
            self.skipped_sensitive += 1
            return None
        key = _key(text)
        with self._lock:
            data = self._read()
            for item in data["items"]:
                if item["key"] == key:
                    item["times_seen"] += 1
                    item["last_seen_utc"] = _now()
                    item["last"] = decision
                    self._write(data)
                    return self._public(item)
            if len(data["items"]) >= self.max_items:
                self.skipped_full += 1
                return None
            item = {"id": f"USR-{data['next_id']:04d}", "key": key, "prompt": text, "label": None, "first_seen_utc": _now(),
                    "last_seen_utc": _now(), "times_seen": 1, "last": decision}
            data["next_id"] += 1
            data["items"].append(item)
            self._write(data)
            return self._public(item)

    @staticmethod
    def _public(item: Dict[str, object]) -> Dict[str, object]:
        return {k: v for k, v in item.items() if k != "key"}

    def items(self) -> List[Dict[str, object]]:
        with self._lock:
            return [self._public(i) for i in self._read()["items"]]

    def set_label(self, item_id: str, label: Optional[str]) -> bool:
        if label is not None and label not in LABELS:
            raise ValueError(f"label must be one of {LABELS} or null")
        with self._lock:
            data = self._read()
            for item in data["items"]:
                if item["id"] == item_id:
                    item["label"] = label
                    self._write(data)
                    return True
        return False

    def delete(self, item_id: str) -> bool:
        with self._lock:
            data = self._read()
            kept = [i for i in data["items"] if i["id"] != item_id]
            if len(kept) == len(data["items"]):
                return False
            data["items"] = kept
            self._write(data)
            return True

    def clear(self) -> int:
        with self._lock:
            data = self._read()
            n = len(data["items"])
            data["items"] = []
            self._write(data)
            return n

    def counts(self) -> Dict[str, int]:
        items = self.items()
        return {"total": len(items), "attack": sum(i["label"] == "attack" for i in items),
                "benign": sum(i["label"] == "benign" for i in items), "unlabelled": sum(i["label"] is None for i in items),
                "skipped_sensitive": self.skipped_sensitive, "skipped_list_full": self.skipped_full, "max_items": self.max_items}

    # ---- for the evaluator -----------------------------------------------------------------
    def as_rows(self) -> List[Dict[str, object]]:
        """Dataset rows. Unlabelled entries become REVIEW (shown, never scored)."""
        rows = []
        for i in self.items():
            label = i["label"]
            rows.append({"id": i["id"], "prompt": i["prompt"], "is_attack": label == "attack",
                         "category": {"attack": "USER_ATTACK", "benign": "USER_BENIGN"}.get(label, "USER_UNLABELLED"),
                         "expected": {"attack": "BLOCK", "benign": "PASS"}.get(label, "REVIEW")})
        return rows


def recording_enabled(s: Optional[config.Settings] = None) -> bool:
    s = s or config.settings
    if s.RECORD_PROMPTS == "on":
        return True
    if s.RECORD_PROMPTS == "off":
        return False
    return not s.binds_non_loopback                                 # "auto": only when the server is localhost-only


_logs: Dict[Path, PromptLog] = {}


def get_log(s: Optional[config.Settings] = None) -> PromptLog:
    """The process-wide list for the configured data folder (one PromptLog per path, so counters and the lock are shared)."""
    s = s or config.settings
    path = (Path(s.DATA_DIR).expanduser() if s.DATA_DIR else DATA_DIR) / "user_prompts.json"
    if path not in _logs:
        _logs[path] = PromptLog(path)
    return _logs[path]
