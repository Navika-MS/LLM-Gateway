"""
Central, validated configuration.

Principles (audit C1, H8, M2, M10):
  * The SERVER owns security policy. Clients may only make it stricter (see pipeline.resolve_policy).
  * Secure defaults. Anything that weakens security is off unless an operator opts in by env var.
  * Fail fast with a clear message on a bad value instead of crashing later in a request.
  * No secret is read unless the mode that needs it is explicitly enabled; no secret is ever logged.
  * One source of truth for every threshold (the old code had 65 hard-coded in two places and
    reported a different value from /health than it enforced).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Mapping, Optional

BASE_DIR = Path(__file__).resolve().parent

try:  # python-dotenv is a convenience, not a hard requirement
    from dotenv import load_dotenv

    # The test suite sets GATEWAY_SKIP_DOTENV=1 so tests are hermetic and never read a developer's real .env
    # (which may hold a live API key).
    if os.environ.get("GATEWAY_SKIP_DOTENV") != "1":
        load_dotenv(dotenv_path=BASE_DIR / ".env")
except Exception:  # pragma: no cover - missing package or unreadable file
    pass

# Bump when decision semantics change; both are stamped into every API response and every report.
POLICY_VERSION = "2.0.0"
SIMULATOR_VERSION = "2.0.0"

EXECUTION_MODE_SIMULATION = "LOCAL_SIMULATION"
EXECUTION_MODE_LIVE = "LIVE_PROVIDER"

TRUE = {"1", "true", "yes", "on"}
FALSE = {"0", "false", "no", "off"}


class ConfigError(ValueError):
    """Raised at start-up for an invalid environment value."""


def _bool(env: Mapping[str, str], name: str, default: bool) -> bool:
    raw = env.get(name)
    if raw is None or raw.strip() == "":
        return default
    v = raw.strip().lower()
    if v in TRUE:
        return True
    if v in FALSE:
        return False
    raise ConfigError(f"{name} must be one of {sorted(TRUE | FALSE)}, got {raw!r}")


def _int(env: Mapping[str, str], name: str, default: int, lo: int, hi: int) -> int:
    raw = env.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        value = int(raw.strip())
    except ValueError as exc:
        raise ConfigError(f"{name} must be an integer, got {raw!r}") from exc
    if not lo <= value <= hi:
        raise ConfigError(f"{name} must be between {lo} and {hi}, got {value}")
    return value


def _choice(env: Mapping[str, str], name: str, default: str, allowed: tuple) -> str:
    raw = env.get(name)
    if raw is None or raw.strip() == "":
        return default
    v = raw.strip().lower()
    if v not in allowed:
        raise ConfigError(f"{name} must be one of {list(allowed)}, got {raw!r}")
    return v


STAGE2_BACKEND_PARTS = ("simulator", "deberta", "deberta_onnx")


def _stage2_backend(env: Mapping[str, str]) -> str:
    raw = (env.get("GATEWAY_STAGE2_BACKEND") or "simulator").strip().lower()
    parts = [p.strip() for p in raw.split("+")]
    if not parts or any(p not in STAGE2_BACKEND_PARTS for p in parts) or len(set(parts)) != len(parts):
        raise ConfigError(f"GATEWAY_STAGE2_BACKEND must be one of {list(STAGE2_BACKEND_PARTS)} or a '+'-joined combination "
                          f"of distinct ones (e.g. 'simulator+deberta'), got {raw!r}")
    if "deberta" in parts and "deberta_onnx" in parts:
        raise ConfigError("GATEWAY_STAGE2_BACKEND may use 'deberta' or 'deberta_onnx', not both")
    return "+".join(parts)


def _list(env: Mapping[str, str], name: str, default: List[str]) -> List[str]:
    raw = env.get(name)
    if raw is None or raw.strip() == "":
        return list(default)
    items = [p.strip() for p in raw.split(",") if p.strip()]
    if any(i == "*" for i in items):
        raise ConfigError(f"{name} must list explicit origins; '*' is not allowed")
    return items


@dataclass(frozen=True)
class Settings:
    # --- server ---------------------------------------------------------------------------
    HOST: str = "127.0.0.1"
    PORT: int = 8000
    CORS_ORIGINS: List[str] = field(default_factory=lambda: ["http://localhost:5173", "http://127.0.0.1:5173"])

    # --- execution mode -------------------------------------------------------------------
    GATEWAY_MODE: str = "simulation"          # "simulation" (default, free) | "live" (opt-in, paid)
    CONFIRM_PAID_CALLS: bool = False          # must also be true for live mode to start
    PRIMARY_MODEL: str = "claude-3-5-sonnet-20241022"
    CLASSIFIER_MODEL: str = "claude-3-haiku-20240307"
    API_TIMEOUT_SECONDS: float = 25.0

    # --- limits ---------------------------------------------------------------------------
    MAX_PROMPT_CHARS: int = 8000
    MAX_BODY_BYTES: int = 64 * 1024
    MAX_OUTPUT_CHARS: int = 20000
    MAX_OUTPUT_RETRIES: int = 1               # 0 or 1. Bounded by construction (audit: no retry loops)
    EVAL_MAX_CASES: int = 500

    # --- server-owned security policy ----------------------------------------------------
    PII_CHECK: bool = True
    INJECTION_CHECK: bool = True
    AI_CLASSIFIER_CHECK: bool = True
    SCHEMA_ENFORCEMENT: bool = True
    OUTPUT_PII_CHECK: bool = True
    RISK_THRESHOLD: int = 65                  # block iff risk_score is STRICTLY GREATER than this
    UNCERTAIN_LOW: int = 40                   # [UNCERTAIN_LOW, RISK_THRESHOLD] is the "uncertain" band
    UNCERTAIN_ACTION: str = "flag"            # "flag" (pass + mark) | "block"
    STAGE2_ERROR_POLICY: str = "block"        # fail closed by default: "block" | "allow"
    SENSITIVE_DATA_POLICY: str = "block"      # risk_policy.py: "off" | "flag" | "block"
    DESTRUCTIVE_ACTION_POLICY: str = "block"  # risk_policy.py: "off" | "flag" | "block"

    # --- Stage 2 backend (which classifier answers "is this an attack?") -------------------
    # "simulator" (default; deterministic heuristics, no downloads) | "deberta" (PyTorch) | "deberta_onnx"
    # or a "+"-joined ensemble such as "simulator+deberta" (highest risk wins). Models are loaded from a LOCAL
    # folder only (`python manage.py setup-model` downloads it); the server never fetches anything by itself.
    STAGE2_BACKEND: str = "simulator"
    STAGE2_MODEL_DIR: str = ""                # default: backend/models/deberta-v3-base-prompt-injection-v2
    STAGE2_ONNX_FILE: str = "onnx/model.onnx" # relative to the model folder
    STAGE2_THREADS: int = 0                   # 0 = library default
    STAGE2_MAX_WINDOWS: int = 12              # 512-token windows per input; longer input fails closed (ERROR)

    # --- your own test list (prompt_log.py) ---------------------------------------------------
    # "auto" records typed prompts only while the server is bound to localhost; "on" / "off" force it.
    RECORD_PROMPTS: str = "auto"
    DATA_DIR: str = ""                        # default: backend/data (git-ignored; never part of the project zip)

    # --- demo-only relaxations (OFF by default; never enable on a shared deployment) -------
    ALLOW_CLIENT_POLICY_OVERRIDE: bool = False
    ENABLE_EVALUATE_ENDPOINT: bool = True

    # --- secret (read only in live mode) -------------------------------------------------
    _ANTHROPIC_API_KEY: str = field(default="", repr=False)

    @property
    def live_mode_requested(self) -> bool:
        return self.GATEWAY_MODE == "live"

    @property
    def execution_mode(self) -> str:
        return EXECUTION_MODE_LIVE if self.live_mode_requested and self.CONFIRM_PAID_CALLS else EXECUTION_MODE_SIMULATION

    @property
    def anthropic_api_key(self) -> str:
        """Only available when live mode is explicitly requested. Never log this value."""
        return self._ANTHROPIC_API_KEY if self.live_mode_requested else ""

    @property
    def binds_non_loopback(self) -> bool:
        return self.HOST not in ("127.0.0.1", "localhost", "::1")

    def is_anthropic_configured(self) -> bool:
        key = self.anthropic_api_key
        return bool(key and key != "your_api_key_here" and len(key) > 10)

    @classmethod
    def from_env(cls, env: Optional[Mapping[str, str]] = None) -> "Settings":
        env = os.environ if env is None else env
        # STAGE2_RISK_THRESHOLD is the pre-audit name; honoured as an alias so existing .env files keep working.
        legacy = _int(env, "STAGE2_RISK_THRESHOLD", 65, 1, 100)
        threshold = _int(env, "GATEWAY_RISK_THRESHOLD", legacy, 1, 100)
        low = _int(env, "GATEWAY_UNCERTAIN_LOW", min(40, threshold - 1), 0, 100)
        if low >= threshold:
            raise ConfigError(f"GATEWAY_UNCERTAIN_LOW ({low}) must be below GATEWAY_RISK_THRESHOLD ({threshold})")
        mode = _choice(env, "GATEWAY_MODE", "simulation", ("simulation", "live"))
        confirm = _bool(env, "GATEWAY_CONFIRM_PAID_CALLS", False)
        if mode == "live" and not confirm:
            raise ConfigError(
                "GATEWAY_MODE=live makes paid API calls. Set GATEWAY_CONFIRM_PAID_CALLS=yes to confirm, "
                "or leave GATEWAY_MODE unset for the free local simulation."
            )
        return cls(
            HOST=env.get("HOST", "127.0.0.1").strip() or "127.0.0.1",
            PORT=_int(env, "PORT", 8000, 1, 65535),
            CORS_ORIGINS=_list(env, "GATEWAY_CORS_ORIGINS", ["http://localhost:5173", "http://127.0.0.1:5173"]),
            GATEWAY_MODE=mode,
            CONFIRM_PAID_CALLS=confirm,
            PRIMARY_MODEL=env.get("PRIMARY_MODEL", "claude-3-5-sonnet-20241022").strip(),
            CLASSIFIER_MODEL=env.get("CLASSIFIER_MODEL", "claude-3-haiku-20240307").strip(),
            MAX_PROMPT_CHARS=_int(env, "GATEWAY_MAX_PROMPT_CHARS", 8000, 100, 100_000),
            MAX_BODY_BYTES=_int(env, "GATEWAY_MAX_BODY_BYTES", 64 * 1024, 1024, 4 * 1024 * 1024),
            MAX_OUTPUT_RETRIES=_int(env, "GATEWAY_MAX_OUTPUT_RETRIES", 1, 0, 1),
            EVAL_MAX_CASES=_int(env, "GATEWAY_EVAL_MAX_CASES", 500, 1, 5000),
            PII_CHECK=_bool(env, "GATEWAY_PII_CHECK", True),
            INJECTION_CHECK=_bool(env, "GATEWAY_INJECTION_CHECK", True),
            AI_CLASSIFIER_CHECK=_bool(env, "GATEWAY_AI_CLASSIFIER_CHECK", True),
            SCHEMA_ENFORCEMENT=_bool(env, "GATEWAY_SCHEMA_ENFORCEMENT", True),
            OUTPUT_PII_CHECK=_bool(env, "GATEWAY_OUTPUT_PII_CHECK", True),
            RISK_THRESHOLD=threshold,
            UNCERTAIN_LOW=low,
            UNCERTAIN_ACTION=_choice(env, "GATEWAY_UNCERTAIN_ACTION", "flag", ("flag", "block")),
            STAGE2_ERROR_POLICY=_choice(env, "GATEWAY_STAGE2_ERROR_POLICY", "block", ("block", "allow")),
            SENSITIVE_DATA_POLICY=_choice(env, "GATEWAY_SENSITIVE_DATA_POLICY", "block", ("off", "flag", "block")),
            DESTRUCTIVE_ACTION_POLICY=_choice(env, "GATEWAY_DESTRUCTIVE_ACTION_POLICY", "block", ("off", "flag", "block")),
            STAGE2_BACKEND=_stage2_backend(env),
            STAGE2_MODEL_DIR=env.get("GATEWAY_STAGE2_MODEL_DIR", "").strip(),
            STAGE2_ONNX_FILE=(env.get("GATEWAY_STAGE2_ONNX_FILE", "") or "onnx/model.onnx").strip(),
            STAGE2_THREADS=_int(env, "GATEWAY_STAGE2_THREADS", 0, 0, 64),
            STAGE2_MAX_WINDOWS=_int(env, "GATEWAY_STAGE2_MAX_WINDOWS", 12, 1, 64),
            RECORD_PROMPTS=_choice(env, "GATEWAY_RECORD_PROMPTS", "auto", ("auto", "on", "off")),
            DATA_DIR=env.get("GATEWAY_DATA_DIR", "").strip(),
            ALLOW_CLIENT_POLICY_OVERRIDE=_bool(env, "GATEWAY_ALLOW_CLIENT_POLICY", False),
            ENABLE_EVALUATE_ENDPOINT=_bool(env, "GATEWAY_ENABLE_EVALUATE", True),
            _ANTHROPIC_API_KEY=env.get("ANTHROPIC_API_KEY", "").strip(),
        )


settings = Settings.from_env()
