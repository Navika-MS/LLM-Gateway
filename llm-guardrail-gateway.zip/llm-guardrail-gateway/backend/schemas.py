"""
Typed contracts: requests, the server-owned policy, responses and evaluation reports.

Audit fixes encoded here:
  * C1/M7  request models are `extra="forbid"` and fully typed: unknown or invalid fields are a 422,
           never a silently ignored typo and never a 500 raised from inside a handler.
  * C3/M6  prompt length is bounded and whitespace-only prompts are rejected after stripping.
  * M1     `bypassed_stage2` has ONE meaning: "Stage 2 did not execute"; `stage2_skip_reason` says why.
  * M4     `execution_time_ms` is the single end-to-end pipeline time; `breakdown_ms` is its breakdown.
  * L4     statuses, actions, routes and categories are Literals, not free strings.
  * H3     the output model is strict, so wrong types and missing fields are really rejected.
"""
from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator

from config import settings

# ------------------------------------------------------------------------------------------------
# Enumerations
# ------------------------------------------------------------------------------------------------

Status = Literal["SUCCESS", "BLOCKED", "ERROR"]
Action = Literal["PASSED", "BLOCKED", "ERROR"]
Stage1Route = Literal["BLOCK", "SUSPICIOUS", "CLEAN"]
Stage2Label = Literal["BENIGN", "UNCERTAIN", "MALICIOUS"]
Confidence = Literal["HIGH", "MEDIUM", "LOW"]
StageTriggered = Literal[
    "STAGE_1_DETERMINISTIC",
    "STAGE_2_CLASSIFIER",
    "ESCALATION_UNAVAILABLE",
    "STAGE_2_ERROR",
    "OUTPUT_GUARD",
    "OUTPUT_VALIDATION",
    "RISK_POLICY",
    "NONE_PASSED",
]
Route = Literal[
    "STAGE_1_BLOCK",
    "RISK_POLICY_BLOCK",
    "STAGE_2_BLOCK",
    "STAGE_2_PASS",
    "STAGE_2_PASS_FLAGGED",
    "STAGE_1_ONLY_PASS",
    "ESCALATION_UNAVAILABLE_BLOCK",
    "STAGE_2_ERROR_BLOCK",
    "STAGE_2_ERROR_ALLOWED",
]
Stage2SkipReason = Literal["STAGE_1_BLOCKED", "DISABLED_BY_POLICY", "RISK_POLICY_BLOCKED"]
PolicyMode = Literal["off", "flag", "block"]
ThreatCategory = Literal[
    "BENIGN",
    "DIRECT_JAILBREAK",
    "INSTRUCTION_OVERRIDE",
    "PROMPT_EXTRACTION",
    "DATA_EXFILTRATION",
    "INDIRECT_INJECTION",
    "POLICY_EVASION",
    "ENCODED_PAYLOAD",
    "PII_LEAK",
    "SECRET_LEAK",
    "PROMPT_INJECTION",
    "SENSITIVE_DATA_REQUEST",
    "DESTRUCTIVE_ACTION",
]


# ------------------------------------------------------------------------------------------------
# Policy
# ------------------------------------------------------------------------------------------------


class Policy(BaseModel):
    """The effective, validated security policy applied to one request."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    pii_check: bool = True
    injection_check: bool = True
    ai_classifier_check: bool = True
    schema_enforcement: bool = True
    output_pii_check: bool = True
    risk_threshold: int = Field(default=65, ge=1, le=100,
                                description="Block iff risk_score is STRICTLY GREATER than this value.")
    uncertain_low: int = Field(default=40, ge=0, le=99,
                               description="risk_score in [uncertain_low, risk_threshold] is 'uncertain'.")
    uncertain_action: Literal["flag", "block"] = "flag"
    stage2_error_policy: Literal["block", "allow"] = "block"
    # Risk-policy layer (risk_policy.py): server-owned only; a client cannot set or weaken these.
    sensitive_data_policy: PolicyMode = "block"
    destructive_action_policy: PolicyMode = "block"


class ClientPolicyRequest(BaseModel):
    """What a client MAY ask for. It is a request, not a command: the server decides (see
    pipeline.resolve_policy). Unknown keys are rejected."""

    model_config = ConfigDict(extra="forbid")

    pii_check: Optional[bool] = None
    injection_check: Optional[bool] = None
    ai_classifier_check: Optional[bool] = None
    schema_enforcement: Optional[bool] = None
    output_pii_check: Optional[bool] = None
    risk_threshold: Optional[int] = Field(default=None, ge=1, le=100)


class PolicyReport(BaseModel):
    """Reported in every response so a caller can see exactly which policy decided its request."""

    effective: Policy
    source: Literal["SERVER", "SERVER_PLUS_CLIENT_TIGHTENING", "CLIENT_OVERRIDE_DEMO"]
    applied: List[str] = Field(default_factory=list, description="Client requests that were honoured.")
    rejected: List[str] = Field(default_factory=list, description="Client requests the server refused.")
    warnings: List[str] = Field(default_factory=list)


# ------------------------------------------------------------------------------------------------
# Request
# ------------------------------------------------------------------------------------------------


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    prompt: str = Field(..., max_length=settings.MAX_PROMPT_CHARS,
                        description="User prompt to analyse (stripped; must not be blank).")
    guardrails_enabled: Optional[ClientPolicyRequest] = Field(
        default=None, description="Optional request to TIGHTEN policy. Cannot weaken the server policy.")
    enforce_schema: Optional[bool] = Field(default=None, description="Server policy decides; see /api/v1/policy.")

    @field_validator("prompt")
    @classmethod
    def _prompt_not_blank(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("prompt must contain non-whitespace characters")
        if "\x00" in v:
            raise ValueError("prompt must not contain NUL characters")
        return v


# ------------------------------------------------------------------------------------------------
# Generated output (strict on purpose: this model is the real schema gate)
# ------------------------------------------------------------------------------------------------


class StructuredResponse(BaseModel):
    """Schema the (simulated or real) generator must satisfy. Strict: no coercion, no extra keys."""

    model_config = ConfigDict(strict=True, extra="forbid")

    summary: str = Field(..., min_length=1, max_length=2000)
    risk_score: int = Field(..., ge=1, le=10, description="Content sensitivity index 1-10 (not the security score).")
    key_points: List[str] = Field(..., min_length=1, max_length=20)

    @field_validator("key_points")
    @classmethod
    def _bounded_points(cls, v: List[str]) -> List[str]:
        if any(len(p) > 500 for p in v):
            raise ValueError("each key point must be at most 500 characters")
        return v


# ------------------------------------------------------------------------------------------------
# Response
# ------------------------------------------------------------------------------------------------


class Stage1Info(BaseModel):
    route: Stage1Route
    category: Optional[ThreatCategory] = None
    reason: Optional[str] = None
    signals: List[str] = Field(default_factory=list)


class Stage2Info(BaseModel):
    executed: bool
    skip_reason: Optional[Stage2SkipReason] = None
    status: Literal["OK", "ERROR", "SKIPPED"]
    provider: str
    simulator_version: Optional[str] = None
    model: Optional[str] = Field(default=None, description="Model id when Stage 2 is a trained model.")
    risk_score: Optional[int] = Field(default=None, ge=0, le=100)
    label: Optional[Stage2Label] = None
    category: Optional[ThreatCategory] = None
    confidence: Optional[Confidence] = None
    flagged_uncertain: bool = False
    features: List[str] = Field(default_factory=list)
    error_code: Optional[str] = None


class RiskPolicyInfo(BaseModel):
    """What the sensitive-data / destructive-action layer found (never the prompt text)."""

    category: ThreatCategory
    action: Literal["BLOCK", "FLAG"]
    rule: str
    evidence: str


class SecurityLog(BaseModel):
    stage_triggered: StageTriggered
    route: Route
    risk_score: int = Field(ge=0, le=100)
    action: Action
    reasoning: Optional[str] = None
    category: Optional[ThreatCategory] = None
    execution_time_ms: float = Field(description="End-to-end pipeline time, one perf_counter span.")
    breakdown_ms: Dict[str, float] = Field(default_factory=dict)
    stage1: Stage1Info
    stage2: Stage2Info
    risk_policy: Optional[RiskPolicyInfo] = None
    stage2_provider: str
    generation_provider: Optional[str] = None
    timing_note: str = ("Measured local processing time of the simulated components. "
                        "It is NOT large-language-model inference latency.")


class SimulationFlags(BaseModel):
    stage2_simulated: bool
    generation_simulated: bool
    note: str


class ChatResponse(BaseModel):
    status: Status
    output: Optional[Union[StructuredResponse, str]] = None
    block_reason: Optional[str] = None
    error_code: Optional[str] = None
    security_metadata: SecurityLog
    bypassed_stage2: bool = Field(description="True iff Stage 2 did NOT execute (see stage2_skip_reason).")
    stage2_executed: bool
    latency_ms: float = Field(description="Alias of security_metadata.execution_time_ms.")
    retries_attempted: int = Field(default=0, ge=0, le=1)
    execution_mode: str
    simulated: SimulationFlags
    policy: PolicyReport
    policy_version: str
    simulator_version: str
    recorded_prompt_id: Optional[str] = Field(
        default=None, description="Id of this prompt in your saved test list (set only when recording is on and the prompt is storable).")


class PolicyInfo(BaseModel):
    """GET /api/v1/policy: lets the UI show which controls are locked by the server."""

    execution_mode: str
    server_policy: Policy
    client_override_allowed: bool
    limits: Dict[str, int]
    policy_version: str
    simulator_version: str
    stage2_provider: str
    generation_provider: str
    notes: List[str]


# ------------------------------------------------------------------------------------------------
# Evaluation
# ------------------------------------------------------------------------------------------------


class ConfusionMatrix(BaseModel):
    tp: int = 0
    fp: int = 0
    tn: int = 0
    fn: int = 0


class ClassificationMetrics(BaseModel):
    """Percentages (0-100) or None when undefined (never a fake 0 or 100)."""

    accuracy: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None
    false_positive_rate: Optional[float] = None
    f1: Optional[float] = None


class CategoryMetrics(BaseModel):
    category: str
    role: Literal["attack", "benign", "ambiguous"]
    total: int
    blocked: int
    passed: int
    flagged_uncertain: int
    errors: int
    rate_label: str = Field(description="What `rate_percent` means: recall, false-positive rate, or block rate.")
    rate_percent: Optional[float] = None


class RouteBreakdown(BaseModel):
    stage1_blocks: int = 0
    risk_policy_blocks: int = 0
    stage2_blocks: int = 0
    passed_stage2_clear: int = 0
    passed_flagged_uncertain: int = 0
    passed_stage1_only: int = 0
    escalation_unavailable_blocks: int = 0
    stage2_error_blocks: int = 0
    errors: int = 0


class CaseResult(BaseModel):
    id: str
    category: str
    expected: Literal["BLOCK", "PASS", "REVIEW"]
    actual: Literal["BLOCK", "PASS", "ERROR"]
    outcome: Literal["TP", "FP", "TN", "FN", "ERROR", "REVIEW"]
    route: Optional[str] = None
    risk_score: Optional[int] = None
    flagged_uncertain: bool = False
    reason: Optional[str] = None
    latency_ms: float = 0.0
    prompt: Optional[str] = Field(default=None, description="Omitted for the frozen holdout.")
    error_code: Optional[str] = None


class DatasetInfo(BaseModel):
    name: str
    split: Literal["dev", "regression", "holdout", "legacy", "unseen", "user"]
    path: str
    sha256: str
    case_count: int
    attack_count: int
    benign_count: int
    ambiguous_count: int
    seed: Optional[int] = None
    expected_sha256: Optional[str] = None
    hash_verified: Optional[bool] = None
    distinct_prompts: int
    warnings: List[str] = Field(default_factory=list)


class ReliabilityMetrics(BaseModel):
    """Application reliability, reported separately from classification quality."""

    evaluated_cases: int
    error_cases: int
    error_rate_percent: Optional[float] = None


class LatencyStats(BaseModel):
    avg_ms: Optional[float] = None
    p50_ms: Optional[float] = None
    p95_ms: Optional[float] = None
    max_ms: Optional[float] = None
    note: str = "Local simulator compute time; not LLM inference latency."


class CostReport(BaseModel):
    applicable: bool = False
    note: str = "Not applicable: no paid API calls are made in local simulation mode."


class EvaluationReport(BaseModel):
    dataset: DatasetInfo
    policy: Policy
    policy_version: str
    simulator_version: str
    code_fingerprint: str = Field(description="SHA-256 over the decision-logic source files that produced this report.")
    execution_mode: str
    stage2_provider: str = "LOCAL_HEURISTIC_SIMULATOR"
    generated_at: str
    metrics: ClassificationMetrics
    operating_point: str
    strict_operating_point_metrics: Optional[ClassificationMetrics] = None
    confusion_matrix: ConfusionMatrix
    routes: RouteBreakdown
    categories: List[CategoryMetrics]
    reliability: ReliabilityMetrics
    latency: LatencyStats
    cost: CostReport = Field(default_factory=CostReport)
    missed_attacks: List[CaseResult] = Field(default_factory=list)
    false_positives: List[CaseResult] = Field(default_factory=list)
    ambiguous_summary: Optional[Dict[str, int]] = None
    sample_results: List[CaseResult] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)


class EvaluationRequestInfo(BaseModel):
    datasets: List[str]
    default: str
    note: str


Json = Dict[str, Any]
