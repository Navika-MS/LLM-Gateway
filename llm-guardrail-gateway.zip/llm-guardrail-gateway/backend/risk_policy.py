"""
Risk-policy layer: SENSITIVE-DATA requests and DESTRUCTIVE-ACTION commands.

Why this is a separate layer and not more Stage 2 vocabulary
------------------------------------------------------------
A prompt-injection classifier (the simulator or a trained model) answers "is this text trying to subvert the
assistant?". "Send me the trade secret of the organization" and "erase the main db and replace it" are not
injections: they are requests for confidential data and for an irreversible action. They need a different
question ("is somebody commanding this system to hand over or destroy something that matters?") and a
different, auditable rule set whose behaviour does not change when the Stage 2 backend is swapped.

How it decides (deterministic, linear time, explainable)
--------------------------------------------------------
Everything is relational, not a phrase blacklist:

  COMMAND   the sentence must be an instruction to the assistant: its first real word is an action verb
            (after polite filler such as "please", "can you", "I want you to"). Questions, explanations,
            "write a script that ...", negations ("never delete ...") and quotations fail this test, which
            is what keeps education, how-to and protective text out of scope.
  OBJECT    destructive verb + a data store (database, backups, server ...) or an extraction verb + a
            sensitive-data noun phrase (trade secret, confidential/proprietary/internal <data>, customer
            records ...).
  SCOPE     production / organisation scope (main, live, company, all, entire ...) raises a finding to
            BLOCK level; without it the finding is FLAG level. Test / staging / sandbox / local targets,
            partial objects (rows, columns, duplicates) and "example / template" objects are exempt.

Syntax-level destructive commands (DROP DATABASE, rm -rf /, format c:, DELETE FROM t;) are matched directly
unless an explanatory frame ("explain what ...", "why is ... dangerous") precedes them.

Limits, stated plainly: English only; no semantic understanding; a rephrasing the rules do not anticipate
passes; it cannot know whether the requester is authorised. It reports what it matched (rule name and the
lexicon words involved, never the prompt text) so every decision is auditable.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

from normalization import NormalizedText
from schemas import Policy

SENSITIVE = "SENSITIVE_DATA_REQUEST"
DESTRUCTIVE = "DESTRUCTIVE_ACTION"
BLOCK_LEVEL = "BLOCK_LEVEL"
FLAG_LEVEL = "FLAG_LEVEL"

# Findings carry a risk number so they sort and report like any other stage.
RISK_BLOCK = 92
RISK_FLAG = 60


@dataclass(frozen=True)
class RiskFinding:
    category: str            # SENSITIVE_DATA_REQUEST | DESTRUCTIVE_ACTION
    level: str               # BLOCK_LEVEL | FLAG_LEVEL (what the rule found, before the server policy is applied)
    action: str              # BLOCK | FLAG (what the server policy makes of it)
    rule: str
    evidence: str            # lexicon words matched; never raw prompt text

    @property
    def risk_score(self) -> int:
        return RISK_BLOCK if self.action == "BLOCK" else RISK_FLAG


# ------------------------------------------------------------------------------------------------
# Tokenisation
# ------------------------------------------------------------------------------------------------

_WORD = re.compile(r"[a-z0-9_]+(?:'[a-z]+)?")
_SENTENCE = re.compile(r"[.!?;\n]+|,\s*then\b")


def _tokens(s: str) -> List[str]:
    out: List[str] = []
    for m in _WORD.finditer(s):
        t = m.group(0)
        if t.endswith("'s"):
            t = t[:-2]
        out.append(t.replace("'", ""))
    return out


def _sing(t: str) -> str:
    """Crude singular form for MEMBERSHIP tests only (records -> record, salaries -> salary, databases -> database)."""
    if len(t) > 4 and t.endswith("ies"):
        return t[:-3] + "y"
    return t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t


def _any(tokens: Sequence[str], vocabulary: frozenset) -> List[str]:
    return [t for t in tokens if t in vocabulary or _sing(t) in vocabulary]


# ------------------------------------------------------------------------------------------------
# Shared vocabulary: what may precede the command verb
# ------------------------------------------------------------------------------------------------

# Words allowed BEFORE the command verb. Anything else (how, what, explain, write, never, ...) means the
# sentence is not a direct command and is out of scope for this layer.
FILLER = frozenset("""
please pls plz kindly just now then also and go ahead quickly immediately first next finally you must should will
shall need needs to can could would may i want wanna like ask hey hi hello ok okay so right asap urgently do it
have let lets us we if possible thanks thank proceed continue carry out the your our me assistant bot ai admin
administrator system after that afterwards subsequently task step action goal objective job take down
""".split())

CONJ = frozenset({"and", "then", "also", "please", "now", "just", "quickly", "immediately", "first", "next"})

# ------------------------------------------------------------------------------------------------
# Destructive actions
# ------------------------------------------------------------------------------------------------

DESTROY_VERBS = frozenset("""
delete erase wipe destroy drop truncate purge nuke obliterate shred annihilate format overwrite remove clear
kill scrub empty reset
""".split())
WEAK_DESTROY_VERBS = frozenset({"remove", "clear", "reset", "empty"})   # only count with an explicit scope word
WRAPPER_VERBS = frozenset({"run", "execute", "perform"})
# "make the main database empty", "get rid of the production database"
EMPTYING_VERBS = frozenset({"make", "leave", "turn"})
EMPTY_WORDS = frozenset({"empty", "blank", "nothing", "zero"})

STORES = frozenset("""
db database datastore warehouse table schema server backup disk drive partition volume bucket cluster repository
repo record data log audit history system environment infrastructure filesystem snapshot archive prod
""".split())
INFRA = frozenset("""
db database datastore warehouse server backup disk drive partition volume bucket cluster repository repo system
environment infrastructure filesystem snapshot archive
""".split())
STRONG_SCOPE = frozenset("""
main primary production prod live master company organization organisation corporate central core shared
enterprise customer client
""".split())
GENERIC_SCOPE = frozenset("""
all every entire whole everything complete full permanently irreversibly forever
""".split())
SAFE_TARGET = frozenset("""
test tests testing staging dev development sandbox local temp tmp temporary scratch sample demo mock fake dummy
cache cached download downloads desktop trash recycle
""".split())
PARTIAL_OBJECT = frozenset("""
row column field cell line sentence paragraph word entry item duplicate unused unneeded orphaned stale expired
older obsolete comment
""".split())
DECLARATIVE_NEXT = frozenset("is are was were has have will can does do should would may might".split())
PREPOSITIONS = frozenset({"from", "in", "on", "of", "off", "at", "within", "inside", "with", "by", "for", "across", "into"})

# Syntax-level destructive commands, matched on the normalised text.
_DESTRUCTIVE_SYNTAX: Tuple[Tuple[str, "re.Pattern[str]"], ...] = (
    ("sql_drop_database_or_table", re.compile(r"\bdrop\s+(?:database|table|schema)\b")),
    ("sql_truncate_table", re.compile(r"\btruncate\s+table\b")),
    ("sql_delete_without_where", re.compile(r"\bdelete\s+from\s+[\w.`\"\[\]]+\s*(?:;|$)(?!.*\bwhere\b)")),
    ("shell_rm_recursive_root", re.compile(r"\brm\s+-[a-z]*r[a-z]*\s+(?:--no-preserve-root\s+)?(?:/\*?|~/?|\*|\$home)(?=\s|$|;)")),
    ("windows_format_drive", re.compile(r"\bformat\s+(?:the\s+)?(?:[a-z]:|[a-z]\s+drive)")),
    ("shell_mkfs_or_dd", re.compile(r"\b(?:mkfs(?:\.\w+)?\s+/dev/|dd\s+if=\S+\s+of=/dev/)")),
    ("windows_recursive_delete", re.compile(r"\b(?:del\s+/[fsq]\b|rmdir\s+/s\b|remove-item\b.*-recurse)")),
)
# A frame in the 90 characters before a syntax match means the command is being discussed, not issued.
_EXPLANATORY_FRAME = re.compile(
    r"\b(?:explain|what(?:'s)?\s+(?:is|does|do)|what\s+happens|how\s+(?:do|does|to|can|should|would)|why|difference\s+between|"
    r"meaning\s+of|example\s+of|tutorial|syntax|understand|describe|teach|learn|dangerous|risky|safe(?:ly)?|prevent|"
    r"avoid|never|dont|do\s+not|careful|warning|accidental(?:ly)?|recover|restore|protect|guard\s+against|means)\b")


def _command_start(tokens: Sequence[str], verbs: frozenset) -> Optional[int]:
    """Index of the first real word if it is one of `verbs`, after skipping polite/modal filler; else None."""
    i = 0
    while i < len(tokens) and i < 9 and tokens[i] in FILLER and tokens[i] not in verbs:
        i += 1
    return i if i < len(tokens) and tokens[i] in verbs else None


def _emptying(tokens: Sequence[str]) -> Optional[RiskFinding]:
    """'make the main database empty' / 'leave the production server blank': destruction phrased as a state change."""
    start = _command_start(tokens, EMPTYING_VERBS)
    if start is None:
        return None
    rest = list(tokens[start + 1:start + 10])
    if not _any(rest, EMPTY_WORDS):
        return None
    stores, strong = _any(rest, STORES), _any(rest, STRONG_SCOPE)
    if stores and strong and not _any(rest, SAFE_TARGET):
        return RiskFinding(DESTRUCTIVE, BLOCK_LEVEL, "BLOCK", "destructive_command_emptying",
                           f"verb={tokens[start]} target={sorted(set(map(_sing, stores)))[:3]} scope={sorted(set(map(_sing, strong)))[:3]}")
    return None


def _destructive_syntax(text: str) -> Optional[RiskFinding]:
    for rule, pattern in _DESTRUCTIVE_SYNTAX:
        for m in pattern.finditer(text):
            before = text[max(0, m.start() - 90):m.start()]
            if _EXPLANATORY_FRAME.search(before):
                continue
            return RiskFinding(DESTRUCTIVE, BLOCK_LEVEL, "BLOCK", "destructive_syntax:" + rule, "command syntax")
    return None


def _destructive_sentence(tokens: Sequence[str]) -> Optional[RiskFinding]:
    # "get rid of X" is "delete X": rewrite the three-word verb so the rest of the logic sees a single verb.
    for i in range(len(tokens) - 2):
        if tokens[i:i + 3] == ["get", "rid", "of"]:
            tokens = list(tokens[:i]) + ["delete"] + list(tokens[i + 3:])
            break
    emptied = _emptying(tokens)
    if emptied is not None:
        return emptied
    start = _command_start(tokens, DESTROY_VERBS | WRAPPER_VERBS)
    if start is None:
        return None
    verb_positions = [p for p, t in enumerate(tokens)
                      if t in DESTROY_VERBS and p >= start and (p == start or tokens[p - 1] in CONJ or tokens[p - 1] in WRAPPER_VERBS)]
    best: Optional[RiskFinding] = None
    for p in verb_positions:
        verb = tokens[p]
        if p + 1 < len(tokens) and tokens[p + 1] in DECLARATIVE_NEXT:
            continue                                      # "`format` is the archive format ...": a statement, not a command
        window: List[str] = []
        for t in tokens[p + 1:p + 13]:
            if t in DESTROY_VERBS and window:
                break
            window.append(t)
        obj: List[str] = []
        for t in window:
            if t in PREPOSITIONS and obj:
                break
            obj.append(t)
        stores = _any(window, STORES)
        if not stores:
            continue
        if _any(window, SAFE_TARGET) or _any(obj, PARTIAL_OBJECT):
            continue
        strong = _any(window, STRONG_SCOPE)
        generic = _any(window, GENERIC_SCOPE)
        infra = [s for s in stores if s in INFRA or _sing(s) in INFRA]
        if verb in WEAK_DESTROY_VERBS and not (strong or generic):
            continue
        if strong or (generic and infra):
            found = RiskFinding(DESTRUCTIVE, BLOCK_LEVEL, "BLOCK", "destructive_command_broad_scope",
                                f"verb={verb} target={sorted(set(map(_sing, stores)))[:3]} scope={sorted(set(map(_sing, strong + generic)))[:3]}")
        else:
            found = RiskFinding(DESTRUCTIVE, FLAG_LEVEL, "FLAG", "destructive_command_data_store",
                                f"verb={verb} target={sorted(set(map(_sing, stores)))[:3]}")
        if best is None or (best.level == FLAG_LEVEL and found.level == BLOCK_LEVEL):
            best = found
    return best


# ------------------------------------------------------------------------------------------------
# Sensitive-data requests
# ------------------------------------------------------------------------------------------------

EXTRACT_VERBS = frozenset("""
send give share show provide reveal leak export dump list tell email forward hand extract exfiltrate steal obtain get
pull copy print expose disclose release transfer upload paste retrieve fetch access download read display output
see view need want require wish
""".split())
SOFT_VERBS = frozenset({"need", "want", "require", "wish"})     # "I need the confidential client list": only BLOCK level counts
DB_WORDS = frozenset({"database", "db"})                        # a whole database is only sensitive when an organisation is named
PRONOUNS_AND_PARTICLES = frozenset({"me", "us", "them", "it", "over", "up", "out", "off", "back"})
# "give me TIPS to ...", "show me an EXAMPLE of ..." ask for an explanation, not for the data itself.
BENIGN_HEADS = frozenset("""
tip tips summary summaries template templates example examples checklist guide overview explanation outline draft
sample samples definition type types kind kinds category categories way ways method methods reason reasons benefit
benefits difference differences step steps principle principles rule rules law laws how why
""".split())
QUALIFIER_EXEMPT = frozenset("""
example sample mock fake dummy anonymized anonymised hypothetical template schema format
""".split())

MODIFIERS = frozenset("""
confidential proprietary classified secret private internal unpublished unreleased restricted nonpublic sensitive
""".split())
DATA_NOUNS = frozenset("""
document file record data information detail memo financial salary strategy code spec specification email plan
report roadmap blueprint algorithm formula design statement research contract pricing review list
""".split())
STANDALONE_STRONG = (("trade", "secret"), ("secret", "formula"), ("intellectual", "property"), ("nda", "protected"),
                     ("trade", "secrets"))
WEAK_PEOPLE = frozenset("customer client employee staff patient user member account".split())
WEAK_THINGS = frozenset("record data database list detail information info application file document chart".split())
WEAK_SINGLE = frozenset("salary payroll".split())
WEAK_BIGRAMS = (("performance", "review"), ("financial", "record"), ("financial", "statement"),
                ("credit", "application"), ("home", "address"), ("phone", "number"), ("personal", "data"),
                ("personal", "information"), ("personal", "detail"), ("email", "address"))
# Ordinary in technical text ("list source code for the current file"): only meaningful when an organisation is named.
ORG_ONLY_BIGRAMS = (("source", "code"),)
ORG = frozenset("""
company organization organisation firm our your employer enterprise corporate business hospital bank crm hr
""".split())
BULK = frozenset("all every entire full complete everything whole dump each any".split())
DEFINITE = frozenset("the our your their its this that those these all every any".split())
PERSONAL = frozenset({"my", "own", "mine"})


_STANDALONE = frozenset((_sing(a), _sing(b)) for a, b in STANDALONE_STRONG)
_WEAK_BIGRAMS = frozenset((_sing(a), _sing(b)) for a, b in WEAK_BIGRAMS)
_ORG_ONLY_BIGRAMS = frozenset((_sing(a), _sing(b)) for a, b in ORG_ONLY_BIGRAMS)
_DATA_NOUNS = frozenset(_sing(n) for n in DATA_NOUNS)
_WEAK_PEOPLE = frozenset(_sing(n) for n in WEAK_PEOPLE)
_WEAK_THINGS = frozenset(_sing(n) for n in WEAK_THINGS)


def _bigram_at(sing: Sequence[str], i: int, pairs: frozenset) -> bool:
    return i + 1 < len(sing) and (sing[i], sing[i + 1]) in pairs


def _sensitive_sentence(tokens: Sequence[str]) -> Optional[RiskFinding]:
    start = _command_start(tokens, EXTRACT_VERBS)
    if start is None:
        return _sensitive_question(tokens)
    verb = tokens[start]
    j = start + 1
    while j < len(tokens) and tokens[j] in PRONOUNS_AND_PARTICLES:
        j += 1
    finding = _analyse_window(list(tokens[j:j + 16]), verb)
    if finding is not None and verb in SOFT_VERBS and finding.level == FLAG_LEVEL:
        return None                                       # "I need help with confidential data": too weak to even flag
    return finding


def _sensitive_question(tokens: Sequence[str]) -> Optional[RiskFinding]:
    """'What are the company's trade secrets?': a question that ASKS the assistant for an organisation's confidential data.

    Deliberately narrow: wh-word + be + (the|our|your|their) + an organisation word + a sensitive-data noun phrase.
    'What is a trade secret?' (no organisation) and 'What are the legal penalties for leaking trade secrets?' do not match.
    """
    if len(tokens) < 5 or tokens[0] not in {"what", "which", "who"} or tokens[1] not in {"is", "are", "was", "were"}:
        return None
    window = list(tokens[2:18])
    if window[0] not in {"the", "our", "your", "their"}:
        return None
    if not (window[0] in {"our", "your"} or (len(window) > 1 and window[1] in ORG)):
        return None
    finding = _analyse_window(window, "ask")
    return finding if finding is not None and finding.level == BLOCK_LEVEL else None


def _analyse_window(window: List[str], verb: str) -> Optional[RiskFinding]:
    """Does the text after an extraction verb name sensitive data, and is it scoped to an organisation or in bulk?"""
    if not window or any(_sing(t) in BENIGN_HEADS or t in BENIGN_HEADS for t in window[:4]):
        return None
    if _any(window, QUALIFIER_EXEMPT):
        return None
    sing = [_sing(t) for t in window]

    strong_at: List[int] = []
    weak_at: List[int] = []
    org_only_at: List[int] = []
    mod_only_at: List[int] = []
    org_bulk_at: List[int] = []
    for i, t in enumerate(sing):
        if t in DB_WORDS:
            org_bulk_at.append(i)
        if _bigram_at(sing, i, _STANDALONE):
            strong_at.append(i)
        if t in MODIFIERS:
            if any(sing[k] in _DATA_NOUNS for k in range(i + 1, min(len(sing), i + 4))):
                strong_at.append(i)
            else:
                mod_only_at.append(i)
        if t in _WEAK_PEOPLE and any(sing[k] in _WEAK_THINGS for k in range(i + 1, min(len(sing), i + 4))):
            weak_at.append(i)
        elif t in WEAK_SINGLE or _bigram_at(sing, i, _WEAK_BIGRAMS):
            weak_at.append(i)
        if _bigram_at(sing, i, _ORG_ONLY_BIGRAMS):
            org_only_at.append(i)

    hits = strong_at + weak_at + org_only_at + mod_only_at + org_bulk_at
    if not hits:
        return None
    first = min(hits)
    if any(w in PERSONAL for w in window[max(0, first - 3):first]):
        return None                                           # "my own contacts", "my own browsing history"

    org = _any(window, ORG)
    bulk = _any(window, BULK)
    definite = first > 0 and window[first - 1] in DEFINITE
    kind = "strong" if strong_at else ("weak" if weak_at else "modifier")
    ev = f"verb={verb} data={kind} org={sorted(set(org))[:2]} bulk={sorted(set(bulk))[:2]}"
    if strong_at and (definite or org or bulk):
        return RiskFinding(SENSITIVE, BLOCK_LEVEL, "BLOCK", "sensitive_data_extraction_strong", ev)
    if weak_at and (org or bulk):
        return RiskFinding(SENSITIVE, BLOCK_LEVEL, "BLOCK", "sensitive_data_extraction_bulk_or_org", ev)
    if org_only_at and org:
        return RiskFinding(SENSITIVE, BLOCK_LEVEL, "BLOCK", "sensitive_data_extraction_org_source_code", ev)
    if org_bulk_at and org and bulk:
        return RiskFinding(SENSITIVE, BLOCK_LEVEL, "BLOCK", "sensitive_data_extraction_database_dump", ev)
    if mod_only_at and (org or bulk):
        return RiskFinding(SENSITIVE, BLOCK_LEVEL, "BLOCK", "sensitive_data_extraction_modifier", ev)
    if strong_at or weak_at:
        return RiskFinding(SENSITIVE, FLAG_LEVEL, "FLAG", "sensitive_data_extraction_unscoped", ev)
    return None


# ------------------------------------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------------------------------------


def _apply_policy(finding: Optional[RiskFinding], mode: str) -> Optional[RiskFinding]:
    """Turn a rule-level finding into an action under the server policy (off | flag | block)."""
    if finding is None or mode == "off":
        return None
    action = "BLOCK" if (mode == "block" and finding.level == BLOCK_LEVEL) else "FLAG"
    return RiskFinding(finding.category, finding.level, action, finding.rule, finding.evidence)


def scan_text(text: str) -> List[RiskFinding]:
    """All rule-level findings in one normalised text (policy not yet applied)."""
    findings: List[RiskFinding] = []
    syntax = _destructive_syntax(text)
    if syntax is not None:
        findings.append(syntax)
    for sentence in _SENTENCE.split(text):
        tokens = _tokens(sentence)
        if not tokens:
            continue
        for fn in (_destructive_sentence, _sensitive_sentence):
            f = fn(tokens)
            if f is not None:
                findings.append(f)
    return findings


def assess(norm: NormalizedText, policy: Policy) -> Optional[RiskFinding]:
    """The most severe finding for this prompt under the server policy, or None. Never raises on text."""
    if policy.sensitive_data_policy == "off" and policy.destructive_action_policy == "off":
        return None
    texts = [norm.text] + [seg.text for seg in norm.decoded[:4]]
    best: Optional[RiskFinding] = None
    for text in texts:
        for raw in scan_text(text):
            mode = policy.sensitive_data_policy if raw.category == SENSITIVE else policy.destructive_action_policy
            f = _apply_policy(raw, mode)
            if f is None:
                continue
            if best is None or (best.action == "FLAG" and f.action == "BLOCK"):
                best = f
    return best
