# Historical baselines (do not edit)

These are the original, unmodified artifacts from before the 2026-10-27 audit.
They are kept for comparison only. Never tune against them and never overwrite them.

| File | What it is |
|------|------------|
| `final_eval_dataset_FROZEN_seed731904.json` | Frozen 100-prompt holdout (seed 731904). Required SHA-256: `449b222ea697658d863d1862583cb8636a0f7e09b214db965640867697160fe1` |
| `final_eval_results_ORIGINAL_2026-10-22.json` | Historical holdout result: 52% accuracy / 75% precision / 6% recall / 2% FPR. Produced by an older runner that bypassed Stage 2 for CLEAN prompts (96 of 100 prompts were `CLEAN_PASS`). |
| `unseen_test_results_ORIGINAL_2026-10-22.json` | Historical 24-case result: 95.83% accuracy. Produced by a *different, older* `guardrails.py`; it cannot be reproduced with the pre-audit code (that code scores 41.67% on the same cases). |
| `MANIFEST.sha256` | Checksums. `tests/test_evaluator.py` verifies them. |

The 24-case set was iterated against during development, so it is a **development** set, not an unseen one.
