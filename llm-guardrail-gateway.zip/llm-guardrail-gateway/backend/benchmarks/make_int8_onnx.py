"""
Create an int8 (dynamically quantised) copy of the ONNX model, locally. No download, no new weights from anywhere: the
output is a deterministic function of onnx/model.onnx, so it is NOT trusted any differently from the source model.

    python benchmarks/make_int8_onnx.py            # writes models/.../onnx/model.int8.onnx
    GATEWAY_STAGE2_BACKEND=deberta_onnx GATEWAY_STAGE2_ONNX_FILE=onnx/model.int8.onnx python benchmarks/compare_stage2.py ...

Quantisation changes the numbers the model computes, so its accuracy MUST be re-measured (compare_stage2.py does that); a smaller
and faster model that misses attacks is not an improvement.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import stage2_backends  # noqa: E402


def main() -> int:
    from onnxruntime.quantization import QuantType, quantize_dynamic

    src = stage2_backends.DEFAULT_MODEL_DIR / "onnx" / "model.onnx"
    dst = src.with_name("model.int8.onnx")
    if not src.is_file():
        print(f"missing {src}; run: python manage.py setup-model --onnx")
        return 1
    t0 = time.perf_counter()
    quantize_dynamic(str(src), str(dst), weight_type=QuantType.QInt8)
    print(f"wrote {dst} ({dst.stat().st_size / 1e6:.0f} MB, was {src.stat().st_size / 1e6:.0f} MB) in {time.perf_counter() - t0:.0f} s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
