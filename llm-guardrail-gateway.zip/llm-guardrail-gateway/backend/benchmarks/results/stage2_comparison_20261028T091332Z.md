# Stage 2 backend comparison

Generated 2026-10-28T09:13:32+00:00. Every backend ran in its own fresh process.


## Resources

| backend | load (s) | first inference (ms) | RSS before -> after load (MB) | model cost (MB) | peak RSS (MB) | Stage 2 p50 / p95 (ms) | long 4000-char p50 (ms) |
|---|---|---|---|---|---|---|---|
| simulator+deberta_onnx | 91.26 | 51.3 | 32.0 -> 1587.5 | 1555.6 | 1739.9 | 54.68 / 96.06 | 2248.61 |

## Classifier only (Stage 1 + Stage 2; risk-policy layer OFF)

| dataset | backend | cases | recall | FPR | precision | accuracy | TP | FP | TN | FN | err | decision p50 / p95 (ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| holdout | simulator+deberta_onnx | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | 38.123 / 62.976 |
| regression | simulator+deberta_onnx | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | 26.146 / 33.397 |
| dev | simulator+deberta_onnx | 179 | 99.0% | 7.0% | 95.2% | 96.5% | 99 | 5 | 66 | 1 | 0 | 33.587 / 86.3 |
| legacy_unseen | simulator+deberta_onnx | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 14 | 0 | 10 | 0 | 0 | 48.504 / 62.5 |
| policy | simulator+deberta_onnx | 105 | 16.7% | 0.0% | 100.0% | 60.4% | 8 | 0 | 53 | 40 | 0 | 36.927 / 59.203 |
| policy_unseen | simulator+deberta_onnx | 36 | 12.5% | 0.0% | 100.0% | 61.1% | 2 | 0 | 20 | 14 | 0 | 26.688 / 41.962 |

## Full system (risk-policy layer ON)

| dataset | backend | cases | recall | FPR | precision | accuracy | TP | FP | TN | FN | err | decision p50 / p95 (ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| holdout | simulator+deberta_onnx | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | (cached pass) |
| regression | simulator+deberta_onnx | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | (cached pass) |
| dev | simulator+deberta_onnx | 179 | 99.0% | 7.0% | 95.2% | 96.5% | 99 | 5 | 66 | 1 | 0 | (cached pass) |
| legacy_unseen | simulator+deberta_onnx | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 14 | 0 | 10 | 0 | 0 | (cached pass) |
| policy | simulator+deberta_onnx | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy_unseen | simulator+deberta_onnx | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |

## Per-category results (classifier only)

* holdout: binary labels only, no per-category breakdown exists.

### regression

| category | role | total | simulator+deberta_onnx |
|---|---|---|---|
| LEXICAL_LOOKALIKE | benign | 8 | 0 FP |
| NUMBERS_AND_IDS | benign | 2 | 1 FP |
| PII_LEAK | attack | 1 | 0 missed |
| SYNTHETIC_PII | benign | 2 | 0 FP |
| ENCODED_PAYLOAD | attack | 7 | 0 missed |
| INSTRUCTION_OVERRIDE | attack | 1 | 0 missed |
| PROMPT_EXTRACTION | attack | 1 | 0 missed |
| SECURITY_EDUCATION | benign | 2 | 2 FP |

### dev

| category | role | total | simulator+deberta_onnx |
|---|---|---|---|
| DIRECT_JAILBREAK | attack | 12 | 0 missed |
| INSTRUCTION_OVERRIDE | attack | 12 | 0 missed |
| PROMPT_EXTRACTION | attack | 10 | 0 missed |
| DATA_EXFILTRATION | attack | 10 | 0 missed |
| INDIRECT_INJECTION | attack | 12 | 0 missed |
| POLICY_EVASION | attack | 10 | 0 missed |
| ENCODED_PAYLOAD | attack | 12 | 0 missed |
| PII_LEAK | attack | 10 | 0 missed |
| SECRET_LEAK | attack | 4 | 0 missed |
| HARD_SEMANTIC | attack | 8 | 1 missed |
| GENERAL | benign | 20 | 0 FP |
| SECURITY_EDUCATION | benign | 22 | 2 FP |
| LEXICAL_LOOKALIKE | benign | 18 | 1 FP |
| NUMBERS_AND_IDS | benign | 6 | 1 FP |
| SYNTHETIC_PII | benign | 5 | 1 FP |

### legacy_unseen

| category | role | total | simulator+deberta_onnx |
|---|---|---|---|
| INJECTION_NOVEL | attack | 6 | 0 missed |
| EXFILTRATION | attack | 4 | 0 missed |
| POLICY_EVASION | attack | 4 | 0 missed |
| BENIGN_SECURITY_LOOKALIKE | benign | 10 | 0 FP |

### policy

| category | role | total | simulator+deberta_onnx |
|---|---|---|---|
| SENSITIVE_DATA_REQUEST | attack | 24 | 20 missed |
| DESTRUCTIVE_ACTION | attack | 24 | 20 missed |
| SENSITIVE_BENIGN | benign | 25 | 0 FP |
| DESTRUCTIVE_BENIGN | benign | 28 | 0 FP |

### policy_unseen

| category | role | total | simulator+deberta_onnx |
|---|---|---|---|
| SENSITIVE_DATA_REQUEST | attack | 8 | 6 missed |
| DESTRUCTIVE_ACTION | attack | 8 | 8 missed |
| SENSITIVE_BENIGN | benign | 10 | 0 FP |
| DESTRUCTIVE_BENIGN | benign | 10 | 0 FP |

## Notes

* The holdout is frozen and was written for the simulator-era project. Comparing backends on it is a SELECTION on that set: it is no longer a clean estimate for whichever backend is chosen. A fresh independent holdout is needed for a final claim.
* Latencies are wall-clock on the machine listed under environment, single process, sequential requests, no GPU.
* `peak RSS` is the process peak working set (Windows only; null elsewhere).
