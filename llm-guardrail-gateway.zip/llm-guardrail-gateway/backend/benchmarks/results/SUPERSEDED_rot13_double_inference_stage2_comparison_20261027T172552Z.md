# Stage 2 backend comparison

Generated 2026-10-27T17:25:52+00:00. Every backend ran in its own fresh process.

* **simulator+deberta: FAILED** backend not ready: None

## Resources

| backend | load (s) | first inference (ms) | RSS before -> after load (MB) | model cost (MB) | peak RSS (MB) | Stage 2 p50 / p95 (ms) | long 4000-char p50 (ms) |
|---|---|---|---|---|---|---|---|
| simulator | 0.0 | 2.1 | 31.6 -> 31.6 | 0.0 | 222.2 | 0.38 / 0.63 | 13.02 |
| deberta | 29.64 | 652.1 | 32.0 -> 431.2 | 399.2 | 2317.1 | 390.83 / 607.33 | 10317.73 |

## Classifier only (Stage 1 + Stage 2; risk-policy layer OFF)

| dataset | backend | cases | recall | FPR | precision | accuracy | TP | FP | TN | FN | err | decision p50 / p95 (ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| holdout | simulator | 100 | 12.0% | 0.0% | 100.0% | 56.0% | 6 | 0 | 50 | 44 | 0 | 0.669 / 0.832 |
| holdout | deberta | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | 378.656 / 440.321 |
| regression | simulator | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 10 | 0 | 14 | 0 | 0 | 0.736 / 1.603 |
| regression | deberta | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | 294.932 / 553.619 |
| dev | simulator | 179 | 90.0% | 0.0% | 100.0% | 94.2% | 90 | 0 | 71 | 10 | 0 | 0.716 / 1.202 |
| dev | deberta | 179 | 90.0% | 11.3% | 91.8% | 89.5% | 90 | 8 | 63 | 10 | 0 | 382.171 / 568.18 |
| legacy_unseen | simulator | 24 | 85.7% | 0.0% | 100.0% | 91.7% | 12 | 0 | 10 | 2 | 0 | 0.735 / 1.128 |
| legacy_unseen | deberta | 24 | 92.9% | 0.0% | 100.0% | 95.8% | 13 | 0 | 10 | 1 | 0 | 391.629 / 542.488 |
| policy | simulator | 105 | 0.0% | 0.0% | n/a | 52.5% | 0 | 0 | 53 | 48 | 0 | 0.519 / 0.79 |
| policy | deberta | 105 | 18.8% | 0.0% | 100.0% | 61.4% | 9 | 0 | 53 | 39 | 0 | 335.767 / 413.877 |
| policy_unseen | simulator | 36 | 6.2% | 0.0% | 100.0% | 58.3% | 1 | 0 | 20 | 15 | 0 | 0.52 / 0.634 |
| policy_unseen | deberta | 36 | 12.5% | 0.0% | 100.0% | 61.1% | 2 | 0 | 20 | 14 | 0 | 308.183 / 389.83 |

## Full system (risk-policy layer ON)

| dataset | backend | cases | recall | FPR | precision | accuracy | TP | FP | TN | FN | err | decision p50 / p95 (ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| holdout | simulator | 100 | 12.0% | 0.0% | 100.0% | 56.0% | 6 | 0 | 50 | 44 | 0 | (cached pass) |
| holdout | deberta | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | (cached pass) |
| regression | simulator | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 10 | 0 | 14 | 0 | 0 | (cached pass) |
| regression | deberta | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | (cached pass) |
| dev | simulator | 179 | 90.0% | 0.0% | 100.0% | 94.2% | 90 | 0 | 71 | 10 | 0 | (cached pass) |
| dev | deberta | 179 | 91.0% | 11.3% | 91.9% | 90.1% | 91 | 8 | 63 | 9 | 0 | (cached pass) |
| legacy_unseen | simulator | 24 | 85.7% | 0.0% | 100.0% | 91.7% | 12 | 0 | 10 | 2 | 0 | (cached pass) |
| legacy_unseen | deberta | 24 | 92.9% | 0.0% | 100.0% | 95.8% | 13 | 0 | 10 | 1 | 0 | (cached pass) |
| policy | simulator | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy | deberta | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy_unseen | simulator | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |
| policy_unseen | deberta | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |

## Per-category results (classifier only)

* holdout: binary labels only, no per-category breakdown exists.

### regression

| category | role | total | simulator | deberta |
|---|---|---|---|---|
| LEXICAL_LOOKALIKE | benign | 8 | 0 FP | 0 FP |
| NUMBERS_AND_IDS | benign | 2 | 0 FP | 1 FP |
| PII_LEAK | attack | 1 | 0 missed | 0 missed |
| SYNTHETIC_PII | benign | 2 | 0 FP | 0 FP |
| ENCODED_PAYLOAD | attack | 7 | 0 missed | 0 missed |
| INSTRUCTION_OVERRIDE | attack | 1 | 0 missed | 0 missed |
| PROMPT_EXTRACTION | attack | 1 | 0 missed | 0 missed |
| SECURITY_EDUCATION | benign | 2 | 0 FP | 2 FP |

### dev

| category | role | total | simulator | deberta |
|---|---|---|---|---|
| DIRECT_JAILBREAK | attack | 12 | 0 missed | 0 missed |
| INSTRUCTION_OVERRIDE | attack | 12 | 0 missed | 1 missed |
| PROMPT_EXTRACTION | attack | 10 | 0 missed | 1 missed |
| DATA_EXFILTRATION | attack | 10 | 0 missed | 4 missed |
| INDIRECT_INJECTION | attack | 12 | 0 missed | 0 missed |
| POLICY_EVASION | attack | 10 | 3 missed | 1 missed |
| ENCODED_PAYLOAD | attack | 12 | 0 missed | 1 missed |
| PII_LEAK | attack | 10 | 0 missed | 0 missed |
| SECRET_LEAK | attack | 4 | 0 missed | 0 missed |
| HARD_SEMANTIC | attack | 8 | 7 missed | 2 missed |
| GENERAL | benign | 20 | 0 FP | 1 FP |
| SECURITY_EDUCATION | benign | 22 | 0 FP | 3 FP |
| LEXICAL_LOOKALIKE | benign | 18 | 0 FP | 1 FP |
| NUMBERS_AND_IDS | benign | 6 | 0 FP | 1 FP |
| SYNTHETIC_PII | benign | 5 | 0 FP | 2 FP |

### legacy_unseen

| category | role | total | simulator | deberta |
|---|---|---|---|---|
| INJECTION_NOVEL | attack | 6 | 1 missed | 0 missed |
| EXFILTRATION | attack | 4 | 1 missed | 1 missed |
| POLICY_EVASION | attack | 4 | 0 missed | 0 missed |
| BENIGN_SECURITY_LOOKALIKE | benign | 10 | 0 FP | 0 FP |

### policy

| category | role | total | simulator | deberta |
|---|---|---|---|---|
| SENSITIVE_DATA_REQUEST | attack | 24 | 24 missed | 20 missed |
| DESTRUCTIVE_ACTION | attack | 24 | 24 missed | 19 missed |
| SENSITIVE_BENIGN | benign | 25 | 0 FP | 0 FP |
| DESTRUCTIVE_BENIGN | benign | 28 | 0 FP | 0 FP |

### policy_unseen

| category | role | total | simulator | deberta |
|---|---|---|---|---|
| SENSITIVE_DATA_REQUEST | attack | 8 | 7 missed | 7 missed |
| DESTRUCTIVE_ACTION | attack | 8 | 8 missed | 7 missed |
| SENSITIVE_BENIGN | benign | 10 | 0 FP | 0 FP |
| DESTRUCTIVE_BENIGN | benign | 10 | 0 FP | 0 FP |

## Threshold sensitivity (classifier only; recall / FPR)

| dataset | backend | t=50 | t=65 | t=80 | t=90 |
|---|---|---|---|---|---|
| holdout | simulator | 12.0% / 0.0% | 12.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| holdout | deberta | 92.0% / 8.0% | 92.0% / 8.0% | 90.0% / 6.0% | 88.0% / 6.0% |
| regression | simulator | 100.0% / 0.0% | 100.0% / 0.0% | 80.0% / 0.0% | 80.0% / 0.0% |
| regression | deberta | 100.0% / 28.6% | 100.0% / 21.4% | 100.0% / 14.3% | 100.0% / 14.3% |
| dev | simulator | 92.0% / 0.0% | 90.0% / 0.0% | 53.0% / 0.0% | 43.0% / 0.0% |
| dev | deberta | 90.0% / 11.3% | 90.0% / 11.3% | 89.0% / 11.3% | 88.0% / 5.6% |
| legacy_unseen | simulator | 85.7% / 0.0% | 85.7% / 0.0% | 14.3% / 0.0% | 7.1% / 0.0% |
| legacy_unseen | deberta | 92.9% / 0.0% | 92.9% / 0.0% | 92.9% / 0.0% | 92.9% / 0.0% |
| policy | simulator | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| policy | deberta | 18.8% / 0.0% | 18.8% / 0.0% | 18.8% / 0.0% | 18.8% / 0.0% |
| policy_unseen | simulator | 6.2% / 0.0% | 6.2% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| policy_unseen | deberta | 12.5% / 0.0% | 12.5% / 0.0% | 12.5% / 0.0% | 12.5% / 0.0% |

## Notes

* The holdout is frozen and was written for the simulator-era project. Comparing backends on it is a SELECTION on that set: it is no longer a clean estimate for whichever backend is chosen. A fresh independent holdout is needed for a final claim.
* Latencies are wall-clock on the machine listed under environment, single process, sequential requests, no GPU.
* `peak RSS` is the process peak working set (Windows only; null elsewhere).
