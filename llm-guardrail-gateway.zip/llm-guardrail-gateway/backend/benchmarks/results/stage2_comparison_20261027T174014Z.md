# Stage 2 backend comparison

Generated 2026-10-27T17:40:14+00:00. Every backend ran in its own fresh process.


## Resources

| backend | load (s) | first inference (ms) | RSS before -> after load (MB) | model cost (MB) | peak RSS (MB) | Stage 2 p50 / p95 (ms) | long 4000-char p50 (ms) |
|---|---|---|---|---|---|---|---|
| simulator | 0.0 | 2.6 | 32.0 -> 32.0 | 0.0 | 222.7 | 0.91 / 1.65 | 36.77 |
| deberta | 29.73 | 502.8 | 31.8 -> 431.4 | 399.6 | 1015.6 | 243.65 / 384.09 | 3196.77 |
| deberta_onnx | 16.99 | 51.8 | 31.9 -> 1595.2 | 1563.3 | 1629.4 | 37.71 / 94.17 | 2595.31 |
| deberta_onnx:int8 | 15.53 | 41.5 | 31.7 -> 766.2 | 734.4 | 933.0 | 28.96 / 71.96 | 2300.01 |
| simulator+deberta_onnx:int8 | 14.93 | 29.0 | 32.0 -> 768.3 | 736.3 | 933.2 | 29.6 / 83.37 | 2185.0 |

## Classifier only (Stage 1 + Stage 2; risk-policy layer OFF)

| dataset | backend | cases | recall | FPR | precision | accuracy | TP | FP | TN | FN | err | decision p50 / p95 (ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| holdout | simulator | 100 | 12.0% | 0.0% | 100.0% | 56.0% | 6 | 0 | 50 | 44 | 0 | 1.789 / 2.148 |
| holdout | deberta | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | 234.116 / 271.801 |
| holdout | deberta_onnx | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | 35.033 / 65.003 |
| holdout | deberta_onnx:int8 | 100 | 0.0% | 0.0% | n/a | 50.0% | 0 | 0 | 50 | 50 | 0 | 21.709 / 41.772 |
| holdout | simulator+deberta_onnx:int8 | 100 | 12.0% | 0.0% | 100.0% | 56.0% | 6 | 0 | 50 | 44 | 0 | 23.479 / 45.444 |
| regression | simulator | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 10 | 0 | 14 | 0 | 0 | 1.009 / 1.927 |
| regression | deberta | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | 227.894 / 259.37 |
| regression | deberta_onnx | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | 27.78 / 37.513 |
| regression | deberta_onnx:int8 | 24 | 70.0% | 0.0% | 100.0% | 87.5% | 7 | 0 | 14 | 3 | 0 | 24.564 / 41.242 |
| regression | simulator+deberta_onnx:int8 | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 10 | 0 | 14 | 0 | 0 | 31.163 / 52.786 |
| dev | simulator | 179 | 90.0% | 0.0% | 100.0% | 94.2% | 90 | 0 | 71 | 10 | 0 | 1.719 / 2.986 |
| dev | deberta | 179 | 90.0% | 7.0% | 94.7% | 91.2% | 90 | 5 | 66 | 10 | 0 | 242.81 / 280.481 |
| dev | deberta_onnx | 179 | 90.0% | 7.0% | 94.7% | 91.2% | 90 | 5 | 66 | 10 | 0 | 41.999 / 77.703 |
| dev | deberta_onnx:int8 | 179 | 25.0% | 0.0% | 100.0% | 56.1% | 25 | 0 | 71 | 75 | 0 | 25.577 / 69.464 |
| dev | simulator+deberta_onnx:int8 | 179 | 90.0% | 0.0% | 100.0% | 94.2% | 90 | 0 | 71 | 10 | 0 | 25.064 / 60.416 |
| legacy_unseen | simulator | 24 | 85.7% | 0.0% | 100.0% | 91.7% | 12 | 0 | 10 | 2 | 0 | 1.88 / 3.056 |
| legacy_unseen | deberta | 24 | 92.9% | 0.0% | 100.0% | 95.8% | 13 | 0 | 10 | 1 | 0 | 239.01 / 300.769 |
| legacy_unseen | deberta_onnx | 24 | 92.9% | 0.0% | 100.0% | 95.8% | 13 | 0 | 10 | 1 | 0 | 31.788 / 45.547 |
| legacy_unseen | deberta_onnx:int8 | 24 | 0.0% | 0.0% | n/a | 41.7% | 0 | 0 | 10 | 14 | 0 | 22.972 / 28.361 |
| legacy_unseen | simulator+deberta_onnx:int8 | 24 | 85.7% | 0.0% | 100.0% | 91.7% | 12 | 0 | 10 | 2 | 0 | 24.567 / 56.696 |
| policy | simulator | 105 | 0.0% | 0.0% | n/a | 52.5% | 0 | 0 | 53 | 48 | 0 | 1.266 / 1.891 |
| policy | deberta | 105 | 16.7% | 0.0% | 100.0% | 60.4% | 8 | 0 | 53 | 40 | 0 | 200.741 / 275.265 |
| policy | deberta_onnx | 105 | 16.7% | 0.0% | 100.0% | 60.4% | 8 | 0 | 53 | 40 | 0 | 33.996 / 63.957 |
| policy | deberta_onnx:int8 | 105 | 0.0% | 0.0% | n/a | 52.5% | 0 | 0 | 53 | 48 | 0 | 25.218 / 43.406 |
| policy | simulator+deberta_onnx:int8 | 105 | 0.0% | 0.0% | n/a | 52.5% | 0 | 0 | 53 | 48 | 0 | 21.856 / 50.255 |
| policy_unseen | simulator | 36 | 6.2% | 0.0% | 100.0% | 58.3% | 1 | 0 | 20 | 15 | 0 | 0.914 / 1.391 |
| policy_unseen | deberta | 36 | 6.2% | 0.0% | 100.0% | 58.3% | 1 | 0 | 20 | 15 | 0 | 157.454 / 321.825 |
| policy_unseen | deberta_onnx | 36 | 6.2% | 0.0% | 100.0% | 58.3% | 1 | 0 | 20 | 15 | 0 | 31.657 / 50.03 |
| policy_unseen | deberta_onnx:int8 | 36 | 0.0% | 0.0% | n/a | 55.6% | 0 | 0 | 20 | 16 | 0 | 17.903 / 21.063 |
| policy_unseen | simulator+deberta_onnx:int8 | 36 | 6.2% | 0.0% | 100.0% | 58.3% | 1 | 0 | 20 | 15 | 0 | 21.325 / 25.525 |

## Full system (risk-policy layer ON)

| dataset | backend | cases | recall | FPR | precision | accuracy | TP | FP | TN | FN | err | decision p50 / p95 (ms) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| holdout | simulator | 100 | 12.0% | 0.0% | 100.0% | 56.0% | 6 | 0 | 50 | 44 | 0 | (cached pass) |
| holdout | deberta | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | (cached pass) |
| holdout | deberta_onnx | 100 | 92.0% | 8.0% | 92.0% | 92.0% | 46 | 4 | 46 | 4 | 0 | (cached pass) |
| holdout | deberta_onnx:int8 | 100 | 0.0% | 0.0% | n/a | 50.0% | 0 | 0 | 50 | 50 | 0 | (cached pass) |
| holdout | simulator+deberta_onnx:int8 | 100 | 12.0% | 0.0% | 100.0% | 56.0% | 6 | 0 | 50 | 44 | 0 | (cached pass) |
| regression | simulator | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 10 | 0 | 14 | 0 | 0 | (cached pass) |
| regression | deberta | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | (cached pass) |
| regression | deberta_onnx | 24 | 100.0% | 21.4% | 76.9% | 87.5% | 10 | 3 | 11 | 0 | 0 | (cached pass) |
| regression | deberta_onnx:int8 | 24 | 70.0% | 0.0% | 100.0% | 87.5% | 7 | 0 | 14 | 3 | 0 | (cached pass) |
| regression | simulator+deberta_onnx:int8 | 24 | 100.0% | 0.0% | 100.0% | 100.0% | 10 | 0 | 14 | 0 | 0 | (cached pass) |
| dev | simulator | 179 | 90.0% | 0.0% | 100.0% | 94.2% | 90 | 0 | 71 | 10 | 0 | (cached pass) |
| dev | deberta | 179 | 91.0% | 7.0% | 94.8% | 91.8% | 91 | 5 | 66 | 9 | 0 | (cached pass) |
| dev | deberta_onnx | 179 | 91.0% | 7.0% | 94.8% | 91.8% | 91 | 5 | 66 | 9 | 0 | (cached pass) |
| dev | deberta_onnx:int8 | 179 | 26.0% | 0.0% | 100.0% | 56.7% | 26 | 0 | 71 | 74 | 0 | (cached pass) |
| dev | simulator+deberta_onnx:int8 | 179 | 90.0% | 0.0% | 100.0% | 94.2% | 90 | 0 | 71 | 10 | 0 | (cached pass) |
| legacy_unseen | simulator | 24 | 85.7% | 0.0% | 100.0% | 91.7% | 12 | 0 | 10 | 2 | 0 | (cached pass) |
| legacy_unseen | deberta | 24 | 92.9% | 0.0% | 100.0% | 95.8% | 13 | 0 | 10 | 1 | 0 | (cached pass) |
| legacy_unseen | deberta_onnx | 24 | 92.9% | 0.0% | 100.0% | 95.8% | 13 | 0 | 10 | 1 | 0 | (cached pass) |
| legacy_unseen | deberta_onnx:int8 | 24 | 7.1% | 0.0% | 100.0% | 45.8% | 1 | 0 | 10 | 13 | 0 | (cached pass) |
| legacy_unseen | simulator+deberta_onnx:int8 | 24 | 85.7% | 0.0% | 100.0% | 91.7% | 12 | 0 | 10 | 2 | 0 | (cached pass) |
| policy | simulator | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy | deberta | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy | deberta_onnx | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy | deberta_onnx:int8 | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy | simulator+deberta_onnx:int8 | 105 | 100.0% | 0.0% | 100.0% | 100.0% | 48 | 0 | 53 | 0 | 0 | (cached pass) |
| policy_unseen | simulator | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |
| policy_unseen | deberta | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |
| policy_unseen | deberta_onnx | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |
| policy_unseen | deberta_onnx:int8 | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |
| policy_unseen | simulator+deberta_onnx:int8 | 36 | 100.0% | 0.0% | 100.0% | 100.0% | 16 | 0 | 20 | 0 | 0 | (cached pass) |

## Per-category results (classifier only)

* holdout: binary labels only, no per-category breakdown exists.

### regression

| category | role | total | simulator | deberta | deberta_onnx | deberta_onnx:int8 | simulator+deberta_onnx:int8 |
|---|---|---|---|---|---|---|---|
| LEXICAL_LOOKALIKE | benign | 8 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |
| NUMBERS_AND_IDS | benign | 2 | 0 FP | 1 FP | 1 FP | 0 FP | 0 FP |
| PII_LEAK | attack | 1 | 0 missed | 0 missed | 0 missed | 0 missed | 0 missed |
| SYNTHETIC_PII | benign | 2 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |
| ENCODED_PAYLOAD | attack | 7 | 0 missed | 0 missed | 0 missed | 1 missed | 0 missed |
| INSTRUCTION_OVERRIDE | attack | 1 | 0 missed | 0 missed | 0 missed | 1 missed | 0 missed |
| PROMPT_EXTRACTION | attack | 1 | 0 missed | 0 missed | 0 missed | 1 missed | 0 missed |
| SECURITY_EDUCATION | benign | 2 | 0 FP | 2 FP | 2 FP | 0 FP | 0 FP |

### dev

| category | role | total | simulator | deberta | deberta_onnx | deberta_onnx:int8 | simulator+deberta_onnx:int8 |
|---|---|---|---|---|---|---|---|
| DIRECT_JAILBREAK | attack | 12 | 0 missed | 0 missed | 0 missed | 10 missed | 0 missed |
| INSTRUCTION_OVERRIDE | attack | 12 | 0 missed | 1 missed | 1 missed | 12 missed | 0 missed |
| PROMPT_EXTRACTION | attack | 10 | 0 missed | 1 missed | 1 missed | 10 missed | 0 missed |
| DATA_EXFILTRATION | attack | 10 | 0 missed | 4 missed | 4 missed | 10 missed | 0 missed |
| INDIRECT_INJECTION | attack | 12 | 0 missed | 0 missed | 0 missed | 12 missed | 0 missed |
| POLICY_EVASION | attack | 10 | 3 missed | 1 missed | 1 missed | 10 missed | 3 missed |
| ENCODED_PAYLOAD | attack | 12 | 0 missed | 1 missed | 1 missed | 3 missed | 0 missed |
| PII_LEAK | attack | 10 | 0 missed | 0 missed | 0 missed | 0 missed | 0 missed |
| SECRET_LEAK | attack | 4 | 0 missed | 0 missed | 0 missed | 0 missed | 0 missed |
| HARD_SEMANTIC | attack | 8 | 7 missed | 2 missed | 2 missed | 8 missed | 7 missed |
| GENERAL | benign | 20 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |
| SECURITY_EDUCATION | benign | 22 | 0 FP | 2 FP | 2 FP | 0 FP | 0 FP |
| LEXICAL_LOOKALIKE | benign | 18 | 0 FP | 1 FP | 1 FP | 0 FP | 0 FP |
| NUMBERS_AND_IDS | benign | 6 | 0 FP | 1 FP | 1 FP | 0 FP | 0 FP |
| SYNTHETIC_PII | benign | 5 | 0 FP | 1 FP | 1 FP | 0 FP | 0 FP |

### legacy_unseen

| category | role | total | simulator | deberta | deberta_onnx | deberta_onnx:int8 | simulator+deberta_onnx:int8 |
|---|---|---|---|---|---|---|---|
| INJECTION_NOVEL | attack | 6 | 1 missed | 0 missed | 0 missed | 6 missed | 1 missed |
| EXFILTRATION | attack | 4 | 1 missed | 1 missed | 1 missed | 4 missed | 1 missed |
| POLICY_EVASION | attack | 4 | 0 missed | 0 missed | 0 missed | 4 missed | 0 missed |
| BENIGN_SECURITY_LOOKALIKE | benign | 10 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |

### policy

| category | role | total | simulator | deberta | deberta_onnx | deberta_onnx:int8 | simulator+deberta_onnx:int8 |
|---|---|---|---|---|---|---|---|
| SENSITIVE_DATA_REQUEST | attack | 24 | 24 missed | 20 missed | 20 missed | 24 missed | 24 missed |
| DESTRUCTIVE_ACTION | attack | 24 | 24 missed | 20 missed | 20 missed | 24 missed | 24 missed |
| SENSITIVE_BENIGN | benign | 25 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |
| DESTRUCTIVE_BENIGN | benign | 28 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |

### policy_unseen

| category | role | total | simulator | deberta | deberta_onnx | deberta_onnx:int8 | simulator+deberta_onnx:int8 |
|---|---|---|---|---|---|---|---|
| SENSITIVE_DATA_REQUEST | attack | 8 | 7 missed | 7 missed | 7 missed | 8 missed | 7 missed |
| DESTRUCTIVE_ACTION | attack | 8 | 8 missed | 8 missed | 8 missed | 8 missed | 8 missed |
| SENSITIVE_BENIGN | benign | 10 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |
| DESTRUCTIVE_BENIGN | benign | 10 | 0 FP | 0 FP | 0 FP | 0 FP | 0 FP |

## Threshold sensitivity (classifier only; recall / FPR)

| dataset | backend | t=50 | t=65 | t=80 | t=90 |
|---|---|---|---|---|---|
| holdout | simulator | 12.0% / 0.0% | 12.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| holdout | deberta | 92.0% / 8.0% | 92.0% / 8.0% | 90.0% / 6.0% | 88.0% / 6.0% |
| holdout | deberta_onnx | 92.0% / 8.0% | 92.0% / 8.0% | 90.0% / 6.0% | 88.0% / 6.0% |
| holdout | deberta_onnx:int8 | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| holdout | simulator+deberta_onnx:int8 | 12.0% / 0.0% | 12.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| regression | simulator | 100.0% / 0.0% | 100.0% / 0.0% | 80.0% / 0.0% | 80.0% / 0.0% |
| regression | deberta | 100.0% / 28.6% | 100.0% / 21.4% | 100.0% / 14.3% | 100.0% / 14.3% |
| regression | deberta_onnx | 100.0% / 28.6% | 100.0% / 21.4% | 100.0% / 14.3% | 100.0% / 14.3% |
| regression | deberta_onnx:int8 | 70.0% / 0.0% | 70.0% / 0.0% | 70.0% / 0.0% | 70.0% / 0.0% |
| regression | simulator+deberta_onnx:int8 | 100.0% / 0.0% | 100.0% / 0.0% | 80.0% / 0.0% | 80.0% / 0.0% |
| dev | simulator | 92.0% / 0.0% | 90.0% / 0.0% | 53.0% / 0.0% | 43.0% / 0.0% |
| dev | deberta | 90.0% / 7.0% | 90.0% / 7.0% | 89.0% / 7.0% | 88.0% / 4.2% |
| dev | deberta_onnx | 90.0% / 7.0% | 90.0% / 7.0% | 89.0% / 7.0% | 88.0% / 4.2% |
| dev | deberta_onnx:int8 | 25.0% / 0.0% | 25.0% / 0.0% | 25.0% / 0.0% | 25.0% / 0.0% |
| dev | simulator+deberta_onnx:int8 | 92.0% / 0.0% | 90.0% / 0.0% | 53.0% / 0.0% | 43.0% / 0.0% |
| legacy_unseen | simulator | 85.7% / 0.0% | 85.7% / 0.0% | 14.3% / 0.0% | 7.1% / 0.0% |
| legacy_unseen | deberta | 92.9% / 0.0% | 92.9% / 0.0% | 92.9% / 0.0% | 92.9% / 0.0% |
| legacy_unseen | deberta_onnx | 92.9% / 0.0% | 92.9% / 0.0% | 92.9% / 0.0% | 92.9% / 0.0% |
| legacy_unseen | deberta_onnx:int8 | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| legacy_unseen | simulator+deberta_onnx:int8 | 85.7% / 0.0% | 85.7% / 0.0% | 14.3% / 0.0% | 7.1% / 0.0% |
| policy | simulator | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| policy | deberta | 16.7% / 0.0% | 16.7% / 0.0% | 16.7% / 0.0% | 16.7% / 0.0% |
| policy | deberta_onnx | 16.7% / 0.0% | 16.7% / 0.0% | 16.7% / 0.0% | 16.7% / 0.0% |
| policy | deberta_onnx:int8 | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| policy | simulator+deberta_onnx:int8 | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| policy_unseen | simulator | 6.2% / 0.0% | 6.2% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| policy_unseen | deberta | 6.2% / 0.0% | 6.2% / 0.0% | 6.2% / 0.0% | 6.2% / 0.0% |
| policy_unseen | deberta_onnx | 6.2% / 0.0% | 6.2% / 0.0% | 6.2% / 0.0% | 6.2% / 0.0% |
| policy_unseen | deberta_onnx:int8 | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |
| policy_unseen | simulator+deberta_onnx:int8 | 6.2% / 0.0% | 6.2% / 0.0% | 0.0% / 0.0% | 0.0% / 0.0% |

## Notes

* The holdout is frozen and was written for the simulator-era project. Comparing backends on it is a SELECTION on that set: it is no longer a clean estimate for whichever backend is chosen. A fresh independent holdout is needed for a final claim.
* Latencies are wall-clock on the machine listed under environment, single process, sequential requests, no GPU.
* `peak RSS` is the process peak working set (Windows only; null elsewhere).
