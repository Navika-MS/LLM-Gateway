"""
Stage 2 backend benchmark: the simulator vs. the trained model, measured the same way.

    python benchmarks/compare_stage2.py                                  # simulator + deberta (PyTorch)
    python benchmarks/compare_stage2.py --backends simulator deberta deberta_onnx deberta_onnx:int8 simulator+deberta
    (options after a colon: int8 = the quantised ONNX file, threads=N)
    python benchmarks/compare_stage2.py --datasets holdout dev --no-sweep

What is measured, per backend and per dataset
---------------------------------------------
  attack recall, false-positive rate, precision, accuracy, F1 and the raw confusion matrix (errors reported separately);
  per-category misses (attacks) and false positives (benign), where the dataset has categories;
  CPU latency of the whole decision and of Stage 2 alone (p50/p95/max) on a fixed prompt set, plus a long-prompt probe;
  memory (process RSS before loading, after loading, peak) and start-up time (import + load + first inference);
  threshold sensitivity (risk threshold 50/65/80/90) so an operating point is not picked by accident.

Rules of the road
-----------------
  * Every backend runs in its OWN fresh process, so memory and start-up numbers are not contaminated by another backend.
  * Two configurations per backend: "classifier only" (risk-policy layer OFF, isolates Stage 1 + Stage 2) and
    "full system" (risk-policy layer ON, what the API runs).
  * Frozen-holdout prompts are NEVER printed or stored: only aggregate numbers leave this script. Note that using the holdout
    to compare backends is itself a form of selection on it; the report says so.
  * Reports are written to benchmarks/results/ as NEW timestamped files (never overwritten).
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

HERE = Path(__file__).resolve().parent
BACKEND_DIR = HERE.parent
DEFAULT_DATASETS = ["holdout", "regression", "dev", "legacy_unseen", "policy", "policy_unseen"]
THRESHOLDS = [50, 65, 80, 90]
LATENCY_SET = ["dev", "regression"]            # shown (non-frozen) prompts only
WARMUP = 3


def pct(values: List[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    k = (len(ordered) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(ordered) - 1)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (k - lo)


def lat_stats(ms: List[float]) -> Dict[str, float]:
    return {"n": len(ms), "avg_ms": round(statistics.fmean(ms), 2), "p50_ms": round(pct(ms, .5), 2),
            "p95_ms": round(pct(ms, .95), 2), "max_ms": round(max(ms), 2)} if ms else {"n": 0}


class Memo:
    """Caches Stage 2 results per prompt so threshold sweeps and the second configuration do not repeat identical inference.

    Inference is deterministic on CPU, so cached and fresh results are identical. Latency is therefore taken ONLY from the first
    (uncached) pass of each dataset; later passes report accuracy only.
    """

    def __init__(self, inner):
        self.inner = inner
        self.cache: Dict[str, object] = {}
        self.provider = getattr(inner, "provider", "LOCAL_HEURISTIC_SIMULATOR")
        self.simulated = getattr(inner, "simulated", True)
        self.model_id = getattr(inner, "model_id", None)
        self.live = False

    def __call__(self, prompt, norm, stage1, policy):
        hit = self.cache.get(prompt)
        if hit is None:
            hit = self.inner(prompt, norm, stage1, policy)
            self.cache[prompt] = hit
        return hit


# ------------------------------------------------------------------------------------------------
# Worker: one backend, one fresh process
# ------------------------------------------------------------------------------------------------


def rss_mb() -> float:
    import psutil

    return psutil.Process().memory_info().rss / 1e6


def peak_mb() -> Optional[float]:
    import psutil

    info = psutil.Process().memory_info()
    peak = getattr(info, "peak_wset", None)                    # Windows: true peak working set
    return round(peak / 1e6, 1) if peak else None


def summarise(report) -> Dict[str, object]:
    m, cm = report.metrics, report.confusion_matrix
    cats = []
    for c in report.categories:
        if c.role == "attack":
            cats.append({"category": c.category, "role": "attack", "total": c.total, "missed": c.passed, "blocked": c.blocked})
        elif c.role == "benign":
            cats.append({"category": c.category, "role": "benign", "total": c.total, "false_positives": c.blocked})
    return {"cases": report.dataset.case_count, "attacks": report.dataset.attack_count, "benign": report.dataset.benign_count,
            "accuracy": m.accuracy, "precision": m.precision, "recall": m.recall, "fpr": m.false_positive_rate, "f1": m.f1,
            "tp": cm.tp, "fp": cm.fp, "tn": cm.tn, "fn": cm.fn, "errors": report.reliability.error_cases,
            "flagged_pass": report.routes.passed_flagged_uncertain, "risk_policy_blocks": report.routes.risk_policy_blocks,
            "stage1_blocks": report.routes.stage1_blocks, "stage2_blocks": report.routes.stage2_blocks,
            "decision_latency": {"avg_ms": report.latency.avg_ms, "p50_ms": report.latency.p50_ms, "p95_ms": report.latency.p95_ms,
                                 "max_ms": report.latency.max_ms},
            "categories": cats, "dataset_sha256": report.dataset.sha256, "hash_verified": report.dataset.hash_verified}


def worker(backend: str, datasets: List[str], sweep: bool) -> Dict[str, object]:
    os.environ["GATEWAY_SKIP_DOTENV"] = "1"
    base, _, opts = backend.partition(":")                       # e.g. "deberta_onnx:int8,threads=4"
    os.environ["GATEWAY_STAGE2_BACKEND"] = base
    for opt in filter(None, opts.split(",")):
        if opt == "int8":
            os.environ["GATEWAY_STAGE2_ONNX_FILE"] = "onnx/model.int8.onnx"
        elif opt.startswith("threads="):
            os.environ["GATEWAY_STAGE2_THREADS"] = opt.split("=", 1)[1]
        else:
            raise SystemExit(f"unknown backend option {opt!r}")
    sys.path.insert(0, str(BACKEND_DIR))
    t_proc = time.perf_counter()
    import config
    import evaluator
    import pipeline
    import stage2_backends
    import stage2_simulator
    from guardrails import analyze_stage1
    from normalization import normalize

    rss_before = rss_mb()
    settings = config.Settings.from_env()
    t0 = time.perf_counter()
    clf = stage2_backends.build_classifier(settings)
    status = stage2_backends.warm_up(clf)                       # loads weights now
    load_s = time.perf_counter() - t0
    if not status.get("ready", False):
        return {"backend": backend, "error": f"backend not ready: {status.get('error')}"}
    rss_loaded = rss_mb()

    base_policy = pipeline.server_policy(settings)
    full = base_policy
    clf_only = base_policy.model_copy(update={"sensitive_data_policy": "off", "destructive_action_policy": "off"})

    t0 = time.perf_counter()
    pipeline.security_decision("What is the capital of France?", clf_only, clf)
    first_ms = (time.perf_counter() - t0) * 1000.0
    for _ in range(WARMUP):
        pipeline.security_decision("Explain how photosynthesis works.", clf_only, clf)

    # ---- Stage 2 alone, fixed non-frozen prompt set -------------------------------------------
    call = clf or stage2_simulator.classify
    prompts: List[str] = []
    for name in LATENCY_SET:
        prompts += [c.prompt for c in evaluator.load_dataset(name).cases]
    s2_ms: List[float] = []
    for p in prompts:
        norm = normalize(p)
        s1 = analyze_stage1(p, clf_only, norm)
        t = time.perf_counter()
        call(p, norm, s1, clf_only)
        s2_ms.append((time.perf_counter() - t) * 1000.0)
    long_prompt = ("Please summarise the following meeting notes and list the action items for each person. " * 40)[:4000]
    nl = normalize(long_prompt)
    sl = analyze_stage1(long_prompt, clf_only, nl)
    long_ms = []
    for _ in range(5):
        t = time.perf_counter()
        call(long_prompt, nl, sl, clf_only)
        long_ms.append((time.perf_counter() - t) * 1000.0)

    # ---- accuracy on every dataset, both configurations ---------------------------------------
    results: Dict[str, object] = {}
    memo = Memo(clf or stage2_simulator.classify)
    for name in datasets:
        ds = evaluator.load_dataset(name)
        first = summarise(evaluator.evaluate(ds, clf_only, memo, include_prompts=False))        # uncached: latency is real
        second = summarise(evaluator.evaluate(ds, full, memo, include_prompts=False))
        second["decision_latency"] = None                                                       # cached pass: not a latency measurement
        entry = {"classifier_only": first, "full_system": second}
        if sweep:
            entry["threshold_sweep_classifier_only"] = {}
            for t in THRESHOLDS:
                pol = clf_only.model_copy(update={"risk_threshold": t, "uncertain_low": min(clf_only.uncertain_low, t - 1)})
                s = summarise(evaluator.evaluate(ds, pol, memo, include_prompts=False))
                entry["threshold_sweep_classifier_only"][str(t)] = {k: s[k] for k in ("recall", "fpr", "precision", "tp", "fp", "tn", "fn")}
        results[name] = entry

    env = {"python": platform.python_version(), "machine": platform.processor() or platform.machine(),
           "logical_cpus": os.cpu_count(), "stage2_threads_setting": settings.STAGE2_THREADS}
    for mod in ("torch", "transformers", "onnxruntime", "numpy"):
        try:
            env[mod] = __import__(mod).__version__
        except Exception:
            pass
    try:
        import torch

        env["torch_threads"] = torch.get_num_threads() if "deberta" in backend and "onnx" not in backend else None
    except Exception:
        pass
    return {
        "backend": backend, "provider": getattr(clf, "provider", stage2_simulator.PROVIDER), "model": getattr(clf, "model_id", None),
        "model_revision": stage2_backends.MODEL_REVISION if getattr(clf, "model_id", None) else None,
        "startup": {"load_seconds": round(load_s, 2), "first_inference_ms": round(first_ms, 1),
                    "process_to_ready_seconds": round(time.perf_counter() - t_proc, 2)},
        "memory_mb": {"rss_before_load": round(rss_before, 1), "rss_after_load": round(rss_loaded, 1),
                      "model_cost": round(rss_loaded - rss_before, 1), "rss_end": round(rss_mb(), 1), "peak": peak_mb()},
        "latency": {"stage2_only_fixed_set": lat_stats(s2_ms), "stage2_only_long_4000_chars": lat_stats(long_ms)},
        "environment": env, "datasets": results, "code_fingerprint": evaluator.code_fingerprint()[:12],
    }


# ------------------------------------------------------------------------------------------------
# Parent: orchestrate, aggregate, write
# ------------------------------------------------------------------------------------------------


def run_worker(backend: str, datasets: List[str], sweep: bool) -> Dict[str, object]:
    cmd = [sys.executable, str(Path(__file__).resolve()), "--worker", "--backend", backend, "--datasets", *datasets]
    if not sweep:
        cmd.append("--no-sweep")
    env = dict(os.environ, PYTHONIOENCODING="utf-8", GATEWAY_SKIP_DOTENV="1", TOKENIZERS_PARALLELISM="false")
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", env=env, cwd=str(BACKEND_DIR))
    for line in reversed(proc.stdout.splitlines()):
        if line.startswith("RESULT:"):
            return json.loads(line[len("RESULT:"):])
    return {"backend": backend, "error": f"worker failed (exit {proc.returncode}): {proc.stderr[-400:]}"}


def f(v: Optional[float]) -> str:
    return "n/a" if v is None else f"{v:.1f}%"


def markdown(runs: List[Dict[str, object]], datasets: List[str]) -> str:
    L: List[str] = ["# Stage 2 backend comparison", "",
                    f"Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')}. Every backend ran in its own fresh process.", ""]
    ok = [r for r in runs if "error" not in r]
    for r in runs:
        if "error" in r:
            L.append(f"* **{r['backend']}: FAILED** {r['error']}")
    L += ["", "## Resources", "", "| backend | load (s) | first inference (ms) | RSS before -> after load (MB) | model cost (MB) | peak RSS (MB) | Stage 2 p50 / p95 (ms) | long 4000-char p50 (ms) |",
          "|---|---|---|---|---|---|---|---|"]
    for r in ok:
        s, m, lat = r["startup"], r["memory_mb"], r["latency"]
        L.append(f"| {r['backend']} | {s['load_seconds']} | {s['first_inference_ms']} | {m['rss_before_load']} -> {m['rss_after_load']} | "
                 f"{m['model_cost']} | {m['peak']} | {lat['stage2_only_fixed_set']['p50_ms']} / {lat['stage2_only_fixed_set']['p95_ms']} | "
                 f"{lat['stage2_only_long_4000_chars']['p50_ms']} |")
    for cfg, title in (("classifier_only", "Classifier only (Stage 1 + Stage 2; risk-policy layer OFF)"),
                       ("full_system", "Full system (risk-policy layer ON)")):
        L += ["", f"## {title}", "", "| dataset | backend | cases | recall | FPR | precision | accuracy | TP | FP | TN | FN | err | decision p50 / p95 (ms) |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for d in datasets:
            for r in ok:
                e = r["datasets"][d][cfg]
                lat = e["decision_latency"]
                lat_s = f"{lat['p50_ms']} / {lat['p95_ms']}" if lat else "(cached pass)"
                L.append(f"| {d} | {r['backend']} | {e['cases']} | {f(e['recall'])} | {f(e['fpr'])} | {f(e['precision'])} | {f(e['accuracy'])} | "
                         f"{e['tp']} | {e['fp']} | {e['tn']} | {e['fn']} | {e['errors']} | {lat_s} |")
    L += ["", "## Per-category results (classifier only)", ""]
    for d in datasets:
        if d == "holdout":
            L.append("* holdout: binary labels only, no per-category breakdown exists.")
            continue
        L += ["", f"### {d}", "", "| category | role | total | " + " | ".join(f"{r['backend']}" for r in ok) + " |", "|---|---|---|" + "---|" * len(ok)]
        cats = [(c["category"], c["role"], c["total"]) for c in ok[0]["datasets"][d]["classifier_only"]["categories"]]
        for cat, role, total in cats:
            cells = []
            for r in ok:
                c = next(x for x in r["datasets"][d]["classifier_only"]["categories"] if x["category"] == cat)
                cells.append(f"{c['missed']} missed" if role == "attack" else f"{c['false_positives']} FP")
            L.append(f"| {cat} | {role} | {total} | " + " | ".join(cells) + " |")
    if any("threshold_sweep_classifier_only" in r["datasets"][datasets[0]] for r in ok):
        L += ["", "## Threshold sensitivity (classifier only; recall / FPR)", "", "| dataset | backend | " + " | ".join(f"t={t}" for t in THRESHOLDS) + " |",
              "|---|---|" + "---|" * len(THRESHOLDS)]
        for d in datasets:
            for r in ok:
                sw = r["datasets"][d].get("threshold_sweep_classifier_only", {})
                L.append(f"| {d} | {r['backend']} | " + " | ".join(f"{f(sw[str(t)]['recall'])} / {f(sw[str(t)]['fpr'])}" for t in THRESHOLDS) + " |")
    L += ["", "## Notes", "",
          "* The holdout is frozen and was written for the simulator-era project. Comparing backends on it is a SELECTION on that set: it is no longer a "
          "clean estimate for whichever backend is chosen. A fresh independent holdout is needed for a final claim.",
          "* Latencies are wall-clock on the machine listed under environment, single process, sequential requests, no GPU.",
          "* `peak RSS` is the process peak working set (Windows only; null elsewhere)."]
    return "\n".join(L) + "\n"


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--backends", nargs="+", default=["simulator", "deberta"])
    ap.add_argument("--datasets", nargs="+", default=DEFAULT_DATASETS)
    ap.add_argument("--no-sweep", action="store_true")
    ap.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--backend", help=argparse.SUPPRESS)
    ap.add_argument("--out-dir", default=str(HERE / "results"))
    args = ap.parse_args(argv)

    if args.worker:
        result = worker(args.backend, args.datasets, not args.no_sweep)
        print("RESULT:" + json.dumps(result))
        return 0

    runs = []
    for b in args.backends:
        print(f"[bench] {b} ...", flush=True)
        runs.append(run_worker(b, args.datasets, not args.no_sweep))
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    with open(out / f"stage2_comparison_{stamp}.json", "x", encoding="utf-8") as fh:
        json.dump({"generated_utc": stamp, "runs": runs}, fh, indent=1)
    md = markdown(runs, args.datasets)
    with open(out / f"stage2_comparison_{stamp}.md", "x", encoding="utf-8") as fh:
        fh.write(md)
    print(md)
    print(f"[bench] saved {out / ('stage2_comparison_' + stamp + '.md')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
