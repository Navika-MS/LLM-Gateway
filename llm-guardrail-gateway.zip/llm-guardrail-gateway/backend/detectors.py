"""
Deterministic PII and secret detectors (Stage 1 input checks and the output guard).

Design rules, each traced to an audit finding:
  * Linear time on any input (audit C3: the old email regex was O(n^2); 40k chars took 21 s).
    Emails are found by locating '@' and scanning a *bounded* window either side.
  * Boundary-aware (audit M5: the old phone regex matched any 10 digits, so a card number was
    labelled PHONE and epoch timestamps were blocked).
  * Brand + length + Luhn for cards (a Luhn check alone passes ~10% of random digit strings).
  * Documented test data (RFC 2606 reserved domains, published processor test PANs) is reported as
    `synthetic` and is not treated as personal data; real-looking values are.
  * No detector echoes the matched value: callers get a kind/label and a span, never the secret.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

# ------------------------------------------------------------------------------------------------
# Result type
# ------------------------------------------------------------------------------------------------


@dataclass(frozen=True)
class Detection:
    kind: str                 # EMAIL | PHONE | SSN | CREDIT_CARD | SECRET_*
    label: str                # stable machine label, e.g. PII_EMAIL_DETECTED
    span: Tuple[int, int]
    synthetic: bool = False   # documented test/placeholder data: reported, but not blocking


# ------------------------------------------------------------------------------------------------
# Email (bounded scan around '@')
# ------------------------------------------------------------------------------------------------

_LOCAL_OK = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._%+-")
_DOMAIN_OK = frozenset("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-")
_MAX_LOCAL = 64
_MAX_DOMAIN = 255
_MAX_AT_CANDIDATES = 64

# RFC 2606 / RFC 6761 names that can never belong to a real person.
_RESERVED_DOMAINS = ("example.com", "example.org", "example.net", "example.edu")
_RESERVED_TLDS = ("test", "example", "invalid", "localhost")


def _is_reserved_domain(domain: str) -> bool:
    d = domain.lower()
    if any(d == r or d.endswith("." + r) for r in _RESERVED_DOMAINS):
        return True
    return d.rsplit(".", 1)[-1] in _RESERVED_TLDS


def find_emails(text: str) -> List[Detection]:
    out: List[Detection] = []
    n = len(text)
    i = text.find("@")
    seen = 0
    while i != -1 and seen < _MAX_AT_CANDIDATES:
        seen += 1
        lo = max(0, i - _MAX_LOCAL)
        j = i - 1
        while j >= lo and text[j] in _LOCAL_OK:
            j -= 1
        local = text[j + 1:i]
        hi = min(n, i + 1 + _MAX_DOMAIN)
        k = i + 1
        while k < hi and text[k] in _DOMAIN_OK:
            k += 1
        domain = text[i + 1:k].rstrip(".-")
        if (
            local
            and not local.startswith(".")
            and ".." not in local
            and "." in domain
            and ".." not in domain
            and not domain.startswith(("-", "."))
            and domain.rsplit(".", 1)[-1].isalpha()
            and len(domain.rsplit(".", 1)[-1]) >= 2
        ):
            out.append(Detection("EMAIL", "PII_EMAIL_DETECTED", (j + 1, i + 1 + len(domain)),
                                 synthetic=_is_reserved_domain(domain)))
        i = text.find("@", i + 1)
    return out


# ------------------------------------------------------------------------------------------------
# Phone (NANP + explicit-international), boundary-aware
# ------------------------------------------------------------------------------------------------

# NANP: area code and exchange start 2-9. Separators/parentheses make the intent explicit.
_PHONE_NANP = re.compile(
    r"(?<![\w.+-])(?:\+?1[ .-]?)?(?:\(([2-9]\d{2})\)[ .-]?|([2-9]\d{2})[ .-])([2-9]\d{2})[ .-]([0-9]{4})(?![\w-])"
)
# Ten bare digits are only a phone number when the text says so ("call 4155550134").
_PHONE_BARE = re.compile(r"(?<![\w.+-])(?:\+?1[ .-]?)?([2-9]\d{2})([2-9]\d{2})(\d{4})(?![\w-])")
_PHONE_CUE = re.compile(r"(?:phone|tel\b|telephone|call|text|sms|mobile|cell|fax|whatsapp|dial|contact|reach)", re.I)
# Explicit international form: must start with '+', 8-15 digits overall.
_PHONE_INTL = re.compile(r"(?<![\w.])\+\d{1,3}(?:[ .-]?\(?\d{1,5}\)?){2,5}(?![\w-])")


def find_phones(text: str) -> List[Detection]:
    out: List[Detection] = []
    for m in _PHONE_NANP.finditer(text):
        out.append(Detection("PHONE", "PII_PHONE_DETECTED", m.span()))
    for m in _PHONE_BARE.finditer(text):
        start = max(0, m.start() - 30)
        if _PHONE_CUE.search(text[start:m.start()]):
            out.append(Detection("PHONE", "PII_PHONE_DETECTED", m.span()))
    for m in _PHONE_INTL.finditer(text):
        digits = sum(c.isdigit() for c in m.group(0))
        if 8 <= digits <= 15:
            out.append(Detection("PHONE", "PII_PHONE_DETECTED", m.span()))
    return out


# ------------------------------------------------------------------------------------------------
# SSN (structurally valid only: SSA never issues 000, 666, 9xx areas, 00 groups, 0000 serials)
# ------------------------------------------------------------------------------------------------

_SSN = re.compile(r"(?<![\w-])(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}(?![\w-])")


def find_ssns(text: str) -> List[Detection]:
    return [Detection("SSN", "PII_SSN_DETECTED", m.span()) for m in _SSN.finditer(text)]


# ------------------------------------------------------------------------------------------------
# Payment cards
# ------------------------------------------------------------------------------------------------

# Each repetition consumes exactly one digit (optionally preceded by one separator): linear.
_CARD_CANDIDATE = re.compile(r"(?<![\d-])\d(?:[ -]?\d){12,18}(?![\d-])")

# Published processor test numbers: documented, never real accounts.
_TEST_PANS = frozenset({
    "4111111111111111", "4012888888881881", "4242424242424242", "4000056655665556",
    "5555555555554444", "5105105105105100", "5200828282828210", "2223003122003222",
    "378282246310005", "371449635398431", "378734493671000",
    "6011111111111117", "6011000990139424", "3530111333300000", "3566002020360505",
    "30569309025904", "38520000023237", "6200000000000005",
})


def luhn_valid(digits: str) -> bool:
    if not digits.isdigit() or not 12 <= len(digits) <= 19:
        return False
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def card_brand(digits: str) -> str:
    """Return the issuer brand if prefix and length are consistent, else ''."""
    n = len(digits)
    p2, p3, p4 = int(digits[:2]), int(digits[:3]), int(digits[:4])
    if digits[0] == "4" and n in (13, 16, 19):
        return "VISA"
    if n == 16 and (51 <= p2 <= 55 or 2221 <= p4 <= 2720):
        return "MASTERCARD"
    if n == 15 and p2 in (34, 37):
        return "AMEX"
    if 16 <= n <= 19 and (p4 == 6011 or p2 == 65 or 644 <= p3 <= 649 or 622126 <= int(digits[:6]) <= 622925):
        return "DISCOVER"
    if 14 <= n <= 19 and (300 <= p3 <= 305 or p4 == 3095 or p2 in (36, 38, 39)):
        return "DINERS"
    if 16 <= n <= 19 and 3528 <= p4 <= 3589:
        return "JCB"
    if 16 <= n <= 19 and p2 == 62:
        return "UNIONPAY"
    return ""


def find_cards(text: str) -> List[Detection]:
    out: List[Detection] = []
    for m in _CARD_CANDIDATE.finditer(text):
        digits = re.sub(r"\D", "", m.group(0))
        if luhn_valid(digits) and card_brand(digits):
            out.append(Detection("CREDIT_CARD", "PII_CREDIT_CARD_DETECTED", m.span(),
                                 synthetic=digits in _TEST_PANS))
    return out


# ------------------------------------------------------------------------------------------------
# Secrets (credentials in a prompt or in a generated answer)
# ------------------------------------------------------------------------------------------------

_SECRET_PATTERNS = (
    ("SECRET_API_KEY", re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,200}")),
    ("SECRET_API_KEY", re.compile(r"(?<![A-Za-z0-9])sk-[A-Za-z0-9]{32,100}")),
    ("SECRET_AWS_KEY", re.compile(r"(?<![A-Z0-9])(?:AKIA|ASIA)[0-9A-Z]{16}(?![A-Z0-9])")),
    ("SECRET_GITHUB_TOKEN", re.compile(r"gh[pousr]_[A-Za-z0-9]{36,255}")),
    ("SECRET_GITHUB_TOKEN", re.compile(r"github_pat_[A-Za-z0-9_]{50,255}")),
    ("SECRET_SLACK_TOKEN", re.compile(r"xox[baprs]-[A-Za-z0-9-]{10,100}")),
    ("SECRET_GOOGLE_KEY", re.compile(r"AIza[0-9A-Za-z_\-]{35}")),
    ("SECRET_STRIPE_KEY", re.compile(r"(?:sk|rk)_live_[0-9a-zA-Z]{24,99}")),
    ("SECRET_PRIVATE_KEY", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?-----")),
    ("SECRET_JWT", re.compile(r"eyJ[A-Za-z0-9_-]{10,500}\.eyJ[A-Za-z0-9_-]{10,500}\.[A-Za-z0-9_-]{10,500}")),
)
_SECRET_ASSIGN = re.compile(
    r"\b(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret)\b"
    r"\s*[:=]\s*[\"']?([^\s\"']{12,100})",
    re.I,
)
_PLACEHOLDER = re.compile(
    r"^(?:your|example|sample|changeme|change_me|placeholder|xxx+|\*+|<.*>|\$\{.*\}|\{\{.*\}\}|todo|none|null|redacted|dummy|test)",
    re.I,
)


def find_secrets(text: str) -> List[Detection]:
    out: List[Detection] = []
    for kind, rx in _SECRET_PATTERNS:
        for m in rx.finditer(text):
            out.append(Detection(kind, "SECRET_" + kind.split("_", 1)[1] + "_DETECTED", m.span()))
    for m in _SECRET_ASSIGN.finditer(text):
        value = m.group(1)
        if not _PLACEHOLDER.match(value):
            out.append(Detection("SECRET_ASSIGNMENT", "SECRET_ASSIGNMENT_DETECTED", m.span(1)))
    return out


# ------------------------------------------------------------------------------------------------
# Public helpers
# ------------------------------------------------------------------------------------------------


def find_pii(text: str) -> List[Detection]:
    """All PII detections, including synthetic ones (callers decide what to do with them)."""
    # Cards first so card digits can never be re-labelled as a phone number.
    found = find_cards(text) + find_emails(text) + find_ssns(text) + find_phones(text)
    card_spans = [d.span for d in found if d.kind == "CREDIT_CARD"]
    return [d for d in found
            if d.kind != "PHONE" or not any(s[0] <= d.span[0] < s[1] for s in card_spans)]


def first_blocking_pii(text: str) -> Optional[Detection]:
    """First PII detection that should block (i.e. is not documented synthetic data)."""
    for d in find_pii(text):
        if not d.synthetic:
            return d
    return None


def first_secret(text: str) -> Optional[Detection]:
    found = find_secrets(text)
    return found[0] if found else None


def detect_sensitive(text: str, *, pii: bool = True, secrets: bool = True) -> Optional[Detection]:
    """Single entry point for output scanning: first blocking PII or secret, else None."""
    if pii:
        d = first_blocking_pii(text)
        if d:
            return d
    if secrets:
        return first_secret(text)
    return None
