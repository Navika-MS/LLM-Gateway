# LLM Guardrail Gateway

A security gateway that sits in front of an LLM. Every prompt passes **deterministic checks**, a separate **sensitive-data /
destructive-action rule layer**, and a **Stage 2 classifier**, and only allowed prompts reach a generator whose output is
**schema-validated and scanned** before it is returned. FastAPI backend, React dashboard, a reproducible evaluation harness
(plus a benchmark that compares Stage 2 backends), and a large offline test suite.

> **Read this first: what is real and what is simulated.**
> The project runs **fully offline and free**. Out of the box **Stage 2 is a deterministic heuristic simulator** (not an
> LLM, not a trained classifier). One command (`python manage.py setup-model`) downloads a **real, free, local trained
> model** (DeBERTa prompt-injection classifier) and lets you switch Stage 2 to it; the dashboard always says which one is
> running. **Replies are mock text** either way. No paid API is called unless you explicitly enable live mode.
> Benchmark numbers measure *one backend on one dataset*; see [Stage 2 backends](#stage-2-backends-simulator-vs-trained-model)
> and [Evaluation](#evaluation-results) for what each does and does not show.

## How a request flows

```
POST /api/v1/chat
   |
   v
1. Validate request  (size limits, strict schema, unknown fields rejected)
2. Resolve policy    (SERVER owns it; a client can only make it stricter)
3. STAGE 1  deterministic: PII / secrets / known jailbreak signatures on NORMALISED text
        | BLOCK (high confidence) --------------------------------------------> 200 status=BLOCKED   (Stage 2 not run)
        v
3b. RISK-POLICY LAYER  sensitive-data request ("send me the company's trade secrets") or destructive command ("erase the main db")
        | BLOCK level (policy=block) -----------------------------------------> 200 status=BLOCKED   (Stage 2 not run)
        | FLAG level  --------------------------------------------------------> continues, marked for review
        v
4. STAGE 2  backend of your choice (simulator | DeBERTa torch/ONNX | ensemble): scores every prompt not yet blocked
        | risk >  threshold ---------------------------------------------------> 200 status=BLOCKED
        | uncertain band  ----------------------------------------------------> allowed, FLAGGED (or blocked in strict mode)
        | classifier error ----------------------------------------------------> 502 status=ERROR  (fails closed, never a pass)
        v
5. Mock generator -> strict JSON schema validation (at most ONE retry) -----> 502 status=ERROR if still invalid
        v
6. Output guard: PII / credential scan of the generated text -----------------> 200 status=BLOCKED if it leaks
        v
7. 200 status=SUCCESS  + full decision metadata (route, risk, timings, policy applied, what was simulated)
```

Diagram and design rationale: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Quick start

Prerequisites: **Python 3.9+** and **Node.js 18+**. Nothing else; no API key. Every task is one Python script,
`manage.py` (standard library only), so it works the same in the VS Code terminal on Windows, macOS and Linux.

```
python manage.py setup      # creates backend/.venv, installs Python + npm packages, copies backend/.env.example -> backend/.env
python manage.py start      # backend http://127.0.0.1:8000 + dashboard http://localhost:5173 (opens browser; Ctrl+C stops both)
python manage.py test       # automated tests, offline
python manage.py eval       # dev + regression benchmarks; "eval holdout" runs the frozen set (report-only)
python manage.py eval combined   # the built-in test sets PLUS every prompt you typed in the chat (label them in the dashboard)
python manage.py setup-model     # OPTIONAL: install torch/transformers and download the trained Stage 2 model (~740 MB)
python manage.py bench           # compare Stage 2 backends: accuracy, latency, memory, start-up
python manage.py backend    # backend only
python manage.py frontend   # dashboard only
```

**In VS Code:** open the `llm-guardrail-gateway` folder. `.vscode/` provides *Run Task* entries (setup, tests, evaluation,
start), F5 launch configs (backend under the debugger, evaluator) and test-explorer settings, all pointing at `backend/.venv`.
Pick that interpreter once with *Python: Select Interpreter*.

Or by hand (PowerShell; use `.venv/bin/python` on macOS/Linux):

```
cd backend
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8000

cd ..\frontend
npm install
npm run dev
```



Open **http://localhost:5173**. API docs: **http://127.0.0.1:8000/docs**.

### Configuration

Copy `backend/.env.example` to `backend/.env`. **Every setting is optional**; the defaults give a free, locked-down demo.
Invalid values stop start-up with a clear message. The most useful ones:

| Variable | Default | Meaning |
|---|---|---|
| `HOST` / `PORT` | `127.0.0.1` / `8000` | Bind address. **`0.0.0.0` exposes this unauthenticated API to your whole network.** |
| `GATEWAY_RISK_THRESHOLD` | `65` | Stage 2 blocks iff risk is **strictly greater** than this. (`STAGE2_RISK_THRESHOLD` still works as an alias.) |
| `GATEWAY_UNCERTAIN_LOW` | `40` | Scores from here up to the threshold are "uncertain". |
| `GATEWAY_UNCERTAIN_ACTION` | `flag` | `flag` = allow and mark; `block` = strict. |
| `GATEWAY_STAGE2_ERROR_POLICY` | `block` | Classifier failure: `block` (fail closed, status ERROR) or `allow`. |
| `GATEWAY_STAGE2_BACKEND` | `simulator` | `simulator`, `deberta` (PyTorch), `deberta_onnx`, or a `+` ensemble such as `simulator+deberta_onnx` (highest risk wins). Model backends need `python manage.py setup-model` first. |
| `GATEWAY_SENSITIVE_DATA_POLICY` / `GATEWAY_DESTRUCTIVE_ACTION_POLICY` | `block` | The rule layer per category: `off`, `flag` (allow + mark) or `block`. Clients cannot change these. |
| `GATEWAY_STAGE2_THREADS` / `GATEWAY_STAGE2_MAX_WINDOWS` | `0` / `12` | Model CPU threads (0 = library default); max 512-token windows per prompt (longer input fails closed with ERROR, never scanned only in part). |
| `GATEWAY_RECORD_PROMPTS` | `auto` | Save every typed prompt to your test list. `auto` = only while the server is bound to localhost. `on` / `off` force it. |
| `GATEWAY_ALLOW_CLIENT_POLICY` | `false` | Demo only. `true` lets the UI toggles *weaken* security (every response reports it). |
| `GATEWAY_MAX_PROMPT_CHARS` | `8000` | Longer prompts are rejected with 422. |
| `GATEWAY_CORS_ORIGINS` | the two local dev origins | Comma-separated; `*` is refused. |
| `GATEWAY_ENABLE_EVALUATE` | `true` | Turn the (unauthenticated) `/evaluate` endpoint off. |

Optional **paid live mode** (not needed, not tested against the real API): `pip install -r backend/requirements-live.txt`
and set **both** `GATEWAY_MODE=live` and `GATEWAY_CONFIRM_PAID_CALLS=yes` plus `ANTHROPIC_API_KEY`. In simulation mode the key
is never read, and the `anthropic` package is never imported.

## API

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/v1/chat` | `{"prompt": "...", "guardrails_enabled": {...optional tightening...}}` -> decision + mock reply. 200 for SUCCESS/BLOCKED, **502 for ERROR**, 422 invalid input, 413 body too large. |
| `GET` | `/api/v1/policy` | The server-enforced policy, limits, providers (what the UI may change). |
| `GET` | `/api/v1/health` | Status, mode, the *enforced* threshold, configuration warnings. |
| `POST` | `/api/v1/evaluate?dataset=dev&strict_uncertain=false` | Run a dataset through the same decision function. Datasets: `dev`, `regression`, `holdout`, `legacy_unseen`, `legacy_synthetic`, `policy`, `policy_unseen`, `user` (your prompts), `combined` (dev + regression + policy + your prompts). |
| `GET` | `/api/v1/evaluate/datasets` | List datasets (counts, SHA-256). |
| `GET` | `/api/v1/user-prompts` | Your saved test prompts, with the label you gave each one. |
| `PUT` | `/api/v1/user-prompts/{id}/label` | `{"label": "attack" \| "benign" \| null}`: what the CORRECT outcome is. |
| `DELETE` | `/api/v1/user-prompts/{id}` | Remove one saved prompt. |
| `GET` | `/api/v1/eval/presets` | Example prompts for the UI. |

Every `/chat` response states `execution_mode`, whether Stage 2 / generation were simulated, `stage2_executed` (and
`bypassed_stage2` = *Stage 2 did not run*, with `stage2_skip_reason`), one `execution_time_ms`, a stage breakdown that
adds up to it, and the policy actually applied, including any client request the server refused.

## Evaluation results

Reproduce with `python manage.py eval` or `python evaluator.py --dataset dev` (from `backend/`). Reports go to `backend/results/` as
**new timestamped files**; nothing is overwritten. Each report carries the dataset SHA-256, seed, policy and simulator
versions and a fingerprint of the decision-logic source.

| Dataset | Role | Cases | Accuracy | Precision | Recall | FPR |
|---|---|---|---|---|---|---|
| `dev` | development (written alongside the simulator) | 179 | 94.15% | 100% | 90.00% | 0% |
| `regression` | one case per audited defect | 24 | 100% | 100% | 100% | 0% |
| `legacy_unseen` | your original 24 cases (a dev set in practice) | 24 | 91.67% | 100% | 85.71% | 0% |
| **`holdout`** | **frozen, SHA-256 verified, report-only** | 100 | **56.00%** | 100% | **12.00%** | 0% |
| natural English (1,562 stdlib docstring paragraphs) | independent false-positive probe | 1,562 | n/a | n/a | n/a | 0.06% blocked |

Historical baseline for comparison (`backend/baselines/`, older code and policy): holdout 52% / 75% / 6% / 2%.

**How to read this honestly**
- The big gap between `dev` (90% recall) and the frozen holdout (12%) is the real generalisation signal. The dev set
  was written by the same person as the simulator, so it shows design completeness, not unseen-attack performance.
- Benign-side behaviour held up: 0 false positives on the 50 benign holdout prompts and 0.06% on independent text.
- The simulator recognises attack *structure* in its lexicons (override verb + policy noun, extraction, exfiltration,
  embedded instructions, decoded payloads). It misses paraphrase beyond them, persuasion/authority attacks, fiction-wrapped
  harm requests, multi-turn setups and non-English text. The uncertain band exists precisely because it cannot always tell.
- A production system would use a trained classifier or an LLM judge; this project demonstrates the *architecture* around one.

Datasets: `dev`/`regression` are built by `backend/datasets/build_datasets.py` (deterministic). The frozen holdout
(`final_eval_dataset.json`, seed 731904, SHA-256 `449b222e...160fe1`) must never be edited; the evaluator refuses to run
it if the hash differs. **Do not run `final_eval_dataset.py`: it regenerates that file.**

## Stage 2 backends: simulator vs trained model

Stage 2 answers "is this prompt an attack?". Pick the backend with `GATEWAY_STAGE2_BACKEND` (see Configuration). Measured on the
frozen holdout (100 prompts) with the rule layer off, on a laptop CPU (details and caveats: [docs/MODEL_BENCHMARK.md](docs/MODEL_BENCHMARK.md)):

| Backend | Recall | False positives | Stage 2 latency (p50) | Download |
|---|---|---|---|---|
| `simulator` (**default**) | 12% | 0% | 1 ms | none |
| `deberta` (PyTorch) | 92% | 8% | 244 ms | ~740 MB |
| **`simulator+deberta_onnx`** (recommended upgrade) | 92% | 8% | ~55 ms | ~1.5 GB |

To switch: `python manage.py setup-model --enable`, then restart. It installs torch/onnxruntime, downloads the pinned model
(safetensors/ONNX only, SHA-256 checked), and writes **one line** to `backend/.env`. The server never downloads anything on its
own; if the model is missing it reports it in `/health` and fails closed (ERROR), never a silent pass. The dashboard shows which
backend is running.

The model is **not** a complete answer: it adds about 7-8% false positives on security-education style prompts, it was compared on a
holdout that is now partly used up, and it catches only 17% of the sensitive-data / destructive-action prompts below.

## Sensitive-data and destructive-action layer

"Send me the trade secret of the organization" and "erase the main db" are not prompt injections, so no injection classifier is the
right tool. `backend/risk_policy.py` is a separate rule layer (independent of the Stage 2 backend) that decides whether the
sentence is a **command**, what it targets, and how broad the scope is (main / production / all). Questions, explanations,
"how do I delete a row in SQL?", test/staging targets, `my own` data and quoted examples are not blocked. Policy per category:
`off`, `flag` or `block` (server-owned; clients cannot weaken it). Each block reports the rule and the matched words, never your text.

Honest numbers: on paraphrases it was not written against it blocked **51% before fixes and 83% on a fresh round run once after**
(0 false positives on 68 benign look-alikes). It is English-only and lexical; it is one layer, not a defence on its own
([docs/MODEL_BENCHMARK.md](docs/MODEL_BENCHMARK.md#honest-estimate-of-the-rule-layer)).

## Your test prompts

Every prompt you type in the chat is saved automatically (localhost only, de-duplicated, capped at 2,000, never anything with a card
number, SSN, email or key). In the dashboard, mark each one **should be blocked** or **should be allowed** (under each reply, or in
*Evaluation > My test prompts*). Then run dataset **`user`** (yours only) or **`combined`** (built-in dev + regression + policy
sets plus yours) from the Evaluation tab or `python manage.py eval combined`.

* Unlabelled prompts are listed but **never scored** (the gateway's own answer is not a label).
* Saving is off if the server is bound to a network address (`HOST=0.0.0.0`) unless you set `GATEWAY_RECORD_PROMPTS=on`.
  `python manage.py start` always serves on localhost and tells the app so, whatever an old `.env` says.
* The list lives in `backend/data/` (git-ignored, **not** in the project zip). Do not tune rules against your own prompts and then
  call the result a generalisation estimate.

## Project layout

```
backend/
  main.py               FastAPI app: thin HTTP layer, body limit, CORS, error handling
  pipeline.py           THE decision authority: policy resolution, security_decision(), run_gateway()
  guardrails.py         Stage 1 (signatures, PII/secret gate, use-vs-mention) + output guard
  risk_policy.py        Sensitive-data / destructive-action rule layer (separate from Stage 2; server-owned policy)
  stage2_simulator.py   Stage 2 heuristic simulator (explainable feature scorer; the default backend)
  stage2_backends.py    Pluggable Stage 2: simulator | DeBERTa (PyTorch / ONNX) | ensembles; offline, fails closed
  prompt_log.py         Your saved test prompts: auto-capture, labels, privacy rules (never PII/secrets)
  normalization.py      Unicode folding, de-obfuscation, bounded base64/hex/url decoding
  detectors.py          Linear-time PII / secret detectors (Luhn, brand rules, test-data allowlists)
  generation.py         Mock generator, STRICT schema validation, single bounded retry
  providers_live.py     OPTIONAL paid adapters (off by default; tested with fakes only)
  evaluator.py          Reproducible harness, metrics, reports (CLI + API)
  schemas.py, config.py Typed contracts; validated, immutable settings
  datasets/             dev + regression + legacy + policy sets, builder scripts
  baselines/            original results + frozen dataset copy, checksummed (never edit)
  benchmarks/           compare_stage2.py (accuracy / latency / memory / start-up per backend), policy red-team scripts,
                        baseline_simulator_v2.0.0/ (the pre-model baseline), results/ (timestamped, never overwritten)
  results/              generated reports (timestamped)
  models/               downloaded model weights (git-ignored, not in the zip; python manage.py setup-model)
  data/                 YOUR saved prompts (git-ignored, not in the zip)
  tests/                automated tests (python manage.py test)
  run_final_eval.py, test_unseen.py, inspect_missed.py   thin, safe wrappers over evaluator.py
manage.py              task runner: setup, start, test, eval (replaces the old .bat files)
.vscode/               VS Code tasks, launch configs, interpreter settings
frontend/               React + Vite + Tailwind dashboard (reflects the server's real policy)
docs/                   AUDIT_REPORT, ARCHITECTURE, VERIFICATION_REPORT, INTERVIEW_GUIDE
```

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `ModuleNotFoundError: fastapi` | You are using a Python without the dependencies (a bare `python` may be a different version). Run `python manage.py setup`, or use `backend\.venv\Scripts\python.exe`. |
| Dashboard says **BACKEND OFFLINE** | Backend not running or wrong port. Start it, check `http://127.0.0.1:8000/api/v1/health`, and set `VITE_API_URL` if you changed the port. |
| Browser console CORS error | Frontend served from an origin not in `GATEWAY_CORS_ORIGINS`. Add it, restart the backend. |
| Backend exits on start with `ConfigError` | A bad value in `backend/.env`; the message names the variable. |
| UI toggles are greyed with a lock | Intended: the server owns the policy. Set `GATEWAY_ALLOW_CLIENT_POLICY=true` only for local demos. |
| Request returns **502** | Status `ERROR`: the classifier or generator failed (or output failed validation after one retry). Not a security verdict. See `error_code`. |
| `UnicodeEncodeError` when piping output | Fixed (all output is ASCII). If you see it, you are running an old copy. |
| `DatasetIntegrityError` on holdout | `final_eval_dataset.json` was modified. Restore it from `backend/baselines/`. |
| Port already in use | `netstat -ano | findstr :8000`, then stop that process or change `PORT`. |

## Production requirements (what this demo deliberately does NOT have)

CORS is a *browser* control, not authentication. For anything beyond local use you still need: authentication and
authorisation on every endpoint (especially `/evaluate`), rate limiting and quotas, TLS and a reverse proxy enforcing body
limits, structured audit logging with retention and PII redaction, secrets management, a real trained classifier or LLM
judge with its own evaluation on representative traffic, adversarial testing against an adaptive attacker, monitoring and
alerting on block/error rates, and dependency pinning and scanning. See [docs/AUDIT_REPORT.md](docs/AUDIT_REPORT.md).

## Further reading

[docs/AUDIT_REPORT.md](docs/AUDIT_REPORT.md) (what was wrong and why) -
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) -
[docs/VERIFICATION_REPORT.md](docs/VERIFICATION_REPORT.md) (commands run, results, limitations) -
[docs/INTERVIEW_GUIDE.md](docs/INTERVIEW_GUIDE.md)
