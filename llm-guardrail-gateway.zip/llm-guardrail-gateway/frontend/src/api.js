// Thin client for the gateway API. All security decisions are made by the server; the UI only displays them.
const BASE_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';

async function readJson(response) {
  try {
    return await response.json();
  } catch {
    return null;
  }
}

function describeError(status, body) {
  if (status === 422 && Array.isArray(body?.detail)) {
    return 'Invalid request: ' + body.detail.map((d) => `${(d.loc || []).slice(1).join('.') || 'body'} ${d.msg}`).join('; ');
  }
  if (status === 413) return 'Request body too large.';
  if (typeof body?.detail === 'string') return body.detail;
  return `Server responded with status ${status}`;
}

/**
 * Send a prompt. `requestedPolicy` is a REQUEST to tighten the policy; the server owns the policy and reports
 * what it applied or refused in `response.policy`. A 502 carries a structured status=ERROR response (a reliability
 * failure, distinct from a security BLOCK), so it is returned rather than thrown.
 */
export async function sendChatMessage(prompt, requestedPolicy) {
  const response = await fetch(`${BASE_URL}/api/v1/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, guardrails_enabled: requestedPolicy }),
  });
  const body = await readJson(response);
  if (response.ok || (response.status === 502 && body?.status === 'ERROR')) return body;
  throw new Error(describeError(response.status, body));
}

export async function runEvaluationBenchmark(dataset = 'dev', strictUncertain = false) {
  const qs = new URLSearchParams({ dataset, strict_uncertain: String(strictUncertain) });
  const response = await fetch(`${BASE_URL}/api/v1/evaluate?${qs}`, { method: 'POST' });
  const body = await readJson(response);
  if (!response.ok) throw new Error(describeError(response.status, body));
  return body;
}

export async function fetchDatasets() {
  const response = await fetch(`${BASE_URL}/api/v1/evaluate/datasets`);
  if (!response.ok) throw new Error('Could not list datasets');
  return response.json();
}

// ---- your saved test prompts (every prompt typed in the chat is saved automatically by the server) ----
export async function fetchUserPrompts() {
  const response = await fetch(`${BASE_URL}/api/v1/user-prompts`);
  const body = await readJson(response);
  if (!response.ok) throw new Error(describeError(response.status, body));
  return body; // { enabled, counts, items }
}

export async function labelUserPrompt(id, label) {
  const response = await fetch(`${BASE_URL}/api/v1/user-prompts/${encodeURIComponent(id)}/label`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ label }),
  });
  const body = await readJson(response);
  if (!response.ok) throw new Error(describeError(response.status, body));
  return body;
}

export async function deleteUserPrompt(id) {
  const response = await fetch(`${BASE_URL}/api/v1/user-prompts/${encodeURIComponent(id)}`, { method: 'DELETE' });
  const body = await readJson(response);
  if (!response.ok) throw new Error(describeError(response.status, body));
  return body;
}

export async function fetchPolicy() {
  const response = await fetch(`${BASE_URL}/api/v1/policy`);
  if (!response.ok) throw new Error('Could not load the server policy');
  return response.json();
}

export async function fetchPromptPresets() {
  try {
    const response = await fetch(`${BASE_URL}/api/v1/eval/presets`);
    if (!response.ok) return [];
    return await response.json();
  } catch {
    return []; // no stale, hard-coded fallback: presets describe the server's behaviour, so they come from the server
  }
}

export async function fetchHealthStatus() {
  try {
    const response = await fetch(`${BASE_URL}/api/v1/health`);
    if (!response.ok) return { status: 'offline' };
    return await response.json();
  } catch {
    return { status: 'offline' };
  }
}
