import React, { useState, useEffect } from 'react';
import { Shield, MessageSquare, BarChart3, FlaskConical, AlertTriangle } from 'lucide-react';
import GuardrailControls from './components/GuardrailControls';
import ChatWindow from './components/ChatWindow';
import LogsViewer from './components/LogsViewer';
import EvaluationDashboard from './components/EvaluationDashboard';
import { sendChatMessage, fetchPromptPresets, fetchHealthStatus, fetchPolicy } from './api';

const CONTROL_KEYS = ['pii_check', 'injection_check', 'ai_classifier_check', 'schema_enforcement', 'output_pii_check'];

// What is Stage 2, really? Taken from the server's /health, never assumed.
function describeStage2(health) {
  const s2 = health?.stage2;
  const members = s2?.members || (s2 ? [s2] : []);
  const model = members.find((m) => m.model);
  const mixesRules = members.some((m) => !m.model);
  if (!health || health.status !== 'healthy') return { short: 'Stage 2', long: '' };
  if (!model) {
    return { short: 'Local heuristic Stage 2 simulator', long: 'Stage 2 is a deterministic heuristic simulator, not an LLM or trained classifier.' };
  }
  const state = model.error ? ` NOT LOADED (${model.error})` : model.ready ? '' : ' (loading the model...)';
  const extra = mixesRules ? ' combined with the rule-based scorer (highest risk wins)' : '';
  return {
    short: `Stage 2: ${model.model.split('/').pop()}`,
    long: `Stage 2 is a trained model (${model.model}, ${model.runtime}) running locally${extra}${state}.`,
  };
}

export default function App() {
  const [activeTab, setActiveTab] = useState('chat'); // 'chat' | 'evaluation'
  const [policyInfo, setPolicyInfo] = useState(null); // what the SERVER enforces (GET /api/v1/policy)
  const [requested, setRequested] = useState(null); // what the UI asks for (a request, never a command)
  const [messages, setMessages] = useState([]);
  const [latestResponse, setLatestResponse] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [presets, setPresets] = useState([]);
  const [healthStatus, setHealthStatus] = useState(null);

  useEffect(() => {
    async function init() {
      setPresets(await fetchPromptPresets());
      setHealthStatus(await fetchHealthStatus());
      try {
        const info = await fetchPolicy();
        setPolicyInfo(info);
        setRequested({ ...info.server_policy });
      } catch {
        setPolicyInfo(null);
      }
    }
    init();
  }, []);

  // While a Stage 2 model is still loading in the background, keep the status strip fresh.
  useEffect(() => {
    const s2 = healthStatus?.stage2;
    const members = s2?.members || (s2 ? [s2] : []);
    const loading = members.some((m) => m.model && !m.ready && !m.error);
    if (!loading) return undefined;
    const timer = setInterval(async () => setHealthStatus(await fetchHealthStatus()), 3000);
    return () => clearInterval(timer);
  }, [healthStatus]);

  const handleSendMessage = async (promptText) => {
    setMessages((prev) => [...prev, { role: 'user', content: promptText, timestamp: new Date().toLocaleTimeString() }]);
    setIsLoading(true);
    try {
      const payload = requested
        ? Object.fromEntries([...CONTROL_KEYS, 'risk_threshold'].map((k) => [k, requested[k]]))
        : undefined;
      const res = await sendChatMessage(promptText, payload);
      setMessages((prev) => [...prev, { role: 'assistant', ...res, timestamp: new Date().toLocaleTimeString() }]);
      setLatestResponse(res);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', status: 'ERROR', error_code: 'CLIENT_ERROR', block_reason: err.message, timestamp: new Date().toLocaleTimeString() },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const online = healthStatus?.status === 'healthy';
  const warnings = healthStatus?.warnings || [];
  const stage2Text = describeStage2(healthStatus);

  return (
    <div className="min-h-screen flex flex-col bg-[#080C14] text-slate-100 selection:bg-emerald-500 selection:text-black">
      <header className="border-b border-white/10 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-500 text-slate-950 shadow-lg shadow-emerald-500/20">
              <Shield size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold tracking-tight text-white">LLM Guardrail Gateway</h1>
                <span className="badge badge-info text-[10px]">v2.2</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Deterministic Stage 1 &bull; Sensitive-data / destructive-action rules &bull; {stage2Text.short} &bull; Strict output validation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900/90 border border-white/5">
            {[
              ['chat', MessageSquare, 'Gateway Chat'],
              ['evaluation', BarChart3, 'Evaluation'],
            ].map(([id, Icon, label]) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
                  activeTab === id ? 'bg-emerald-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon size={14} />
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Honest status strip: what is real and what is simulated */}
      <div className="border-b border-amber-500/20 bg-amber-950/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-amber-200/90">
          <span className="flex items-center gap-1.5 font-semibold">
            <FlaskConical size={13} /> {online ? (healthStatus.mode === 'LOCAL_SIMULATION' ? 'LOCAL SIMULATION' : 'LIVE PROVIDER MODE') : 'BACKEND OFFLINE'}
          </span>
          <span className="text-amber-200/70">{stage2Text.long} Replies are mocks. No paid API is called.</span>
          {!online && <span className="text-rose-300">Start the backend (see README), then reload.</span>}
          {warnings.map((w) => (
            <span key={w} className="flex items-center gap-1 text-rose-300">
              <AlertTriangle size={12} /> {w}
            </span>
          ))}
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {activeTab === 'chat' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            <div className="lg:col-span-3">
              <GuardrailControls policyInfo={policyInfo} requested={requested} setRequested={setRequested} healthStatus={healthStatus} />
            </div>
            <div className="lg:col-span-6">
              <ChatWindow
                messages={messages}
                onSendMessage={handleSendMessage}
                isLoading={isLoading}
                onClearMessages={() => {
                  setMessages([]);
                  setLatestResponse(null);
                }}
                presets={presets}
              />
            </div>
            <div className="lg:col-span-3">
              <LogsViewer latestResponse={latestResponse} />
            </div>
          </div>
        ) : (
          <EvaluationDashboard />
        )}
      </main>

      <footer className="border-t border-white/5 bg-slate-950/60 py-4 px-6 text-[11px] text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>LLM Guardrail Gateway &bull; FastAPI + React &bull; runs fully offline in simulation mode</span>
          <span className="font-mono text-slate-400">Policy is owned by the server; the UI can only request stricter settings</span>
        </div>
      </footer>
    </div>
  );
}
