import React from 'react';
import { Activity, Clock, Terminal, FlaskConical } from 'lucide-react';

const segmentsFor = (stage2Label) => [
  ['stage1_local', 'Stage 1', 'bg-emerald-400'],
  ['risk_policy', 'Risk policy', 'bg-rose-400'],
  ['stage2_classifier', stage2Label, 'bg-cyan-400'],
  ['generation', 'Mock generator', 'bg-violet-400'],
  ['output_validation', 'Output guard', 'bg-amber-400'],
  ['overhead', 'Overhead', 'bg-slate-500'],
];

function StageCard({ n, name, badge, tone }) {
  const tones = { ok: 'badge-passed', bad: 'badge-blocked', skip: 'badge-bypassed', warn: 'badge-warning' };
  return (
    <div className="flex flex-col items-center p-2 rounded-lg bg-slate-900/80 border border-white/5">
      <span className="text-[10px] font-bold text-slate-400">{n}</span>
      <span className="text-[11px] font-medium text-slate-200 mt-0.5 text-center leading-tight">{name}</span>
      <span className={`badge mt-1.5 text-[9px] ${tones[tone]}`}>{badge}</span>
    </div>
  );
}

export default function LogsViewer({ latestResponse }) {
  if (!latestResponse) {
    return (
      <div className="glass-panel p-5 h-full flex flex-col items-center justify-center text-center text-slate-400">
        <Activity size={32} className="text-slate-600 mb-2" />
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300">Telemetry idle</h3>
        <p className="text-[11px] text-slate-400 max-w-xs mt-1">Send a request to see the stage path, risk score, timing and the policy that applied.</p>
      </div>
    );
  }

  const { status, security_metadata: m, stage2_executed, latency_ms, retries_attempted, policy, execution_mode } = latestResponse;
  const stage1 = m?.stage1;
  const stage2 = m?.stage2;
  const eff = policy?.effective;
  const isBlocked = status === 'BLOCKED';
  const isError = status === 'ERROR';
  const threshold = eff?.risk_threshold ?? 65;
  const low = eff?.uncertain_low ?? 40;
  const gaugeScore = stage2_executed ? stage2.risk_score : m?.risk_score ?? 0;

  let tone = 'text-emerald-400 border-emerald-500/30 bg-emerald-950/40';
  let gauge = '#10B981';
  let label = 'Below the uncertain band';
  if (gaugeScore > threshold) {
    tone = 'text-rose-400 border-rose-500/30 bg-rose-950/40';
    gauge = '#EF4444';
    label = `Above the block threshold (${threshold})`;
  } else if (gaugeScore >= low) {
    tone = 'text-amber-400 border-amber-500/30 bg-amber-950/40';
    gauge = '#F59E0B';
    label = `Uncertain band (${low}-${threshold})`;
  }
  if (isError) {
    tone = 'text-amber-300 border-amber-500/30 bg-amber-950/30';
    gauge = '#F59E0B';
    label = 'No verdict: processing error';
  }

  const total = latency_ms || 0;
  const breakdown = m?.breakdown_ms || {};
  const stage1Badge = stage1?.route === 'BLOCK' ? ['BLOCKED', 'bad'] : stage1?.route === 'SUSPICIOUS' ? ['SUSPICIOUS', 'warn'] : ['CLEAN', 'ok'];
  const isModel = Boolean(stage2?.model);
  const stage2Name = isModel ? `Model: ${stage2.model.split('/').pop()}` : 'Heuristic simulator';
  const SEGMENTS = segmentsFor(isModel ? 'Stage 2 (model)' : 'Stage 2 (sim)');
  const rp = m?.risk_policy;
  const rpBadge = rp ? (rp.action === 'BLOCK' ? ['BLOCKED', 'bad'] : ['FLAGGED', 'warn']) : stage1?.route === 'BLOCK' ? ['NOT RUN', 'skip'] : ['CLEAR', 'ok'];
  const stage2Badge = !stage2_executed
    ? [
        stage2?.skip_reason === 'STAGE_1_BLOCKED'
          ? 'NOT RUN (S1 BLOCK)'
          : stage2?.skip_reason === 'RISK_POLICY_BLOCKED'
          ? 'NOT RUN (RISK POLICY)'
          : 'NOT RUN (POLICY)',
        'skip',
      ]
    : stage2.status === 'ERROR'
    ? ['ERROR', 'warn']
    : m.stage_triggered === 'STAGE_2_CLASSIFIER'
    ? ['BLOCKED', 'bad']
    : stage2.flagged_uncertain
    ? ['FLAGGED', 'warn']
    : ['SCORED', 'ok'];

  return (
    <div className="glass-panel p-5 flex flex-col gap-5 h-full overflow-y-auto">
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Activity size={18} />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">Telemetry</h2>
            <p className="text-xs text-slate-400">Pipeline trace for the last request</p>
          </div>
        </div>
        <span className={`badge ${isBlocked ? 'badge-blocked' : isError ? 'badge-warning' : 'badge-passed'}`}>{status}</span>
      </div>

      <div className="flex flex-col gap-2">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Decision path</span>
        <div className="grid grid-cols-2 gap-1.5 p-2 rounded-xl bg-slate-950/60 border border-white/5">
          <StageCard n="STAGE 1" name="Deterministic" badge={stage1Badge[0]} tone={stage1Badge[1]} />
          <StageCard n="RULES" name="Sensitive data / destructive action" badge={rpBadge[0]} tone={rpBadge[1]} />
          <StageCard n="STAGE 2" name={stage2Name} badge={stage2Badge[0]} tone={stage2Badge[1]} />
          <StageCard n="GENERATE" name="Mock generator" badge={m?.generation_provider ? 'RAN' : 'NOT RUN'} tone={m?.generation_provider ? 'ok' : 'skip'} />
          <StageCard
            n="OUTPUT"
            name="Schema + leak guard"
            badge={retries_attempted > 0 ? 'RETRIED (1)' : m?.generation_provider ? (isBlocked || isError ? 'REJECTED' : 'VALIDATED') : 'NOT RUN'}
            tone={retries_attempted > 0 ? 'warn' : m?.generation_provider ? (isBlocked || isError ? 'bad' : 'ok') : 'skip'}
          />
        </div>
        <p className="text-[10px] text-slate-500 font-mono">route: {m?.route} &bull; decided by: {m?.stage_triggered}</p>
      </div>

      <div className={`p-4 rounded-xl border flex items-center justify-between ${tone}`}>
        <div className="flex flex-col gap-1">
          <span className="text-[11px] uppercase tracking-wider font-bold opacity-80">
            Risk score {stage2_executed ? (isModel ? '(trained model)' : '(simulated)') : rp ? '(rule layer)' : ''}
          </span>
          <span className="text-xl font-bold font-mono">
            {isError ? 'n/a' : gaugeScore} <span className="text-xs font-normal opacity-70">/ 100</span>
          </span>
          <span className="text-xs font-medium opacity-90">{label}</span>
          {stage2?.confidence && <span className="text-[10px] opacity-80">confidence: {stage2.confidence}</span>}
        </div>
        <div className="w-16 h-16 rounded-full border-4 flex items-center justify-center font-mono font-bold text-base" style={{ borderColor: gauge }}>
          {isError ? '!' : gaugeScore}
        </div>
      </div>

      {rp && (
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Why the rule layer reacted</span>
          <div className="code-box text-[11px] space-y-1">
            <div className="text-slate-400">category: <span className="text-slate-200">{rp.category}</span></div>
            <div className="text-slate-400">rule: <span className="text-slate-200">{rp.rule}</span></div>
            <div className="text-slate-400">matched: <span className="text-slate-200">{rp.evidence}</span></div>
          </div>
        </div>
      )}

      {stage2?.features?.length > 0 && (
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            {isModel ? 'Evidence the model produced' : 'Evidence the simulator used'}
          </span>
          <div className="flex flex-wrap gap-1.5">
            {stage2.features.map((f) => (
              <span key={f} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800/80 border border-white/5 text-slate-300">
                {f}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-col gap-2.5">
        <div className="flex justify-between items-center text-xs">
          <span className="font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Clock size={13} className="text-cyan-400" /> Timing
          </span>
          <span className="font-mono font-bold text-slate-200">{latency_ms} ms total</span>
        </div>
        <div className="h-2 rounded-full bg-slate-800 flex overflow-hidden">
          {SEGMENTS.map(([key, name, color]) => (
            <div key={key} title={`${name}: ${breakdown[key] ?? 0} ms`} style={{ width: `${total > 0 ? ((breakdown[key] || 0) / total) * 100 : 0}%` }} className={`${color} h-full`} />
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
          {SEGMENTS.map(([key, name, color]) => (
            <div key={key} className="p-2 rounded-lg bg-slate-900/60 border border-white/5 flex justify-between items-center">
              <span className="text-slate-400 flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${color}`} /> {name}
              </span>
              <span className="text-slate-200 font-semibold">{breakdown[key] ?? 0}</span>
            </div>
          ))}
        </div>
        <p className="text-[10px] text-slate-500 flex items-start gap-1">
          <FlaskConical size={11} className="shrink-0 mt-0.5" /> {m?.timing_note}
        </p>
      </div>

      {policy && (
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Policy applied</span>
          <div className="code-box text-[11px] space-y-1">
            <div className="text-slate-400">source: <span className="text-slate-200">{policy.source}</span></div>
            <div className="text-slate-400">threshold: <span className="text-slate-200">&gt; {eff.risk_threshold}</span> &bull; uncertain from {eff.uncertain_low} ({eff.uncertain_action})</div>
            {policy.applied.map((a) => <div key={a} className="text-emerald-300">applied: {a}</div>)}
            {policy.rejected.map((r) => <div key={r} className="text-amber-300">refused: {r}</div>)}
            {policy.warnings.map((w) => <div key={w} className="text-rose-300">warning: {w}</div>)}
          </div>
        </div>
      )}

      <div className="flex flex-col gap-2 mt-auto">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
          <Terminal size={12} /> Audit event
        </span>
        <div className="code-box text-[11px] space-y-1">
          <div className="text-slate-400">action: <span className={isBlocked ? 'text-rose-400 font-bold' : isError ? 'text-amber-300 font-bold' : 'text-emerald-400 font-bold'}>{m?.action}</span></div>
          <div className="text-slate-400">stage 2: {stage2_executed ? `executed by ${stage2?.provider}` : `not executed (${stage2?.skip_reason})`}</div>
          <div className="text-slate-400">mode: {execution_mode} &bull; retries: {retries_attempted} (max 1)</div>
          {m?.reasoning && <div className="text-slate-300 text-[10px] mt-1 p-1.5 bg-black/40 rounded border border-white/5 break-words">{m.reasoning}</div>}
        </div>
      </div>
    </div>
  );
}
