import React, { useEffect, useState } from 'react';
import { Play, Target, AlertTriangle, Info, Database, Search } from 'lucide-react';
import { runEvaluationBenchmark, fetchDatasets } from '../api';
import MyPrompts from './MyPrompts';

const pct = (v) => (v === null || v === undefined ? 'n/a' : `${v.toFixed(2)}%`);
const OUTCOME_TONE = { TP: 'text-emerald-300', TN: 'text-emerald-300', FP: 'text-rose-300', FN: 'text-rose-300', ERROR: 'text-amber-300', REVIEW: 'text-slate-300' };

function Metric({ label, value, hint, tone = 'text-slate-100' }) {
  return (
    <div className="glass-panel p-4 flex flex-col gap-1">
      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">{label}</span>
      <span className={`text-2xl font-bold font-mono ${tone}`}>{value}</span>
      <span className="text-[10px] text-slate-400">{hint}</span>
    </div>
  );
}

export default function EvaluationDashboard() {
  const [datasets, setDatasets] = useState([]);
  const [dataset, setDataset] = useState('dev');
  const [strict, setStrict] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('');
  const [listVersion, setListVersion] = useState(0); // bumps when your prompt list changes or a run finishes

  const loadDatasets = () => fetchDatasets().then(setDatasets).catch(() => setDatasets([]));
  useEffect(() => {
    loadDatasets();
  }, []);

  const run = async () => {
    setIsRunning(true);
    setError(null);
    try {
      setReport(await runEvaluationBenchmark(dataset, strict));
    } catch (err) {
      setError(err.message || 'Evaluation failed. Is the backend running?');
    } finally {
      setIsRunning(false);
      setListVersion((v) => v + 1);
      loadDatasets(); // case counts of "user" and "combined" change as you add prompts
    }
  };

  const chosen = datasets.find((d) => d.name === dataset);
  const rows = (report?.sample_results || []).filter(
    (r) => r.id.toLowerCase().includes(filter.toLowerCase()) || r.category.toLowerCase().includes(filter.toLowerCase())
  );
  const m = report?.metrics;
  const cm = report?.confusion_matrix;

  return (
    <div className="flex flex-col gap-6">
      <div className="glass-panel p-6 flex flex-col gap-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Target size={20} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-100 uppercase tracking-wide">Evaluation</h1>
              <p className="text-xs text-slate-400 max-w-2xl">
                Runs a labelled dataset through the same decision function the chat endpoint uses. Results measure whichever Stage 2 backend the server runs
                (shown below the metrics) on that dataset only.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <select
              value={dataset}
              onChange={(e) => setDataset(e.target.value)}
              disabled={isRunning}
              className="glass-input text-xs px-3 py-2.5 cursor-pointer bg-slate-900 text-slate-200"
            >
              {(datasets.length ? datasets : [{ name: 'dev', cases: 0 }]).map((d) => (
                <option key={d.name} value={d.name}>
                  {d.name === 'combined' ? 'combined: built-in tests + my prompts' : d.name === 'user' ? 'user: my prompts only' : d.name}{' '}
                  {d.cases !== undefined ? `(${d.cases} cases)` : ''}
                </option>
              ))}
            </select>
            <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer" title="Block the uncertain band instead of flagging it">
              <input type="checkbox" checked={strict} onChange={(e) => setStrict(e.target.checked)} disabled={isRunning} /> strict
            </label>
            <button
              onClick={run}
              disabled={isRunning}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {isRunning ? <div className="w-3.5 h-3.5 rounded-full border-2 border-black border-t-transparent animate-spin" /> : <Play size={14} />}
              <span>{isRunning ? 'Running...' : 'Run evaluation'}</span>
            </button>
          </div>
        </div>
        {chosen?.warnings?.map((w) => (
          <p key={w} className="text-[11px] text-amber-300/90 flex items-start gap-1.5">
            <Info size={12} className="shrink-0 mt-0.5" /> {w}
          </p>
        ))}
      </div>

      <MyPrompts refreshKey={listVersion} onChanged={loadDatasets} />

      {error && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
          <AlertTriangle size={16} /> {error}
        </div>
      )}

      {report && (
        <>
          <div className="glass-panel p-4 flex flex-wrap items-center gap-x-6 gap-y-1 text-[11px] font-mono text-slate-300">
            <span className="flex items-center gap-1.5"><Database size={12} className="text-cyan-400" /> {report.dataset.name} ({report.dataset.split})</span>
            <span>{report.dataset.case_count} cases: {report.dataset.attack_count} attack / {report.dataset.benign_count} benign / {report.dataset.ambiguous_count} ambiguous</span>
            <span title={report.dataset.sha256}>sha256 {report.dataset.sha256.slice(0, 12)}...{report.dataset.hash_verified === true ? ' (verified)' : ''}</span>
            {report.dataset.seed !== null && <span>seed {report.dataset.seed}</span>}
            <span>policy v{report.policy_version} &bull; Stage 2: {report.stage2_provider || 'LOCAL_HEURISTIC_SIMULATOR'}</span>
            <span>{report.operating_point}</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <Metric label="Accuracy" value={pct(m.accuracy)} hint="correct decisions / decided cases" tone="text-emerald-400" />
            <Metric label="Precision" value={pct(m.precision)} hint="of blocks, how many were attacks" tone="text-cyan-400" />
            <Metric label="Recall" value={pct(m.recall)} hint="of attacks, how many were blocked" tone="text-teal-400" />
            <Metric label="False-positive rate" value={pct(m.false_positive_rate)} hint="benign prompts wrongly blocked" tone="text-amber-400" />
            <Metric label="F1" value={pct(m.f1)} hint="n/a when undefined" tone="text-violet-400" />
          </div>
          {report.strict_operating_point_metrics && (
            <p className="text-[11px] text-slate-400">
              If the uncertain band were blocked (strict): precision {pct(report.strict_operating_point_metrics.precision)}, recall{' '}
              {pct(report.strict_operating_point_metrics.recall)}, false-positive rate {pct(report.strict_operating_point_metrics.false_positive_rate)}.
            </p>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="glass-panel p-4 flex flex-col gap-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Confusion matrix</h3>
              <div className="grid grid-cols-2 gap-2 text-center">
                {[['TP', cm.tp, 'attack blocked'], ['FP', cm.fp, 'benign blocked'], ['FN', cm.fn, 'attack passed'], ['TN', cm.tn, 'benign passed']].map(([k, v, t]) => (
                  <div key={k} className="p-3 rounded-lg bg-slate-900/60 border border-white/5">
                    <div className={`text-xl font-mono font-bold ${OUTCOME_TONE[k]}`}>{v}</div>
                    <div className="text-[10px] text-slate-400">{k} &bull; {t}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-panel p-4 flex flex-col gap-2 text-xs">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Where decisions were made</h3>
              {[
                ['Stage 1 blocks', report.routes.stage1_blocks],
                ['Stage 2 blocks', report.routes.stage2_blocks],
                ['Passed after Stage 2', report.routes.passed_stage2_clear],
                ['Passed but flagged uncertain', report.routes.passed_flagged_uncertain],
                ['Blocked: escalation unavailable', report.routes.escalation_unavailable_blocks],
                ['Blocked: classifier error (fail closed)', report.routes.stage2_error_blocks],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between font-mono text-slate-300"><span className="text-slate-400">{k}</span><span>{v}</span></div>
              ))}
            </div>

            <div className="glass-panel p-4 flex flex-col gap-2 text-xs">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Reliability and cost</h3>
              <div className="flex justify-between font-mono text-slate-300"><span className="text-slate-400">Decided cases</span><span>{report.reliability.evaluated_cases}</span></div>
              <div className="flex justify-between font-mono text-slate-300">
                <span className="text-slate-400">Errors (excluded from metrics)</span>
                <span className={report.reliability.error_cases ? 'text-amber-300' : ''}>{report.reliability.error_cases} ({pct(report.reliability.error_rate_percent)})</span>
              </div>
              <div className="flex justify-between font-mono text-slate-300"><span className="text-slate-400">Avg / p95 time</span><span>{report.latency.avg_ms} / {report.latency.p95_ms} ms</span></div>
              <p className="text-[10px] text-slate-500">{report.latency.note}</p>
              <div className="flex justify-between font-mono text-slate-300"><span className="text-slate-400">Cost reduction</span><span>N/A</span></div>
              <p className="text-[10px] text-slate-500">{report.cost.note}</p>
            </div>
          </div>

          <div className="glass-panel p-4 overflow-x-auto">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">By category</h3>
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="text-left text-slate-400 border-b border-white/10">
                  <th className="py-1.5 pr-3">Category</th><th className="pr-3">Role</th><th className="pr-3">Total</th><th className="pr-3">Blocked</th>
                  <th className="pr-3">Passed</th><th className="pr-3">Flagged</th><th className="pr-3">Err</th><th>Rate</th>
                </tr>
              </thead>
              <tbody>
                {report.categories.map((c) => (
                  <tr key={c.category} className="border-b border-white/5 text-slate-300">
                    <td className="py-1.5 pr-3">{c.category}</td><td className="pr-3 text-slate-400">{c.role}</td><td className="pr-3">{c.total}</td>
                    <td className="pr-3">{c.blocked}</td><td className="pr-3">{c.passed}</td><td className="pr-3">{c.flagged_uncertain}</td><td className="pr-3">{c.errors}</td>
                    <td className={c.role === 'attack' ? (c.rate_percent < 80 ? 'text-amber-300' : 'text-emerald-300') : c.role === 'benign' && c.rate_percent > 0 ? 'text-rose-300' : ''}>
                      {pct(c.rate_percent)} <span className="text-slate-500">{c.rate_label}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {report.ambiguous_summary && (
              <p className="text-[11px] text-slate-400 mt-2">
                Ambiguous (dual-use) prompts, excluded from the metrics above: {report.ambiguous_summary.blocked} blocked, {report.ambiguous_summary.passed_flagged} passed and
                flagged, {report.ambiguous_summary.passed_unflagged} passed unflagged.
              </p>
            )}
          </div>

          <div className="glass-panel p-4 flex flex-col gap-3">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Cases (stratified sample; every miss and false positive is included)
              </h3>
              <div className="relative">
                <Search size={12} className="absolute left-2.5 top-2.5 text-slate-500" />
                <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="filter by id or category" className="glass-input text-xs pl-7 pr-3 py-1.5" />
              </div>
            </div>
            <div className="overflow-x-auto max-h-96 overflow-y-auto">
              <table className="w-full text-xs font-mono">
                <thead className="sticky top-0 bg-slate-950">
                  <tr className="text-left text-slate-400 border-b border-white/10">
                    <th className="py-1.5 pr-3">ID</th><th className="pr-3">Category</th><th className="pr-3">Expected</th><th className="pr-3">Actual</th>
                    <th className="pr-3">Outcome</th><th className="pr-3">Route</th><th className="pr-3">Risk</th><th>Prompt</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id} className="border-b border-white/5 text-slate-300 align-top">
                      <td className="py-1.5 pr-3 whitespace-nowrap">{r.id}</td><td className="pr-3">{r.category}</td><td className="pr-3">{r.expected}</td>
                      <td className="pr-3">{r.actual}{r.flagged_uncertain ? ' (flagged)' : ''}</td>
                      <td className={`pr-3 font-bold ${OUTCOME_TONE[r.outcome]}`}>{r.outcome}</td><td className="pr-3 text-slate-400">{r.route}</td>
                      <td className="pr-3">{r.risk_score ?? '-'}</td>
                      <td className="max-w-md break-words text-slate-400">{r.prompt ?? <span className="text-slate-600">hidden (frozen holdout)</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="glass-panel p-4 text-[11px] text-slate-400 flex flex-col gap-1">
            {[...report.notes, ...report.dataset.warnings].map((n) => (
              <p key={n} className="flex items-start gap-1.5"><Info size={12} className="shrink-0 mt-0.5 text-slate-500" /> {n}</p>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
