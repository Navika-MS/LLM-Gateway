import React, { useCallback, useEffect, useState } from 'react';
import { Bookmark, Trash2, Info } from 'lucide-react';
import { fetchUserPrompts, labelUserPrompt, deleteUserPrompt } from '../api';

const VERDICT_TONE = { SUCCESS: 'text-emerald-300', BLOCKED: 'text-rose-300', ERROR: 'text-amber-300' };

/**
 * Every prompt typed in the chat is saved by the server. Here you can mark what the CORRECT outcome is
 * (the gateway's own verdict is not a label), delete entries, and then run the `user` or `combined` dataset.
 */
export default function MyPrompts({ refreshKey, onChanged }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [open, setOpen] = useState(true);

  const load = useCallback(async () => {
    try {
      setData(await fetchUserPrompts());
      setError(null);
    } catch (err) {
      setError(err.message || 'Could not load your prompts');
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  const change = async (action) => {
    try {
      await action();
      await load();
      onChanged?.();
    } catch (err) {
      setError(err.message || 'Update failed');
    }
  };

  const counts = data?.counts;
  return (
    <div className="glass-panel p-5 flex flex-col gap-3">
      <button onClick={() => setOpen((o) => !o)} className="flex items-center justify-between text-left">
        <span className="flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-slate-100">
          <Bookmark size={16} className="text-cyan-400" /> My test prompts
          {counts && (
            <span className="text-[11px] font-mono font-normal normal-case text-slate-400">
              {counts.total} saved &bull; {counts.attack} should block &bull; {counts.benign} should allow &bull; {counts.unlabelled} unlabelled
            </span>
          )}
        </span>
        <span className="text-[11px] text-slate-400">{open ? 'hide' : 'show'}</span>
      </button>

      {open && (
        <>
          <p className="text-[11px] text-slate-400 flex items-start gap-1.5">
            <Info size={12} className="shrink-0 mt-0.5" />
            Each prompt you send in the chat is saved here automatically. Mark the outcome you EXPECT; only labelled prompts are scored (the
            gateway&apos;s own answer is not a label). Run them with dataset <b>user</b>, or together with the built-in test sets with <b>combined</b>.
            Prompts containing card numbers, emails, SSNs or keys are never saved.
          </p>
          {error && <p className="text-[11px] text-rose-300">{error}</p>}
          {data && !data.enabled && (
            <p className="text-[11px] text-amber-300">
              Saving is off because the server is bound to a network address. Set HOST=127.0.0.1 in backend/.env (or GATEWAY_RECORD_PROMPTS=on) and restart.
            </p>
          )}
          {data?.enabled && data.items.length === 0 && <p className="text-xs text-slate-400">Nothing saved yet. Send a prompt in the Gateway Chat tab.</p>}
          {data?.enabled && data.items.length > 0 && (
            <div className="overflow-x-auto max-h-72 overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="text-left text-slate-400">
                  <tr>
                    <th className="py-1 pr-3 font-semibold">id</th>
                    <th className="py-1 pr-3 font-semibold">prompt</th>
                    <th className="py-1 pr-3 font-semibold">last verdict</th>
                    <th className="py-1 pr-3 font-semibold">seen</th>
                    <th className="py-1 pr-3 font-semibold">correct outcome</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {[...data.items].reverse().map((item) => (
                    <tr key={item.id} className="border-t border-white/5 align-top">
                      <td className="py-1.5 pr-3 font-mono text-slate-300 whitespace-nowrap">{item.id}</td>
                      <td className="py-1.5 pr-3 text-slate-200 max-w-md break-words" title={item.prompt}>
                        {item.prompt.length > 140 ? `${item.prompt.slice(0, 140)}...` : item.prompt}
                      </td>
                      <td className={`py-1.5 pr-3 font-mono whitespace-nowrap ${VERDICT_TONE[item.last?.status] || 'text-slate-300'}`}>
                        {item.last?.status || '-'} <span className="text-slate-500">{item.last?.risk ?? ''}</span>
                      </td>
                      <td className="py-1.5 pr-3 font-mono text-slate-400">{item.times_seen}</td>
                      <td className="py-1.5 pr-3">
                        <select
                          value={item.label || ''}
                          onChange={(e) => change(() => labelUserPrompt(item.id, e.target.value || null))}
                          className="glass-input text-[11px] px-2 py-1 bg-slate-900 text-slate-200 cursor-pointer"
                        >
                          <option value="">unlabelled</option>
                          <option value="attack">should be blocked</option>
                          <option value="benign">should be allowed</option>
                        </select>
                      </td>
                      <td className="py-1.5">
                        <button
                          onClick={() => change(() => deleteUserPrompt(item.id))}
                          title="Remove from my list"
                          className="p-1 rounded text-slate-400 hover:text-rose-300 hover:bg-rose-950/40"
                        >
                          <Trash2 size={13} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
