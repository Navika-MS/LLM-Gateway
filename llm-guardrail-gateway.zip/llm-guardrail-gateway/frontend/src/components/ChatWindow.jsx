import React, { useState } from 'react';
import {
  Send,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Code2,
  RefreshCw,
  Zap,
  User,
  Bot,
  Copy,
  Check,
  FlaskConical,
  Bookmark,
} from 'lucide-react';
import { labelUserPrompt } from '../api';

function presetColor(category) {
  if (category.includes('JAILBREAK') || category.includes('PII') || category.includes('OVERRIDE') || category.includes('ENCODED')) {
    return 'bg-rose-950/40 text-rose-300 hover:bg-rose-900/50 border-rose-500/20';
  }
  if (category.includes('AMBIGUOUS') || category.includes('INDIRECT')) {
    return 'bg-amber-950/40 text-amber-300 hover:bg-amber-900/50 border-amber-500/20';
  }
  return 'bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900/50 border-emerald-500/20';
}

export default function ChatWindow({ messages, onSendMessage, isLoading, onClearMessages, presets }) {
  const [promptInput, setPromptInput] = useState('');
  const [copiedId, setCopiedId] = useState(null);
  const [labels, setLabels] = useState({}); // saved-prompt id -> 'attack' | 'benign' (what YOU say the correct outcome is)
  const [labelError, setLabelError] = useState(null);

  // Clicking the active choice again clears it. The server is the source of truth; roll back if it refuses.
  const chooseLabel = async (id, choice) => {
    const next = labels[id] === choice ? null : choice;
    const before = labels[id] ?? null;
    setLabels((prev) => ({ ...prev, [id]: next }));
    setLabelError(null);
    try {
      await labelUserPrompt(id, next);
    } catch (err) {
      setLabels((prev) => ({ ...prev, [id]: before }));
      setLabelError(err.message || 'Could not save the label');
    }
  };

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (!promptInput.trim() || isLoading) return;
    onSendMessage(promptInput);
    setPromptInput('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const copyToClipboard = (text, id) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="glass-panel flex flex-col h-[740px] overflow-hidden">
      <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Bot size={18} />
          </div>
          <div>
            <h2 className="text-sm font-bold tracking-wide text-slate-100">Protected Channel</h2>
            <p className="text-xs text-slate-400">Every prompt is inspected before a (mock) response is produced</p>
          </div>
        </div>
        <button
          onClick={onClearMessages}
          title="Clear conversation"
          className="text-xs text-slate-400 hover:text-slate-200 px-3 py-1.5 rounded-lg bg-slate-800/40 hover:bg-slate-800 border border-white/5 transition-colors flex items-center gap-1.5"
        >
          <RefreshCw size={12} />
          <span>Clear</span>
        </button>
      </div>

      <div className="px-5 py-2.5 bg-slate-900/60 border-b border-white/5 flex items-center gap-2 overflow-x-auto">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1 shrink-0">
          <Zap size={12} className="text-amber-400" /> Try:
        </span>
        {presets.length === 0 && <span className="text-[11px] text-slate-500">Presets load from the backend.</span>}
        {presets.map((preset) => (
          <button
            key={preset.label}
            onClick={() => setPromptInput(preset.prompt)}
            title={preset.description}
            className={`text-xs px-2.5 py-1 rounded-full border whitespace-nowrap transition-all shrink-0 ${presetColor(preset.category)}`}
          >
            {preset.label}
          </button>
        ))}
      </div>

      <div className="flex-1 p-5 overflow-y-auto flex flex-col gap-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
            <div className="w-14 h-14 rounded-2xl bg-slate-800/40 border border-white/10 flex items-center justify-center mb-3 text-cyan-400">
              <ShieldCheck size={28} />
            </div>
            <h3 className="text-sm font-semibold text-slate-200">Ready for inspection</h3>
            <p className="text-xs text-slate-400 max-w-md mt-1">
              Send a prompt or pick a preset. Stage 1 checks run first, then the sensitive-data / destructive-action rules, then Stage 2 scores
              whatever is left. Allowed prompts get a clearly labelled mock reply, which is validated and scanned before it is returned. Every prompt
              you send is saved to your test list so you can evaluate it later.
            </p>
          </div>
        ) : (
          messages.map((msg, index) => {
            const isUser = msg.role === 'user';
            const isBlocked = msg.status === 'BLOCKED';
            const isError = msg.status === 'ERROR';
            const isSuccess = msg.status === 'SUCCESS';
            const flagged = msg.security_metadata?.stage2?.flagged_uncertain;
            const rejected = msg.policy?.rejected || [];

            return (
              <div key={index} className={`flex flex-col gap-1.5 ${isUser ? 'items-end' : 'items-start'}`}>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 px-1">
                  {isUser ? (
                    <>
                      <span>You</span>
                      <User size={13} className="text-slate-300" />
                    </>
                  ) : (
                    <>
                      <Bot size={13} className={isBlocked ? 'text-rose-400' : isError ? 'text-amber-400' : 'text-emerald-400'} />
                      <span className="font-semibold text-slate-200">Gateway</span>
                      {isBlocked && (
                        <span className="badge badge-blocked">
                          <ShieldAlert size={11} /> BLOCKED
                        </span>
                      )}
                      {isSuccess && (
                        <span className="badge badge-passed">
                          <CheckCircle2 size={11} /> PASSED
                        </span>
                      )}
                      {isError && (
                        <span className="badge badge-warning">
                          <XCircle size={11} /> ERROR (not a verdict)
                        </span>
                      )}
                      {flagged && (
                        <span className="badge badge-warning" title="The simulator was uncertain. The prompt was allowed but flagged.">
                          <AlertTriangle size={11} /> UNCERTAIN: FLAGGED
                        </span>
                      )}
                      {msg.retries_attempted > 0 && (
                        <span className="badge badge-warning">
                          <RefreshCw size={11} /> Retried ({msg.retries_attempted})
                        </span>
                      )}
                      {typeof msg.latency_ms === 'number' && (
                        <span className="text-[11px] font-mono text-slate-400" title="Local simulator processing time, not LLM latency">
                          {msg.latency_ms} ms
                        </span>
                      )}
                    </>
                  )}
                </div>

                <div
                  className={`max-w-[85%] rounded-2xl p-4 text-sm ${
                    isUser
                      ? 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-lg'
                      : isBlocked
                      ? 'bg-rose-950/40 border border-rose-500/40 text-rose-100 shadow-lg'
                      : isError
                      ? 'bg-amber-950/30 border border-amber-500/40 text-amber-100 shadow-lg'
                      : 'bg-slate-900/80 border border-white/10 text-slate-100 shadow-md'
                  }`}
                >
                  {isUser ? (
                    <div className="whitespace-pre-wrap break-words">{msg.content}</div>
                  ) : isBlocked || isError ? (
                    <div className="flex flex-col gap-2.5">
                      <div className={`flex items-start gap-2.5 ${isBlocked ? 'text-rose-400' : 'text-amber-300'}`}>
                        {isBlocked ? <ShieldAlert size={18} className="shrink-0 mt-0.5" /> : <XCircle size={18} className="shrink-0 mt-0.5" />}
                        <div>
                          <strong className="block font-semibold text-xs uppercase tracking-wide">
                            {isBlocked ? 'Blocked by policy' : 'Request could not be processed'}
                          </strong>
                          <p className="text-xs mt-0.5 font-mono break-words">
                            {msg.block_reason || msg.security_metadata?.reasoning || 'See the telemetry panel for details.'}
                          </p>
                          {isError && msg.error_code && <p className="text-[11px] mt-1 font-mono opacity-80">code: {msg.error_code}</p>}
                        </div>
                      </div>
                      {msg.security_metadata && (
                        <div className="p-2.5 rounded-lg bg-black/40 border border-white/10 text-[11px] font-mono flex flex-col gap-1">
                          <div className="flex justify-between text-slate-300">
                            <span>Decided by:</span>
                            <span className="font-bold">{msg.security_metadata.stage_triggered}</span>
                          </div>
                          {isBlocked && (
                            <div className="flex justify-between text-slate-300">
                              <span>Risk score:</span>
                              <span className="font-bold">{msg.security_metadata.risk_score}/100</span>
                            </div>
                          )}
                          <div className="flex justify-between text-slate-300">
                            <span>Stage 2:</span>
                            <span className="font-bold">
                              {msg.stage2_executed ? 'executed' : `not executed (${(msg.security_metadata.stage2?.skip_reason || 'n/a').toLowerCase()})`}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="flex flex-col gap-3">
                      {msg.output && typeof msg.output === 'object' && msg.output.summary ? (
                        <div className="flex flex-col gap-2.5">
                          <div>
                            <span className="text-[10px] font-bold tracking-wider uppercase text-cyan-400 flex items-center gap-1 mb-1">
                              <FlaskConical size={11} /> Simulated reply
                            </span>
                            <p className="text-slate-200 leading-relaxed">{msg.output.summary}</p>
                          </div>
                          <div className="flex items-center gap-2 pt-1 border-t border-white/5">
                            <span className="text-[10px] uppercase font-bold text-slate-400">Content sensitivity:</span>
                            <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono font-bold border border-cyan-500/30">
                              {msg.output.risk_score} / 10
                            </span>
                          </div>
                          {Array.isArray(msg.output.key_points) && msg.output.key_points.length > 0 && (
                            <div className="pt-2 border-t border-white/5">
                              <span className="text-[10px] font-bold tracking-wider uppercase text-slate-400 block mb-1.5">What the gateway established</span>
                              <ul className="space-y-1.5 pl-1">
                                {msg.output.key_points.map((point, pIdx) => (
                                  <li key={pIdx} className="text-xs text-slate-300 flex items-start gap-2">
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                                    <span>{point}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="whitespace-pre-wrap break-words">
                          {typeof msg.output === 'string' ? msg.output : JSON.stringify(msg.output, null, 2)}
                        </div>
                      )}

                      {msg.output && (
                        <details className="mt-1 pt-2 border-t border-white/5 text-xs">
                          <summary className="cursor-pointer text-slate-400 hover:text-slate-200 flex items-center gap-1.5 select-none">
                            <Code2 size={12} /> <span>View validated JSON</span>
                          </summary>
                          <div className="mt-2 relative">
                            <pre className="code-box text-[11px] overflow-x-auto max-h-48">{JSON.stringify(msg.output, null, 2)}</pre>
                            <button
                              onClick={() => copyToClipboard(JSON.stringify(msg.output, null, 2), index)}
                              className="absolute top-2 right-2 p-1 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300"
                              title="Copy JSON"
                            >
                              {copiedId === index ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                            </button>
                          </div>
                        </details>
                      )}
                    </div>
                  )}
                </div>

                {!isUser && rejected.length > 0 && (
                  <div className="max-w-[85%] text-[11px] text-amber-300/90 px-1">
                    The server ignored {rejected.length} request{rejected.length > 1 ? 's' : ''} to weaken the policy: {rejected.join('; ')}
                  </div>
                )}

                {!isUser && msg.recorded_prompt_id && (
                  <div className="max-w-[85%] flex flex-wrap items-center gap-x-2 gap-y-1 px-1 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1" title="Saved automatically to your test list; the Evaluation tab can run it (dataset: user or combined).">
                      <Bookmark size={11} className="text-cyan-400" /> saved as {msg.recorded_prompt_id}. Correct outcome:
                    </span>
                    {[['attack', 'should be blocked'], ['benign', 'should be allowed']].map(([value, text]) => (
                      <button
                        key={value}
                        onClick={() => chooseLabel(msg.recorded_prompt_id, value)}
                        className={`px-2 py-0.5 rounded-full border transition-colors ${
                          labels[msg.recorded_prompt_id] === value
                            ? value === 'attack'
                              ? 'bg-rose-500/20 border-rose-400/60 text-rose-200'
                              : 'bg-emerald-500/20 border-emerald-400/60 text-emerald-200'
                            : 'border-white/10 hover:border-white/30 text-slate-300'
                        }`}
                      >
                        {text}
                      </button>
                    ))}
                    {!labels[msg.recorded_prompt_id] && <span className="text-slate-500">(unlabelled prompts are listed but not scored)</span>}
                  </div>
                )}
              </div>
            );
          })
        )}

        {isLoading && (
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/60 border border-white/10 text-slate-300 w-fit">
            <div className="w-4 h-4 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
            <span className="text-xs font-mono">Running the pipeline...</span>
          </div>
        )}
      </div>

      {labelError && <div className="px-5 py-1.5 text-[11px] text-rose-300 bg-rose-950/30 border-t border-rose-500/20">{labelError}</div>}
      <form onSubmit={handleSubmit} className="p-4 bg-slate-950/60 border-t border-white/10 flex gap-3">
        <textarea
          rows={2}
          maxLength={8000}
          value={promptInput}
          onChange={(e) => setPromptInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a prompt to inspect (Enter to send, Shift+Enter for a new line)..."
          className="glass-input flex-1 p-3 text-xs resize-none"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !promptInput.trim()}
          className="px-5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition-all"
        >
          {isLoading ? (
            <div className="w-4 h-4 rounded-full border-2 border-black border-t-transparent animate-spin" />
          ) : (
            <>
              <span>Send</span>
              <Send size={14} />
            </>
          )}
        </button>
      </form>
    </div>
  );
}
