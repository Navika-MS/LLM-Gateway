import React from 'react';
import { Shield, Cpu, Sliders, RefreshCw, FileCode, Lock, Unlock } from 'lucide-react';

const CONTROLS = {
  stage1: [
    ['pii_check', 'PII & secret detection', 'Emails, phone numbers, SSNs, Luhn-valid cards, API keys. Documented test data is ignored.'],
    ['injection_check', 'Jailbreak signatures', 'Normalised matching: zero-width, fullwidth, leetspeak, spacing, reversal, base64/hex.'],
  ],
  output: [
    ['schema_enforcement', 'Strict schema validation', 'Real JSON validation of the generated output, with at most one retry.'],
    ['output_pii_check', 'Output data-leak guard', 'Scans generated text for PII and credentials before it is returned.'],
  ],
};

function Toggle({ field, label, hint, server, requested, setRequested, locked }) {
  // A client may turn a control ON (stricter). It may only turn one OFF if the operator enabled the demo override.
  const serverOn = server?.[field] === true;
  const disabled = locked && serverOn;
  return (
    <label className={`switch-container ${disabled ? 'opacity-80 cursor-not-allowed' : 'cursor-pointer'}`} title={disabled ? 'Enforced by the server' : ''}>
      <div className="flex flex-col gap-0.5">
        <span className="text-xs font-medium text-slate-200 flex items-center gap-1.5">
          {label}
          {disabled && <Lock size={11} className="text-amber-400" />}
        </span>
        <span className="text-[11px] text-slate-400">{hint}</span>
      </div>
      <input
        type="checkbox"
        className="switch-input"
        checked={disabled ? true : !!requested?.[field]}
        disabled={disabled || !requested}
        onChange={() => setRequested((prev) => ({ ...prev, [field]: !prev[field] }))}
      />
    </label>
  );
}

export default function GuardrailControls({ policyInfo, requested, setRequested, healthStatus }) {
  const server = policyInfo?.server_policy;
  const locked = policyInfo ? !policyInfo.client_override_allowed : true;
  const serverThreshold = server?.risk_threshold ?? 65;
  const maxThreshold = locked ? serverThreshold : 100;
  const threshold = requested?.risk_threshold ?? serverThreshold;
  const uncertainLow = Math.min(server?.uncertain_low ?? 40, threshold - 1);

  const props = { server, requested, setRequested, locked };

  // What Stage 2 really is comes from the server's /health, never from a hard-coded guess.
  const s2 = healthStatus?.stage2;
  const members = s2?.members || (s2 ? [s2] : []);
  const model = members.find((m) => m.model);
  const stage2Title = model ? 'Stage 2: Trained Model' : 'Stage 2: Simulated Classifier';
  const stage2Label = model ? `Stage 2 ${model.model.split('/').pop()}` : 'Stage 2 heuristic simulator';
  const stage2Hint = model
    ? `Runs locally (${model.runtime}${members.length > 1 ? ' + rule-based scorer, highest risk wins' : ''}). ${model.ready ? 'Loaded.' : model.error ? 'NOT LOADED: ' + model.error : 'Loading...'}`
    : 'Runs on every prompt Stage 1 did not block. Deterministic rules, not an LLM.';
  const enforced = server
    ? ['pii_check', 'injection_check', 'ai_classifier_check', 'schema_enforcement', 'output_pii_check'].filter((k) => server[k]).length
    : 0;

  return (
    <div className="glass-panel p-5 flex flex-col gap-5">
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Sliders size={18} />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">Policy</h2>
            <p className="text-xs text-slate-400 flex items-center gap-1">
              {locked ? <Lock size={11} className="text-amber-400" /> : <Unlock size={11} className="text-rose-400" />}
              {locked ? 'Server-enforced: you can only tighten' : 'DEMO OVERRIDE ON: controls can be weakened'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="badge badge-passed text-[11px]">{enforced}/5 enforced</span>
          <button
            onClick={() => server && setRequested({ ...server })}
            title="Reset to the server policy"
            className="p-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <RefreshCw size={13} />
          </button>
        </div>
      </div>

      {!policyInfo && <p className="text-xs text-rose-300">Could not load the server policy. Is the backend running?</p>}

      <div className="flex flex-col gap-2.5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400/90">
          <Shield size={14} /> <span>Stage 1: Deterministic</span>
        </div>
        {CONTROLS.stage1.map(([f, l, h]) => (
          <Toggle key={f} field={f} label={l} hint={h} {...props} />
        ))}
      </div>

      <div className="flex flex-col gap-2.5 pt-2 border-t border-white/5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-cyan-400/90">
          <Cpu size={14} /> <span>{stage2Title}</span>
        </div>
        <Toggle field="ai_classifier_check" label={stage2Label} hint={stage2Hint} {...props} />
        {server && (
          <p className="text-[11px] text-slate-400" title="Server-owned; clients cannot change these (GATEWAY_SENSITIVE_DATA_POLICY / GATEWAY_DESTRUCTIVE_ACTION_POLICY)">
            Sensitive-data rules: <b className="text-slate-200">{server.sensitive_data_policy}</b> &bull; Destructive-action rules:{' '}
            <b className="text-slate-200">{server.destructive_action_policy}</b>
          </p>
        )}

        <div className="p-3 rounded-lg bg-slate-900/40 border border-white/5 flex flex-col gap-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-300 font-medium">Block when risk is above</span>
            <span className="font-mono font-bold text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">&gt; {threshold}</span>
          </div>
          <input
            type="range"
            min="1"
            max={maxThreshold}
            step="1"
            value={Math.min(threshold, maxThreshold)}
            disabled={!requested}
            onChange={(e) => setRequested((prev) => ({ ...prev, risk_threshold: parseInt(e.target.value, 10) }))}
            className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>Stricter (1)</span>
            <span>Server: {serverThreshold}</span>
            <span>{locked ? 'Cannot exceed server' : 'Permissive (100)'}</span>
          </div>
          <p className="text-[10px] text-slate-500 leading-snug">
            Scores {uncertainLow}&ndash;{threshold} are <strong className="text-amber-300">uncertain</strong>: allowed but flagged
            {server?.uncertain_action === 'block' ? ' (this server blocks them)' : ''}. A score equal to the threshold is not blocked.
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-2.5 pt-2 border-t border-white/5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-violet-400/90">
          <FileCode size={14} /> <span>Output Guardrails</span>
        </div>
        {CONTROLS.output.map(([f, l, h]) => (
          <Toggle key={f} field={f} label={l} hint={h} {...props} />
        ))}
      </div>

      <div className="mt-auto pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${healthStatus?.status === 'healthy' ? 'bg-emerald-400 pulse-live' : 'bg-rose-400'}`} />
          <span>
            Gateway: <strong className="text-slate-200">{healthStatus?.status || 'connecting...'}</strong>
          </span>
        </div>
        <div className="text-[11px] flex items-center gap-1">
          <Lock size={11} className={healthStatus?.api_calls_enabled ? 'text-rose-400' : 'text-emerald-400'} />
          <span>{healthStatus?.api_calls_enabled ? 'Paid live provider' : 'Free local simulation'}</span>
        </div>
      </div>
    </div>
  );
}
