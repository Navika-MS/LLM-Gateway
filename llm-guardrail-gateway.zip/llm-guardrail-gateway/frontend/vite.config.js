import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Local development only. The dev server binds to localhost (not the whole network); the API is called directly
// at VITE_API_URL (default http://127.0.0.1:8000), which the backend allows via its explicit CORS origin list.
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, host: '127.0.0.1' },
});
