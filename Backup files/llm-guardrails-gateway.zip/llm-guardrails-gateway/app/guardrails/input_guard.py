"""
STEP 1 — INPUT GUARDRAILS MODULE

Two independent checks, both driven by policy.yaml:
  1. PII Detection (regex)   — emails, phone numbers, credit card numbers, SSNs
  2. Injection/Jailbreak Filtering — known override/jailbreak phrase patterns

Fast, local, no external calls — this is what saves API cost/latency by
rejecting bad requests before they ever reach the LLM.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from app.config import Policy

# --- PII regex library -------------------------------------------------

PII_PATTERNS: dict[str, re.Pattern] = {
    "email": re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"),
    "phone": re.compile(
        r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"
    ),
    # Matches common 16-digit card formats, with or without spaces/dashes,
    # and passes a Luhn check to cut down on false positives (e.g. random
    # 16-digit numbers that aren't actually card numbers).
    "credit_card": re.compile(r"\b(?:\d[ -]*?){13,16}\b"),
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
}


def _luhn_check(number: str) -> bool:
    digits = [int(d) for d in re.sub(r"\D", "", number)]
    if len(digits) < 13:
        return False
    checksum = 0
    parity = len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


@dataclass
class GuardrailResult:
    passed: bool
    stage: str = ""
    reason: str = ""
    detail: str = ""


def check_pii(text: str, categories: list[str]) -> GuardrailResult:
    findings = []
    for category in categories:
        pattern = PII_PATTERNS.get(category)
        if not pattern:
            continue
        for match in pattern.finditer(text):
            if category == "credit_card" and not _luhn_check(match.group()):
                continue
            findings.append(category)
            break  # one hit per category is enough to block

    if findings:
        return GuardrailResult(
            passed=False,
            stage="input_guardrails.pii_detection",
            reason="PII detected in prompt",
            detail=f"Detected category(ies): {', '.join(sorted(set(findings)))}",
        )
    return GuardrailResult(passed=True)


def check_injection(text: str, patterns: list[str]) -> GuardrailResult:
    lowered = text.lower()
    for phrase in patterns:
        if phrase.lower() in lowered:
            return GuardrailResult(
                passed=False,
                stage="input_guardrails.injection_filtering",
                reason="Potential prompt injection / jailbreak attempt detected",
                detail=f"Matched pattern: '{phrase}'",
            )
    return GuardrailResult(passed=True)


def run_input_guardrails(text: str, policy: Policy) -> GuardrailResult:
    """Runs both checks in order; returns the first failure, or a pass."""
    cfg = policy.input_guardrails

    if cfg.pii_enabled:
        result = check_pii(text, cfg.pii_categories)
        if not result.passed:
            return result

    if cfg.injection_enabled:
        result = check_injection(text, cfg.injection_patterns)
        if not result.passed:
            return result

    return GuardrailResult(passed=True)
