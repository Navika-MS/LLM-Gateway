"""
STEP 4 — OUTPUT GUARDRAILS & VALIDATION

  1. Pydantic Schema Check — validate raw LLM JSON against expected schema
  2. Auto-Retry Logic — on failure, send the schema error back to the LLM
     as a correction note and retry once (matches diagram: "FAILURE ->
     SINGLE RETRY W/ ERROR LOG")
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Optional

from app.config import Policy
from app.llm_client import StubLLMClient
from app.schemas import validate_against_schema

logger = logging.getLogger("guardrails_gateway")


@dataclass
class OutputResult:
    success: bool
    data: Optional[Any] = None
    retried: bool = False
    model_used: str = ""
    error: Optional[str] = None


def run_output_guardrails(
    prompt: str,
    response_format: str,
    llm_client: StubLLMClient,
    policy: Policy,
) -> OutputResult:
    cfg = policy.output_guardrails

    # --- Attempt 1: raw LLM call ---
    result = llm_client.call(prompt)
    parsed_json, parse_error = _safe_json_parse(result.raw_text)

    if parse_error is None and cfg.schema_validation_enabled:
        is_valid, data, schema_error = validate_against_schema(parsed_json, response_format)
    elif parse_error is None:
        is_valid, data, schema_error = True, parsed_json, None
    else:
        is_valid, data, schema_error = False, None, parse_error

    if is_valid:
        return OutputResult(success=True, data=data, retried=False, model_used=result.model)

    logger.warning(
        "Output validation failed on first attempt. stage=output_guardrails.schema_validation "
        "error=%s", schema_error,
    )

    if not cfg.auto_retry_enabled:
        return OutputResult(success=False, retried=False, model_used=result.model, error=schema_error)

    # --- Attempt 2: single retry with the error fed back to the LLM ---
    correction_note = (
        f"Your previous response failed schema validation with error: {schema_error}. "
        f"Please correct the output to match the required schema."
    )
    retry_result = llm_client.call(prompt, correction_note=correction_note)
    retry_json, retry_parse_error = _safe_json_parse(retry_result.raw_text)

    if retry_parse_error is None:
        is_valid, data, schema_error = validate_against_schema(retry_json, response_format)
    else:
        is_valid, data, schema_error = False, None, retry_parse_error

    if is_valid:
        logger.info("Retry succeeded after schema error self-correction.")
        return OutputResult(success=True, data=data, retried=True, model_used=retry_result.model)

    logger.error("Retry also failed. error=%s", schema_error)
    return OutputResult(
        success=False, retried=True, model_used=retry_result.model, error=schema_error
    )


def _safe_json_parse(text: str) -> tuple[Optional[dict], Optional[str]]:
    try:
        return json.loads(text), None
    except json.JSONDecodeError as e:
        return None, f"Response was not valid JSON: {e}"
