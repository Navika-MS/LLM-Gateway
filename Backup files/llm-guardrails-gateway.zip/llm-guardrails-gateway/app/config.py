"""
Loads the SYSTEM POLICY (YAML) shown in the architecture diagram and exposes
it as a simple typed object so the rest of the app doesn't touch raw dicts.
"""
from __future__ import annotations

import pathlib
from dataclasses import dataclass, field

import yaml

POLICY_PATH = pathlib.Path(__file__).parent / "policy.yaml"


@dataclass
class InputGuardrailsConfig:
    pii_enabled: bool
    pii_categories: list[str]
    pii_action: str
    injection_enabled: bool
    injection_action: str
    injection_patterns: list[str]


@dataclass
class OutputGuardrailsConfig:
    schema_validation_enabled: bool
    auto_retry_enabled: bool
    max_retries: int


@dataclass
class CoreRoutingConfig:
    primary_model: str
    timeout_seconds: int


@dataclass
class Policy:
    input_guardrails: InputGuardrailsConfig
    output_guardrails: OutputGuardrailsConfig
    core_routing: CoreRoutingConfig
    log_level: str = "INFO"


def load_policy(path: pathlib.Path = POLICY_PATH) -> Policy:
    with open(path, "r") as f:
        raw = yaml.safe_load(f)

    ig = raw["input_guardrails"]
    og = raw["output_guardrails"]
    cr = raw["core_routing"]

    return Policy(
        input_guardrails=InputGuardrailsConfig(
            pii_enabled=ig["pii_detection"]["enabled"],
            pii_categories=ig["pii_detection"]["categories"],
            pii_action=ig["pii_detection"]["action"],
            injection_enabled=ig["injection_filtering"]["enabled"],
            injection_action=ig["injection_filtering"]["action"],
            injection_patterns=ig["injection_filtering"]["patterns"],
        ),
        output_guardrails=OutputGuardrailsConfig(
            schema_validation_enabled=og["schema_validation"]["enabled"],
            auto_retry_enabled=og["auto_retry"]["enabled"],
            max_retries=og["auto_retry"]["max_retries"],
        ),
        core_routing=CoreRoutingConfig(
            primary_model=cr["primary_model"],
            timeout_seconds=cr["timeout_seconds"],
        ),
        log_level=raw.get("monitoring", {}).get("log_level", "INFO"),
    )


# Loaded once at import time; re-import/restart to pick up policy.yaml edits.
policy = load_policy()
