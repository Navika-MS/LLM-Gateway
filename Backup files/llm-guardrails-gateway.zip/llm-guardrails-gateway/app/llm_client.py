"""
STUBBED LLM CLIENT — represents "3. EXTERNAL LLM PROVIDER (Claude/OpenAI API)"
in the diagram.

This mimics the shape of a real `anthropic.Anthropic().messages.create(...)`
call so swapping in the real SDK later is a small, contained change (see
README "Going live" section). It deliberately injects some malformed
responses so you can see the auto-retry logic (step 4) actually fire.
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass

from app.config import Policy


@dataclass
class LLMResult:
    raw_text: str
    model: str


class StubLLMClient:
    """
    Drop-in-shaped replacement for a real LLM SDK client.
    call() takes a prompt (and optional correction instructions for retries)
    and returns raw text — exactly what a real LLM call would hand back
    before any validation happens.
    """

    def __init__(self, policy: Policy):
        self.policy = policy

    def call(self, prompt: str, correction_note: str | None = None) -> LLMResult:
        model = self.policy.core_routing.primary_model

        # Simulate "the LLM tries to extract a task from the prompt."
        # ~30% of first attempts return a deliberately malformed payload
        # (missing required field) to demonstrate the retry path — unless
        # a correction_note is present, in which case it "self-corrects."
        should_malform = correction_note is None and random.random() < 0.3

        if should_malform:
            # Missing required 'priority' field -> fails schema validation
            payload = {
                "task_title": _extract_title(prompt),
                "tags": _extract_tags(prompt),
            }
        else:
            payload = {
                "task_title": _extract_title(prompt),
                "priority": _guess_priority(prompt),
                "due_date": _extract_due_date(prompt),
                "tags": _extract_tags(prompt),
            }

        return LLMResult(raw_text=json.dumps(payload), model=model)


def _extract_title(prompt: str) -> str:
    # Naive stand-in for "the LLM summarized this into a task title."
    words = prompt.strip().split()
    return " ".join(words[:8]).rstrip(".,!?") or "Untitled task"


def _guess_priority(prompt: str) -> str:
    lowered = prompt.lower()
    if any(w in lowered for w in ("urgent", "asap", "immediately", "critical")):
        return "high"
    if any(w in lowered for w in ("someday", "eventually", "low priority")):
        return "low"
    return "medium"


def _extract_due_date(prompt: str) -> str | None:
    lowered = prompt.lower()
    if "tomorrow" in lowered:
        return "tomorrow"
    if "today" in lowered:
        return "today"
    return None


def _extract_tags(prompt: str) -> list[str]:
    tags = []
    for kw in ("bug", "feature", "meeting", "report", "email", "design"):
        if kw in prompt.lower():
            tags.append(kw)
    return tags
