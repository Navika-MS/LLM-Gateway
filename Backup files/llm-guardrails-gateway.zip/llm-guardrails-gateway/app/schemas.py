"""
Pydantic v2 schemas.

- ChatRequest / ChatResponse / ErrorResponse: the gateway's own API contract.
- TaskExtraction: an EXAMPLE downstream schema representing "the structured
  JSON your application expects back from the LLM." Swap this for your own
  schema — it's what the Output Guardrails module (step 4) validates against.
"""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, ValidationError


class ChatRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=8000)
    # Which output schema to enforce. "task_extraction" is the demo schema;
    # "free_text" skips structural validation and just returns model text.
    response_format: Literal["task_extraction", "free_text"] = "task_extraction"


class ErrorResponse(BaseModel):
    status: Literal["blocked", "error"]
    stage: str          # which guardrail stage rejected the request
    reason: str
    detail: Optional[str] = None


class ChatResponse(BaseModel):
    status: Literal["success"] = "success"
    data: Any
    retried: bool = False
    model_used: str


# --- Example downstream structured-output schema (step 4: Pydantic Schema Check) ---

class TaskExtraction(BaseModel):
    """
    Example schema: the LLM is asked to turn a prompt into a structured task.
    This is what 'PYDANTIC SCHEMA CHECK' validates raw LLM output against.
    """
    task_title: str = Field(..., min_length=1)
    priority: Literal["low", "medium", "high"]
    due_date: Optional[str] = None
    tags: list[str] = Field(default_factory=list)


def validate_against_schema(raw_json: dict, schema_name: str) -> tuple[bool, Any, Optional[str]]:
    """
    Returns (is_valid, parsed_or_none, error_message_or_none).
    """
    if schema_name == "free_text":
        return True, raw_json, None

    schema_map = {"task_extraction": TaskExtraction}
    model_cls = schema_map.get(schema_name)
    if model_cls is None:
        return False, None, f"Unknown schema '{schema_name}'"

    try:
        parsed = model_cls.model_validate(raw_json)
        return True, parsed.model_dump(), None
    except ValidationError as e:
        return False, None, str(e)
