"""
LLM GUARDRAILS GATEWAY MIDDLEWARE — FastAPI entrypoint

Flow (matches the architecture diagram exactly):

  USER APPLICATION
        |
        v
  [1] INPUT GUARDRAILS MODULE  (PII detection + injection filtering)
        | pass                        | block
        v                             v
  [2] CORE ROUTING & ORCHESTRATION    400 Bad Request
        |
        v
  [3] EXTERNAL LLM PROVIDER (stubbed — see app/llm_client.py)
        |
        v
  [4] OUTPUT GUARDRAILS & VALIDATION  (pydantic check + single auto-retry)
        | success                     | failure (after retry)
        v                             v
  VALIDATED RESPONSE            502 error w/ log

  Every request is recorded to the PERFORMANCE MONITORING / LOGGING
  dashboard, exposed at GET /v1/metrics.

Run with:  uvicorn app.main:app --reload
Docs at:   http://127.0.0.1:8000/docs
"""
from __future__ import annotations

import time

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.config import policy
from app.guardrails.input_guard import run_input_guardrails
from app.guardrails.output_guard import run_output_guardrails
from app.llm_client import StubLLMClient
from app.monitoring import RequestEvent, metrics
from app.schemas import ChatRequest, ChatResponse, ErrorResponse

app = FastAPI(
    title="LLM Guardrails Gateway",
    description=(
        "Security-first middleware that sits between client apps and an LLM "
        "provider: input PII/injection filtering, orchestration, and output "
        "schema validation with auto-retry."
    ),
    version="1.0.0",
)

llm_client = StubLLMClient(policy)


@app.get("/")
def root():
    return {
        "service": "llm-guardrails-gateway",
        "status": "ok",
        "endpoints": ["/v1/chat", "/v1/metrics", "/docs"],
    }


@app.post(
    "/v1/chat",
    response_model=ChatResponse,
    responses={400: {"model": ErrorResponse}, 502: {"model": ErrorResponse}},
)
def chat(payload: ChatRequest, request: Request):
    start = time.perf_counter()

    # --- STEP 1: INPUT GUARDRAILS MODULE ---
    input_result = run_input_guardrails(payload.prompt, policy)
    if not input_result.passed:
        latency_ms = (time.perf_counter() - start) * 1000
        outcome = (
            "blocked_pii" if "pii" in input_result.stage else "blocked_injection"
        )
        metrics.record(RequestEvent(
            timestamp=time.time(), outcome=outcome, stage=input_result.stage,
            latency_ms=latency_ms,
        ))
        return JSONResponse(
            status_code=400,
            content=ErrorResponse(
                status="blocked",
                stage=input_result.stage,
                reason=input_result.reason,
                detail=input_result.detail,
            ).model_dump(),
        )

    # --- STEP 2 & 3: CORE ROUTING & ORCHESTRATION -> EXTERNAL LLM PROVIDER ---
    # --- STEP 4: OUTPUT GUARDRAILS & VALIDATION (incl. single auto-retry) ---
    output_result = run_output_guardrails(
        prompt=payload.prompt,
        response_format=payload.response_format,
        llm_client=llm_client,
        policy=policy,
    )

    latency_ms = (time.perf_counter() - start) * 1000

    if not output_result.success:
        metrics.record(RequestEvent(
            timestamp=time.time(), outcome="output_error",
            stage="output_guardrails.schema_validation",
            latency_ms=latency_ms, retried=output_result.retried,
        ))
        return JSONResponse(
            status_code=502,
            content=ErrorResponse(
                status="error",
                stage="output_guardrails.schema_validation",
                reason="LLM output failed schema validation after retry",
                detail=output_result.error,
            ).model_dump(),
        )

    metrics.record(RequestEvent(
        timestamp=time.time(), outcome="success", stage="output_guardrails.success",
        latency_ms=latency_ms, retried=output_result.retried,
    ))

    return ChatResponse(
        data=output_result.data,
        retried=output_result.retried,
        model_used=output_result.model_used,
    )


@app.get("/v1/metrics")
def get_metrics():
    """Backs the PERFORMANCE MONITORING / LOGGING DASHBOARD box in the diagram."""
    return metrics.snapshot()
