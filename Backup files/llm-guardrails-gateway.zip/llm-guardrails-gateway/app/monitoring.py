"""
PERFORMANCE MONITORING / LOGGING DASHBOARD (bottom-right box in the diagram)

A minimal in-memory metrics store + structured logger. In production, swap
the in-memory dict for Prometheus counters / a real time-series store, but
the interface (record_request) stays the same.
"""
from __future__ import annotations

import logging
import threading
import time
from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Deque

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("guardrails_gateway")


@dataclass
class RequestEvent:
    timestamp: float
    outcome: str          # "blocked_pii" | "blocked_injection" | "success" | "output_error"
    stage: str
    latency_ms: float
    retried: bool = False


class MetricsStore:
    def __init__(self, max_events: int = 500):
        self._lock = threading.Lock()
        self._events: Deque[RequestEvent] = deque(maxlen=max_events)
        self._counts: Counter = Counter()

    def record(self, event: RequestEvent) -> None:
        with self._lock:
            self._events.append(event)
            self._counts[event.outcome] += 1
        logger.info(
            "request outcome=%s stage=%s latency_ms=%.1f retried=%s",
            event.outcome, event.stage, event.latency_ms, event.retried,
        )

    def snapshot(self) -> dict:
        with self._lock:
            total = sum(self._counts.values())
            recent = list(self._events)[-20:]
            avg_latency = (
                sum(e.latency_ms for e in self._events) / len(self._events)
                if self._events else 0.0
            )
            return {
                "total_requests": total,
                "outcome_counts": dict(self._counts),
                "avg_latency_ms": round(avg_latency, 2),
                "retry_rate": round(
                    (sum(1 for e in self._events if e.retried) / len(self._events)) * 100, 1
                ) if self._events else 0.0,
                "recent_events": [
                    {
                        "timestamp": round(e.timestamp, 2),
                        "outcome": e.outcome,
                        "stage": e.stage,
                        "latency_ms": round(e.latency_ms, 1),
                        "retried": e.retried,
                    }
                    for e in recent
                ],
            }


metrics = MetricsStore()


class Timer:
    """Small context manager for measuring stage latency."""
    def __enter__(self):
        self._start = time.perf_counter()
        return self

    def __exit__(self, *exc):
        self.elapsed_ms = (time.perf_counter() - self._start) * 1000
